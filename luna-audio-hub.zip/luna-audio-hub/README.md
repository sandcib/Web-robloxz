# LUNA AUDIO HUB 🌙🔊

แพลตฟอร์มจัดการไฟล์เสียง และเตรียมเสียงสำหรับ Roblox — Premium Audio SaaS + Gaming Dashboard

## Tech Stack
- **Frontend:** React 18 · TypeScript · Vite · Tailwind CSS · Framer Motion · Lucide · Recharts
- **Backend:** Node.js · Express · TypeScript · JWT (bcrypt)
- **Database:** PostgreSQL · Prisma ORM
- **Audio:** FFmpeg (processing queue จริง พร้อม progress ผ่าน SSE)
- **Realtime:** Server-Sent Events

## เริ่มต้นใช้งาน (Local / Replit)

```bash
# 1. Install dependencies
npm install

# 2. ตั้งค่า environment
cp .env.example .env
# แก้ DATABASE_URL ให้ตรงกับ PostgreSQL ของคุณ

# 3. Setup database + seed demo data
npm run db:migrate
npm run db:seed

# 4. Run (client :5173 + server :4000)
npm run dev
```

## บัญชี Demo (จาก seed)
| Role | Email | Password |
|---|---|---|
| SUPER_ADMIN | admin@luna.dev | Admin@1234 |
| ADMIN | mod@luna.dev | Admin@1234 |
| USER | demo@luna.dev | Demo@1234 |

## โครงสร้าง
```
client/    React SPA (Vite)
server/    Express API + FFmpeg job queue + SSE
prisma/    Schema + seed
uploads/   ไฟล์เสียงที่อัปโหลด (gitignored)
shared/    Types ที่ใช้ร่วมกัน
```

## ฟีเจอร์หลัก
- Auth (Email/Password, bcrypt, JWT session, roles: USER/ADMIN/SUPER_ADMIN)
- Upload เสียง (MP3/WAV/OGG/M4A) พร้อม cover image, drag&drop, waveform
- Processing Queue จริงด้วย FFmpeg (convert/normalize/trim/bitrate) + realtime progress
- YouTube Import (validate URL, duration limit, copyright warning)
- Roblox Ready (ถ้าไม่มี API key จะแสดงสถานะ "not configured" ตามจริง ไม่สร้าง ID ปลอม)
- Sound Library, Favorites, History, Global Audio Player
- Admin Control Center: Users, Audio, Jobs, Audit Log, Settings, Maintenance Mode
- Discord webhook logging (optional, ผ่าน env)
- Security: rate limit, MIME validation, size limit, path traversal protection, server-side authorization
- Command Palette (Ctrl+K), keyboard shortcuts, toasts, skeleton loading
- Responsive 360px → 1920px, error pages 403/404/500
