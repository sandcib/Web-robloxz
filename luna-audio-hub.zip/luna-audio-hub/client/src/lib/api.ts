import type { ApiRes } from "../types";

const TOKEN_KEY = "luna_token";

export function getToken() { return localStorage.getItem(TOKEN_KEY); }
export function setToken(t: string) { localStorage.setItem(TOKEN_KEY, t); }
export function clearToken() { localStorage.removeItem(TOKEN_KEY); }

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = { ...(init.headers as Record<string, string> | undefined) };
  if (!(init.body instanceof FormData)) headers["Content-Type"] = "application/json";
  if (token) headers["Authorization"] = `Bearer ${token}`;

  const res = await fetch(path, { ...init, headers, credentials: "include" });
  const json = (await res.json().catch(() => ({ success: false, message: "Network error", code: "NETWORK" }))) as ApiRes<T>;

  if (!json.success) {
    if (json.code === "SESSION_EXPIRED" || json.code === "UNAUTHORIZED") clearToken();
    const err = new Error(json.message) as Error & { code?: string };
    err.code = json.code;
    throw err;
  }
  return json.data;
}

export const api = {
  get: <T>(path: string) => request<T>(path),
  post: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: "POST", body: body instanceof FormData ? body : JSON.stringify(body ?? {}) }),
  patch: <T>(path: string, body?: unknown) => request<T>(path, { method: "PATCH", body: JSON.stringify(body ?? {}) }),
  del: <T>(path: string) => request<T>(path, { method: "DELETE" }),
  upload: <T>(path: string, form: FormData) => request<T>(path, { method: "POST", body: form }),
};

export function fileUrl(rel: string | null | undefined): string | null {
  if (!rel) return null;
  if (rel.startsWith("http")) return rel;
  return rel; // vite proxy จัดการ /uploads
}
