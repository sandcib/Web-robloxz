import { useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Mail, Lock, User as UserIcon, UserPlus } from "lucide-react";
import { useAuth } from "../contexts/AuthContext";
import { useToast } from "../contexts/ToastContext";
import { BackgroundScene } from "../components/layout/BackgroundScene";
import { Logo } from "../components/layout/Logo";
import { Button } from "../components/ui/Button";
import { Input } from "../components/ui/Input";

export default function Register() {
  const { register } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", username: "", password: "", confirm: "" });
  const [loading, setLoading] = useState(false);

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (form.password !== form.confirm) return toast("warning", "Passwords do not match");
    if (form.password.length < 8) return toast("warning", "Password must be at least 8 characters");
    setLoading(true);
    try {
      const user = await register(form.email, form.username, form.password);
      toast("success", `Welcome to LUNA, ${user.username}`);
      navigate("/dashboard", { replace: true });
    } catch (err) {
      toast("error", (err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 relative">
      <BackgroundScene />
      <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="w-full max-w-md">
        <div className="flex justify-center mb-8"><Logo to="/" /></div>
        <div className="glass-strong neon-border rounded-3xl p-8">
          <h1 className="font-display font-bold text-2xl text-white text-center">สร้างบัญชีใหม่</h1>
          <p className="text-sm text-slate-500 text-center mt-2">เริ่มต้นจัดการเสียงของคุณวันนี้</p>

          <form onSubmit={submit} className="mt-8 space-y-4">
            <div className="relative">
              <Mail size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
              <Input type="email" required value={form.email} onChange={set("email")} placeholder="Email" className="!pl-11" autoComplete="email" />
            </div>
            <div className="relative">
              <UserIcon size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
              <Input required minLength={3} value={form.username} onChange={set("username")} placeholder="Username" className="!pl-11" autoComplete="username" />
            </div>
            <div className="relative">
              <Lock size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
              <Input type="password" required minLength={8} value={form.password} onChange={set("password")} placeholder="Password (min 8 chars)" className="!pl-11" autoComplete="new-password" />
            </div>
            <div className="relative">
              <Lock size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
              <Input type="password" required value={form.confirm} onChange={set("confirm")} placeholder="Confirm password" className="!pl-11" autoComplete="new-password" />
            </div>
            <Button type="submit" loading={loading} className="w-full">
              <UserPlus size={16} /> Create Account
            </Button>
          </form>

          <p className="text-center text-sm text-slate-500 mt-6">
            มีบัญชีอยู่แล้ว?{" "}
            <Link to="/login" className="text-violet-300 hover:text-white font-medium transition-colors">เข้าสู่ระบบ</Link>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
