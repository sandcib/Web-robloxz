import { useEffect, useState } from "react";
import { ScrollText, ChevronLeft, ChevronRight } from "lucide-react";
import { api } from "../../lib/api";
import { formatDate, formatTime } from "../../lib/utils";
import { Card } from "../../components/ui/Card";
import { Input } from "../../components/ui/Input";
import { SkeletonRow } from "../../components/ui/Skeletons";
import type { AuditLogItem, Paginated } from "../../types";

const ACTION_COLORS: Record<string, string> = {
  LOGIN: "text-sky-300", LOGOUT: "text-slate-400", UPLOAD: "text-emerald-300",
  DELETE: "text-rose-300", USER_BAN: "text-amber-300", ROLE_CHANGE: "text-fuchsia-300",
  SETTINGS_UPDATED: "text-violet-300", ROBLOX_UPLOAD: "text-emerald-300",
};

export default function AdminLogs() {
  const [data, setData] = useState<Paginated<AuditLogItem> | null>(null);
  const [loading, setLoading] = useState(true);
  const [action, setAction] = useState("");
  const [page, setPage] = useState(1);

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams({ page: String(page), limit: "30" });
    if (action.trim()) params.set("action", action.trim());
    const t = setTimeout(() => {
      api.get<Paginated<AuditLogItem>>(`/api/admin/logs?${params}`).then(setData).catch(() => {}).finally(() => setLoading(false));
    }, action ? 300 : 0);
    return () => clearTimeout(t);
  }, [page, action]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display font-bold text-3xl text-white flex items-center gap-3">
            <ScrollText className="text-violet-neon" size={26} /> System <span className="gradient-text">Logs</span>
          </h1>
          <p className="text-slate-500 mt-1 text-sm">Audit trail ทุก action ในระบบ — เฉพาะ Admin</p>
        </div>
        <Input value={action} onChange={(e) => { setAction(e.target.value); setPage(1); }} placeholder="Filter by action..." className="!w-56" />
      </div>

      <Card className="!p-0 overflow-hidden">
        {loading ? (
          <div className="p-5">{Array.from({ length: 6 }).map((_, i) => <SkeletonRow key={i} />)}</div>
        ) : (
          <div className="divide-y divide-white/5">
            {(data?.items ?? []).map((log) => (
              <div key={log.id} className="flex flex-wrap items-center gap-x-4 gap-y-1 px-5 py-3.5 hover:bg-white/[0.03] transition-colors">
                <span className="font-mono text-[10px] text-slate-600 w-28 shrink-0">
                  {formatDate(log.createdAt)} {formatTime(log.createdAt)}
                </span>
                <span className={`font-display font-semibold text-xs uppercase tracking-wider w-40 shrink-0 ${ACTION_COLORS[log.action] ?? "text-slate-300"}`}>
                  {log.action}
                </span>
                <span className="text-sm text-white flex-1 min-w-[140px]">{log.user?.username ?? "system"}</span>
                {log.target && <span className="text-xs text-slate-500">{log.target}</span>}
                <span className="text-[10px] font-mono text-slate-600 ml-auto">{log.ip ?? ""}</span>
              </div>
            ))}
            {data?.items.length === 0 && <p className="text-center text-slate-500 py-10 text-sm">No logs found</p>}
          </div>
        )}
      </Card>

      {data && data.pages > 1 && (
        <div className="flex items-center justify-center gap-3">
          <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="btn-ghost !p-2" aria-label="Previous"><ChevronLeft size={16} /></button>
          <span className="font-mono text-sm text-slate-400">{page} / {data.pages}</span>
          <button disabled={page >= data.pages} onClick={() => setPage((p) => p + 1)} className="btn-ghost !p-2" aria-label="Next"><ChevronRight size={16} /></button>
        </div>
      )}
    </div>
  );
}
