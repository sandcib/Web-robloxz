import { useCallback, useEffect, useState } from "react";
import { Search, Ban, CheckCircle2, Trash2, Shield, ChevronLeft, ChevronRight, MoreVertical } from "lucide-react";
import { api } from "../../lib/api";
import { useToast } from "../../contexts/ToastContext";
import { formatBytes, formatDate } from "../../lib/utils";
import { Card } from "../../components/ui/Card";
import { Input, Select } from "../../components/ui/Input";
import { StatusBadge } from "../../components/ui/StatusBadge";
import { ConfirmDialog } from "../../components/ui/ConfirmDialog";
import { SkeletonRow } from "../../components/ui/Skeletons";
import type { Paginated, Role } from "../../types";

interface AdminUser {
  id: string; username: string; email: string; role: Role; banned: boolean;
  avatarUrl: string | null; createdAt: string; lastLoginAt: string | null;
  storageUsed: number; audioCount: number;
}

export default function AdminUsers() {
  const { toast } = useToast();
  const [data, setData] = useState<Paginated<AdminUser> | null>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [role, setRole] = useState("");
  const [page, setPage] = useState(1);
  const [confirm, setConfirm] = useState<{ type: "ban" | "unban" | "delete"; user: AdminUser } | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), limit: "15" });
      if (search.trim()) params.set("search", search.trim());
      if (role) params.set("role", role);
      setData(await api.get<Paginated<AdminUser>>(`/api/admin/users?${params}`));
    } finally {
      setLoading(false);
    }
  }, [page, search, role]);

  useEffect(() => {
    const t = setTimeout(load, search ? 300 : 0);
    return () => clearTimeout(t);
  }, [load]);

  const act = async () => {
    if (!confirm) return;
    setBusy(true);
    try {
      const u = confirm.user;
      if (confirm.type === "ban") await api.patch(`/api/admin/users/${u.id}`, { banned: true });
      if (confirm.type === "unban") await api.patch(`/api/admin/users/${u.id}`, { banned: false });
      if (confirm.type === "delete") await api.del(`/api/admin/users/${u.id}`);
      toast("success", `User ${confirm.type}d`);
      setConfirm(null);
      load();
    } catch (e) {
      toast("error", (e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const changeRole = async (u: AdminUser, newRole: Role) => {
    try {
      await api.patch(`/api/admin/users/${u.id}`, { role: newRole });
      toast("success", `Role changed to ${newRole}`);
      load();
    } catch (e) {
      toast("error", (e as Error).message);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display font-bold text-3xl text-white">User <span className="gradient-text">Management</span></h1>
        <p className="text-slate-500 mt-1 text-sm">{data?.total ?? 0} users</p>
      </div>

      <div className="flex flex-wrap gap-2">
        <div className="relative flex-1 min-w-[220px]">
          <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
          <Input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} placeholder="Search users..." className="!pl-10" />
        </div>
        <Select value={role} onChange={(e) => { setRole(e.target.value); setPage(1); }} className="!w-40">
          <option value="">All roles</option>
          <option value="USER">USER</option>
          <option value="ADMIN">ADMIN</option>
          <option value="SUPER_ADMIN">SUPER_ADMIN</option>
        </Select>
      </div>

      <Card className="!p-0 overflow-hidden">
        {/* Desktop table */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[11px] font-display tracking-wider text-slate-500 uppercase border-b border-white/5">
                <th className="px-5 py-3.5">User</th>
                <th className="px-5 py-3.5">Role</th>
                <th className="px-5 py-3.5">Status</th>
                <th className="px-5 py-3.5">Audio</th>
                <th className="px-5 py-3.5">Storage</th>
                <th className="px-5 py-3.5">Created</th>
                <th className="px-5 py-3.5">Last Login</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {loading ? (
                <tr><td colSpan={8} className="px-5">{Array.from({ length: 5 }).map((_, i) => <SkeletonRow key={i} />)}</td></tr>
              ) : (data?.items ?? []).map((u) => (
                <tr key={u.id} className="hover:bg-white/[0.03] transition-colors">
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-gradient-to-br from-violet-neon to-magenta flex items-center justify-center text-white text-xs font-display font-bold shrink-0">
                        {u.avatarUrl ? <img src={u.avatarUrl} alt="" className="w-full h-full object-cover rounded-full" /> : u.username[0].toUpperCase()}
                      </div>
                      <div>
                        <p className="text-white font-medium">{u.username}</p>
                        <p className="text-xs text-slate-500">{u.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-3">
                    <Select value={u.role} onChange={(e) => changeRole(u, e.target.value as Role)} className="!py-1.5 !px-2 !w-auto text-xs">
                      <option value="USER">USER</option>
                      <option value="ADMIN">ADMIN</option>
                      <option value="SUPER_ADMIN">SUPER_ADMIN</option>
                    </Select>
                  </td>
                  <td className="px-5 py-3">{u.banned ? <StatusBadge status="FAILED" className="!text-[10px]" /> : <StatusBadge status="READY" className="!text-[10px]" />}</td>
                  <td className="px-5 py-3 font-mono text-slate-300">{u.audioCount}</td>
                  <td className="px-5 py-3 font-mono text-slate-300">{formatBytes(u.storageUsed)}</td>
                  <td className="px-5 py-3 text-slate-400 text-xs">{formatDate(u.createdAt)}</td>
                  <td className="px-5 py-3 text-slate-400 text-xs">{u.lastLoginAt ? formatDate(u.lastLoginAt) : "—"}</td>
                  <td className="px-5 py-3">
                    <div className="flex justify-end gap-1.5">
                      {u.banned ? (
                        <button onClick={() => setConfirm({ type: "unban", user: u })} className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-slate-400 hover:text-emerald-300 transition-colors" title="Unban"><CheckCircle2 size={13} /></button>
                      ) : (
                        <button onClick={() => setConfirm({ type: "ban", user: u })} className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-slate-400 hover:text-amber-300 transition-colors" title="Ban"><Ban size={13} /></button>
                      )}
                      <button onClick={() => setConfirm({ type: "delete", user: u })} className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-slate-400 hover:text-rose-400 transition-colors" title="Delete"><Trash2 size={13} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile cards */}
        <div className="md:hidden divide-y divide-white/5">
          {loading ? (
            <div className="p-4">{Array.from({ length: 4 }).map((_, i) => <SkeletonRow key={i} />)}</div>
          ) : (data?.items ?? []).map((u) => (
            <div key={u.id} className="p-4 space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-violet-neon to-magenta flex items-center justify-center text-white font-display font-bold">
                  {u.username[0].toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white text-sm font-medium truncate">{u.username}</p>
                  <p className="text-xs text-slate-500 truncate">{u.email}</p>
                </div>
                {u.banned ? <StatusBadge status="FAILED" className="!text-[9px]" /> : <StatusBadge status="READY" className="!text-[9px]" />}
              </div>
              <div className="grid grid-cols-3 gap-2 text-center text-[11px]">
                <div className="rounded-lg bg-white/5 py-2"><p className="text-slate-500">Audio</p><p className="font-mono text-white">{u.audioCount}</p></div>
                <div className="rounded-lg bg-white/5 py-2"><p className="text-slate-500">Storage</p><p className="font-mono text-white">{formatBytes(u.storageUsed)}</p></div>
                <div className="rounded-lg bg-white/5 py-2"><p className="text-slate-500">Role</p><p className="font-mono text-violet-300">{u.role}</p></div>
              </div>
              <div className="flex gap-2">
                <Select value={u.role} onChange={(e) => changeRole(u, e.target.value as Role)} className="flex-1 !py-1.5 text-xs">
                  <option value="USER">USER</option><option value="ADMIN">ADMIN</option><option value="SUPER_ADMIN">SUPER_ADMIN</option>
                </Select>
                {u.banned ? (
                  <button onClick={() => setConfirm({ type: "unban", user: u })} className="btn-ghost !py-1.5 text-xs">Unban</button>
                ) : (
                  <button onClick={() => setConfirm({ type: "ban", user: u })} className="btn-ghost !py-1.5 text-xs">Ban</button>
                )}
                <button onClick={() => setConfirm({ type: "delete", user: u })} className="btn-ghost !py-1.5 text-xs !border-rose-500/30 text-rose-300">Delete</button>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {data && data.pages > 1 && (
        <div className="flex items-center justify-center gap-3">
          <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="btn-ghost !p-2" aria-label="Previous"><ChevronLeft size={16} /></button>
          <span className="font-mono text-sm text-slate-400">{page} / {data.pages}</span>
          <button disabled={page >= data.pages} onClick={() => setPage((p) => p + 1)} className="btn-ghost !p-2" aria-label="Next"><ChevronRight size={16} /></button>
        </div>
      )}

      <ConfirmDialog
        open={!!confirm}
        onClose={() => setConfirm(null)}
        onConfirm={act}
        loading={busy}
        title={confirm?.type === "delete" ? "Delete User" : confirm?.type === "ban" ? "Ban User" : "Unban User"}
        message={confirm ? `คุณแน่ใจหรือไม่ที่จะ ${confirm.type} ผู้ใช้ “${confirm.user.username}”?` : ""}
        confirmText={confirm?.type ?? "Confirm"}
      />
    </div>
  );
}
