import { useEffect, useState } from "react";
import { Users, UserCheck, Music, Loader2, HardDrive, XCircle, Activity, Cpu } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";
import { api } from "../../lib/api";
import { formatBytes } from "../../lib/utils";
import { StatCard } from "../../components/ui/StatCard";
import { SkeletonStats } from "../../components/ui/Skeletons";
import { Card } from "../../components/ui/Card";

interface Dash {
  totalUsers: number; activeUsers: number; totalAudio: number; processingJobs: number;
  failedJobs: number; bannedUsers: number; storageUsed: number;
  uploadsByDay: { date: string; count: number }[];
  system: { uptime: number; memoryMb: number; node: string; queue: number; online: boolean };
}

export default function AdminDashboard() {
  const [data, setData] = useState<Dash | null>(null);
  const [rt, setRt] = useState<{ queue: number; processing: number; failed: number; memoryMb: number } | null>(null);

  useEffect(() => {
    api.get<Dash>("/api/admin/dashboard").then(setData).catch(() => {});
    const load = () => api.get<{ queue: number; processing: number; failed: number; memoryMb: number }>("/api/admin/stats/realtime").then(setRt).catch(() => {});
    load();
    const t = setInterval(load, 8000);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display font-bold text-3xl text-white tracking-wide">ADMIN <span className="gradient-text">CONTROL CENTER</span></h1>
          <p className="text-slate-500 mt-1 text-sm">ระบบภาพรวม · อัปเดต realtime</p>
        </div>
        <div className="flex items-center gap-2 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-4 py-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs font-display font-semibold text-emerald-300 tracking-widest">SYSTEM ONLINE</span>
        </div>
      </div>

      {/* System strip */}
      <Card className="!py-3.5">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono text-xs">
          {[
            ["CPU", `${rt?.processing ?? 0} active`],
            ["RAM", `${rt?.memoryMb ?? 0} MB`],
            ["QUEUE", `${rt?.queue ?? 0} waiting`],
            ["STORAGE", data ? formatBytes(data.storageUsed) : "—"],
          ].map(([l, v]) => (
            <div key={l} className="flex items-center gap-2.5">
              <Cpu size={14} className="text-violet-300 shrink-0" />
              <span className="text-slate-500">{l}</span>
              <span className="text-white ml-auto">{v}</span>
            </div>
          ))}
        </div>
      </Card>

      {!data ? <SkeletonStats /> : (
        <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
          <StatCard label="Total Users" value={data.totalUsers} icon={<Users size={18} />} accent="violet" />
          <StatCard label="Active Users" value={data.activeUsers} icon={<UserCheck size={18} />} accent="emerald" />
          <StatCard label="Total Audio" value={data.totalAudio} icon={<Music size={18} />} accent="violet" />
          <StatCard label="Processing Jobs" value={data.processingJobs} icon={<Loader2 size={18} />} accent="sky" />
          <StatCard label="Storage" value={formatBytes(data.storageUsed)} icon={<HardDrive size={18} />} accent="rose" />
          <StatCard label="Failed Jobs" value={data.failedJobs} icon={<XCircle size={18} />} accent="rose" />
        </div>
      )}

      <div className="grid lg:grid-cols-2 gap-4">
        <Card glow>
          <h2 className="font-display font-semibold text-white mb-4 flex items-center gap-2"><Activity size={16} className="text-violet-300" /> Audio Uploads (30d)</h2>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data?.uploadsByDay ?? []}>
                <CartesianGrid stroke="rgba(255,255,255,0.05)" vertical={false} />
                <XAxis dataKey="date" stroke="#475569" fontSize={10} tickLine={false} axisLine={false} />
                <YAxis stroke="#475569" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
                <Tooltip contentStyle={{ background: "#120820", border: "1px solid rgba(139,92,246,0.3)", borderRadius: 12, fontSize: 12 }} />
                <Bar dataKey="count" fill="#8B5CF6" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card>
          <h2 className="font-display font-semibold text-white mb-4">System Activity</h2>
          <div className="space-y-4">
            {data && [
              { label: "Uptime", value: `${Math.floor(data.system.uptime / 3600)}h ${Math.floor((data.system.uptime % 3600) / 60)}m`, pct: Math.min(100, (data.system.uptime / 86400) * 100) },
              { label: "Memory", value: `${data.system.memoryMb} MB`, pct: Math.min(100, (data.system.memoryMb / 4096) * 100) },
              { label: "Job Queue Load", value: `${data.processingJobs} jobs`, pct: Math.min(100, data.processingJobs * 10) },
            ].map((r) => (
              <div key={r.label}>
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="text-slate-500">{r.label}</span>
                  <span className="font-mono text-white">{r.value}</span>
                </div>
                <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                  <div className="h-full rounded-full bg-gradient-to-r from-violet-neon to-magenta" style={{ width: `${r.pct}%` }} />
                </div>
              </div>
            ))}
          </div>
          <p className="text-[11px] font-mono text-slate-600 mt-6">Node {data?.system.node ?? ""} · Banned users: {data?.bannedUsers ?? 0}</p>
        </Card>
      </div>
    </div>
  );
}
