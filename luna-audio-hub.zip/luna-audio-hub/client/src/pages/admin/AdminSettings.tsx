import { useEffect, useState, type FormEvent } from "react";
import { Save, Settings2, Palette, Wrench, BellRing } from "lucide-react";
import { api } from "../../lib/api";
import { useToast } from "../../contexts/ToastContext";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { Input, Select } from "../../components/ui/Input";

type Settings = Record<string, unknown>;

export default function AdminSettings() {
  const { toast } = useToast();
  const [settings, setSettings] = useState<Settings>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.get<Settings>("/api/admin/settings").then((s) => setSettings(s)).catch(() => {}).finally(() => setLoading(false));
  }, []);

  const set = (key: string, value: unknown) => setSettings((s) => ({ ...s, [key]: value }));

  const save = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload: Settings = {
        maxUploadSize: Number(settings.maxUploadSize),
        maxAudioDuration: Number(settings.maxAudioDuration),
        defaultBitrate: Number(settings.defaultBitrate),
        storageLimitMb: Number(settings.storageLimitMb),
        maintenanceMode: !!settings.maintenanceMode,
        discordLoggingEnabled: !!settings.discordLoggingEnabled,
        siteName: String(settings.siteName ?? "LUNA AUDIO HUB"),
        primaryColor: String(settings.primaryColor ?? "#8B5CF6"),
        accentColor: String(settings.accentColor ?? "#D946EF"),
      };
      await api.patch("/api/admin/settings", payload);
      toast("success", "Settings saved");
    } catch (err) {
      toast("error", (err as Error).message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="skeleton h-96 max-w-3xl mx-auto" />;

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="font-display font-bold text-3xl text-white flex items-center gap-3">
          <Settings2 className="text-violet-neon" size={26} /> System <span className="gradient-text">Settings</span>
        </h1>
        <p className="text-slate-500 mt-1 text-sm">ตั้งค่าระบบ · มีผลทันทีกับผู้ใช้ทุกคน</p>
      </div>

      {settings.maintenanceMode === true && (
        <div className="rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4 flex items-center gap-3">
          <Wrench size={18} className="text-amber-300 shrink-0" />
          <p className="text-sm text-amber-200"><strong>Maintenance Mode กำลังเปิดอยู่</strong> — ผู้ใช้ทั่วไปจะถูกบล็อกจากการใช้งาน (Admin เข้าได้ตามปกติ)</p>
        </div>
      )}

      <form onSubmit={save} className="space-y-6">
        <Card>
          <h3 className="font-display font-semibold text-white mb-4 flex items-center gap-2"><Wrench size={16} className="text-violet-300" /> Limits & Processing</h3>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-slate-400 font-display uppercase tracking-wider">Maximum Upload Size (bytes)</label>
              <Input type="number" className="mt-1.5" value={Number(settings.maxUploadSize ?? 52428800)} onChange={(e) => set("maxUploadSize", e.target.value)} />
            </div>
            <div>
              <label className="text-xs text-slate-400 font-display uppercase tracking-wider">Maximum Audio Duration (sec)</label>
              <Input type="number" className="mt-1.5" value={Number(settings.maxAudioDuration ?? 600)} onChange={(e) => set("maxAudioDuration", e.target.value)} />
            </div>
            <div>
              <label className="text-xs text-slate-400 font-display uppercase tracking-wider">Default Bitrate</label>
              <Select className="mt-1.5" value={String(settings.defaultBitrate ?? 192)} onChange={(e) => set("defaultBitrate", e.target.value)}>
                {[128, 192, 256, 320].map((b) => <option key={b} value={b}>{b} kbps</option>)}
              </Select>
            </div>
            <div>
              <label className="text-xs text-slate-400 font-display uppercase tracking-wider">Storage Limit per User (MB)</label>
              <Input type="number" className="mt-1.5" value={Number(settings.storageLimitMb ?? 2048)} onChange={(e) => set("storageLimitMb", e.target.value)} />
            </div>
          </div>
        </Card>

        <Card>
          <h3 className="font-display font-semibold text-white mb-4 flex items-center gap-2"><BellRing size={16} className="text-violet-300" /> Maintenance & Logging</h3>
          <div className="space-y-4">
            <label className="flex items-center justify-between rounded-xl bg-white/5 border border-white/10 p-4 cursor-pointer">
              <div>
                <p className="text-sm text-white font-medium">Maintenance Mode</p>
                <p className="text-xs text-slate-500 mt-0.5">บล็อกผู้ใช้ทั่วไป — แสดงหน้า SYSTEM MAINTENANCE</p>
              </div>
              <input type="checkbox" className="w-5 h-5 accent-violet-neon" checked={!!settings.maintenanceMode} onChange={(e) => set("maintenanceMode", e.target.checked)} />
            </label>
            <label className="flex items-center justify-between rounded-xl bg-white/5 border border-white/10 p-4 cursor-pointer">
              <div>
                <p className="text-sm text-white font-medium">Discord Logging</p>
                <p className="text-xs text-slate-500 mt-0.5">ส่ง log ไป Discord Webhook (ต้องตั้ง DISCORD_WEBHOOK_URL ใน env)</p>
              </div>
              <input type="checkbox" className="w-5 h-5 accent-violet-neon" checked={!!settings.discordLoggingEnabled} onChange={(e) => set("discordLoggingEnabled", e.target.checked)} />
            </label>
          </div>
        </Card>

        <Card>
          <h3 className="font-display font-semibold text-white mb-4 flex items-center gap-2"><Palette size={16} className="text-violet-300" /> Branding</h3>
          <div className="grid sm:grid-cols-3 gap-4">
            <div className="sm:col-span-3">
              <label className="text-xs text-slate-400 font-display uppercase tracking-wider">Site Name</label>
              <Input className="mt-1.5" value={String(settings.siteName ?? "LUNA AUDIO HUB")} onChange={(e) => set("siteName", e.target.value)} />
            </div>
            <div>
              <label className="text-xs text-slate-400 font-display uppercase tracking-wider">Primary Color</label>
              <div className="flex gap-2 mt-1.5">
                <input type="color" value={String(settings.primaryColor ?? "#8B5CF6")} onChange={(e) => set("primaryColor", e.target.value)} className="w-10 h-10 rounded-lg bg-transparent border border-white/10 cursor-pointer" aria-label="Primary color" />
                <Input value={String(settings.primaryColor ?? "#8B5CF6")} onChange={(e) => set("primaryColor", e.target.value)} />
              </div>
            </div>
            <div>
              <label className="text-xs text-slate-400 font-display uppercase tracking-wider">Accent Color</label>
              <div className="flex gap-2 mt-1.5">
                <input type="color" value={String(settings.accentColor ?? "#D946EF")} onChange={(e) => set("accentColor", e.target.value)} className="w-10 h-10 rounded-lg bg-transparent border border-white/10 cursor-pointer" aria-label="Accent color" />
                <Input value={String(settings.accentColor ?? "#D946EF")} onChange={(e) => set("accentColor", e.target.value)} />
              </div>
            </div>
          </div>
        </Card>

        <Button type="submit" loading={saving} className="w-full sm:w-auto"><Save size={16} /> Save Settings</Button>
      </form>
    </div>
  );
}
