import { useCallback, useEffect, useState } from "react";
import { Search, Trash2, RotateCcw, Download, ChevronLeft, ChevronRight, Play } from "lucide-react";
import { api } from "../../lib/api";
import { useToast } from "../../contexts/ToastContext";
import { formatBytes, formatDate } from "../../lib/utils";
import { Card } from "../../components/ui/Card";
import { Input, Select } from "../../components/ui/Input";
import { StatusBadge } from "../../components/ui/StatusBadge";
import { ConfirmDialog } from "../../components/ui/ConfirmDialog";
import { SkeletonRow } from "../../components/ui/Skeletons";
import { usePlayer } from "../../contexts/PlayerContext";
import type { Audio, Paginated } from "../../types";

interface AdminAudioItem extends Audio { user?: { username: string; email: string }; deleted?: boolean; }

export default function AdminAudio() {
  const { toast } = useToast();
  const { play } = usePlayer();
  const [data, setData] = useState<Paginated<AdminAudioItem> | null>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");
  const [page, setPage] = useState(1);
  const [confirm, setConfirm] = useState<{ type: "delete" | "restore"; item: AdminAudioItem } | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), limit: "15" });
      if (search.trim()) params.set("search", search.trim());
      if (status) params.set("status", status);
      setData(await api.get<Paginated<AdminAudioItem>>(`/api/admin/audio?${params}`));
    } finally {
      setLoading(false);
    }
  }, [page, search, status]);

  useEffect(() => {
    const t = setTimeout(load, search ? 300 : 0);
    return () => clearTimeout(t);
  }, [load]);

  const act = async () => {
    if (!confirm) return;
    setBusy(true);
    try {
      if (confirm.type === "delete") await api.del(`/api/admin/audio/${confirm.item.id}`);
      else await api.post(`/api/admin/audio/${confirm.item.id}/restore`);
      toast("success", `Audio ${confirm.type}d`);
      setConfirm(null);
      load();
    } catch (e) {
      toast("error", (e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display font-bold text-3xl text-white">Audio <span className="gradient-text">Files</span></h1>
        <p className="text-slate-500 mt-1 text-sm">{data?.total ?? 0} files</p>
      </div>

      <div className="flex flex-wrap gap-2">
        <div className="relative flex-1 min-w-[220px]">
          <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
          <Input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} placeholder="Search audio..." className="!pl-10" />
        </div>
        <Select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }} className="!w-40">
          <option value="">All status</option>
          <option value="READY">READY</option>
          <option value="PROCESSING">PROCESSING</option>
          <option value="QUEUED">QUEUED</option>
          <option value="FAILED">FAILED</option>
        </Select>
      </div>

      <Card className="!p-0 overflow-hidden">
        <div className="hidden lg:block overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[11px] font-display tracking-wider text-slate-500 uppercase border-b border-white/5">
                <th className="px-5 py-3.5">Title</th>
                <th className="px-5 py-3.5">Uploader</th>
                <th className="px-5 py-3.5">Size</th>
                <th className="px-5 py-3.5">Status</th>
                <th className="px-5 py-3.5">Created</th>
                <th className="px-5 py-3.5">Roblox ID</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {loading ? (
                <tr><td colSpan={7} className="px-5">{Array.from({ length: 5 }).map((_, i) => <SkeletonRow key={i} />)}</td></tr>
              ) : (data?.items ?? []).map((a) => (
                <tr key={a.id} className={`hover:bg-white/[0.03] transition-colors ${a.deleted ? "opacity-40" : ""}`}>
                  <td className="px-5 py-3">
                    <p className="text-white font-medium">{a.title}</p>
                    <p className="text-xs text-slate-500 font-mono">{a.originalName ?? ""}</p>
                  </td>
                  <td className="px-5 py-3 text-slate-400 text-xs">{a.user?.username ?? "—"}</td>
                  <td className="px-5 py-3 font-mono text-slate-300">{formatBytes(a.size)}</td>
                  <td className="px-5 py-3"><StatusBadge status={a.status} className="!text-[10px]" /></td>
                  <td className="px-5 py-3 text-slate-400 text-xs">{formatDate(a.createdAt)}</td>
                  <td className="px-5 py-3 font-mono text-xs text-emerald-300">{a.soundId ?? "—"}</td>
                  <td className="px-5 py-3">
                    <div className="flex justify-end gap-1.5">
                      {!a.deleted && (
                        <>
                          <button onClick={() => play(a)} className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-colors" title="Play"><Play size={13} /></button>
                          <a href={`/api/audio/${a.id}/download`} className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-slate-400 hover:text-white transition-colors" title="Download"><Download size={13} /></a>
                        </>
                      )}
                      {a.deleted ? (
                        <button onClick={() => setConfirm({ type: "restore", item: a })} className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-slate-400 hover:text-emerald-300 transition-colors" title="Restore"><RotateCcw size={13} /></button>
                      ) : (
                        <button onClick={() => setConfirm({ type: "delete", item: a })} className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-slate-400 hover:text-rose-400 transition-colors" title="Disable"><Trash2 size={13} /></button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile cards */}
        <div className="lg:hidden divide-y divide-white/5">
          {loading ? (
            <div className="p-4">{Array.from({ length: 4 }).map((_, i) => <SkeletonRow key={i} />)}</div>
          ) : (data?.items ?? []).map((a) => (
            <div key={a.id} className="p-4 space-y-2.5">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-white text-sm font-medium truncate">{a.title}</p>
                  <p className="text-xs text-slate-500">{a.user?.username} · {formatBytes(a.size)} · {formatDate(a.createdAt)}</p>
                </div>
                <StatusBadge status={a.status} className="!text-[9px] shrink-0" />
              </div>
              <div className="flex gap-2">
                {!a.deleted && <button onClick={() => play(a)} className="btn-ghost !py-1.5 text-xs flex-1">Play</button>}
                {a.deleted
                  ? <button onClick={() => setConfirm({ type: "restore", item: a })} className="btn-ghost !py-1.5 text-xs flex-1">Restore</button>
                  : <button onClick={() => setConfirm({ type: "delete", item: a })} className="btn-ghost !py-1.5 text-xs flex-1 !border-rose-500/30 text-rose-300">Disable</button>}
              </div>
            </div>
          ))}
        </div>
      </Card>

      {data && data.pages > 1 && (
        <div className="flex items-center justify-center gap-3">
          <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="btn-ghost !p-2" aria-label="Previous"><ChevronLeft size={16} /></button>
          <span className="font-mono text-sm text-slate-400">{page} / {data.pages}</span>
          <button disabled={page >= data.pages} onClick={() => setPage((p) => p + 1)} className="btn-ghost !p-2" aria-label="Next"><ChevronRight size={16} /></button>
        </div>
      )}

      <ConfirmDialog
        open={!!confirm}
        onClose={() => setConfirm(null)}
        onConfirm={act}
        loading={busy}
        title={confirm?.type === "delete" ? "Disable Audio" : "Restore Audio"}
        message={confirm ? `คุณแน่ใจหรือไม่ที่จะ ${confirm.type === "delete" ? "disable" : "restore"} “${confirm.item.title}”?` : ""}
        confirmText={confirm?.type ?? "Confirm"}
      />
    </div>
  );
}
