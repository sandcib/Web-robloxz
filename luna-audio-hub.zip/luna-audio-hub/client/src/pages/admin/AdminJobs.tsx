import { useCallback, useEffect, useState } from "react";
import { RefreshCw, XCircle, ListVideo, ChevronLeft, ChevronRight } from "lucide-react";
import { api } from "../../lib/api";
import { useToast } from "../../contexts/ToastContext";
import { formatDate, formatTime } from "../../lib/utils";
import { Card } from "../../components/ui/Card";
import { Select } from "../../components/ui/Input";
import { StatusBadge } from "../../components/ui/StatusBadge";
import { ProgressBar } from "../../components/ui/ProgressBar";
import { SkeletonRow } from "../../components/ui/Skeletons";
import type { Paginated, ProcessingJob } from "../../types";

export default function AdminJobs() {
  const { toast } = useToast();
  const [data, setData] = useState<Paginated<ProcessingJob> | null>(null);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState("");
  const [page, setPage] = useState(1);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), limit: "20" });
      if (status) params.set("status", status);
      setData(await api.get<Paginated<ProcessingJob>>(`/api/admin/jobs?${params}`));
    } finally {
      setLoading(false);
    }
  }, [page, status]);

  useEffect(() => {
    load();
    const t = setInterval(load, 5000); // realtime polling
    return () => clearInterval(t);
  }, [load]);

  const retry = async (id: string) => {
    try {
      await api.post(`/api/admin/jobs/${id}/retry`);
      toast("success", "Job requeued");
      load();
    } catch (e) { toast("error", (e as Error).message); }
  };

  const cancel = async (id: string) => {
    try {
      await api.post(`/api/admin/jobs/${id}/cancel`);
      toast("success", "Job cancelled");
      load();
    } catch (e) { toast("error", (e as Error).message); }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display font-bold text-3xl text-white flex items-center gap-3">
            <ListVideo className="text-violet-neon" size={26} /> Processing <span className="gradient-text">Queue</span>
          </h1>
          <p className="text-slate-500 mt-1 text-sm">อัปเดตอัตโนมัติทุก 5 วินาที</p>
        </div>
        <Select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }} className="!w-44">
          <option value="">All status</option>
          <option value="QUEUED">QUEUED</option>
          <option value="PROCESSING">PROCESSING</option>
          <option value="COMPLETED">COMPLETED</option>
          <option value="FAILED">FAILED</option>
        </Select>
      </div>

      <Card className="!p-0 overflow-hidden">
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-[11px] font-display tracking-wider text-slate-500 uppercase border-b border-white/5">
                <th className="px-5 py-3.5">Job</th>
                <th className="px-5 py-3.5">User</th>
                <th className="px-5 py-3.5">Type</th>
                <th className="px-5 py-3.5 w-48">Progress</th>
                <th className="px-5 py-3.5">Status</th>
                <th className="px-5 py-3.5">Created</th>
                <th className="px-5 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {loading ? (
                <tr><td colSpan={7} className="px-5">{Array.from({ length: 5 }).map((_, i) => <SkeletonRow key={i} />)}</td></tr>
              ) : (data?.items ?? []).map((j) => (
                <tr key={j.id} className="hover:bg-white/[0.03] transition-colors">
                  <td className="px-5 py-3">
                    <p className="text-white font-medium">{j.audio?.title ?? "—"}</p>
                    <p className="text-[10px] font-mono text-slate-600">{j.id.slice(0, 12)}...</p>
                  </td>
                  <td className="px-5 py-3 text-slate-400 text-xs">{j.audio?.user?.username ?? "—"}</td>
                  <td className="px-5 py-3 font-mono text-xs text-violet-300 uppercase">{j.type}</td>
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-2">
                      <ProgressBar value={j.progress} className="flex-1" indeterminate={j.status === "PROCESSING" && j.progress === 0} />
                      <span className="font-mono text-[10px] text-slate-500 w-8">{j.progress}%</span>
                    </div>
                  </td>
                  <td className="px-5 py-3"><StatusBadge status={j.status} className="!text-[10px]" /></td>
                  <td className="px-5 py-3 text-slate-400 text-xs">{formatDate(j.createdAt)} {formatTime(j.createdAt)}</td>
                  <td className="px-5 py-3">
                    <div className="flex justify-end gap-1.5">
                      {(j.status === "FAILED" || j.status === "CANCELLED") && (
                        <button onClick={() => retry(j.id)} className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-slate-400 hover:text-emerald-300 transition-colors" title="Retry"><RefreshCw size={13} /></button>
                      )}
                      {j.status === "QUEUED" && (
                        <button onClick={() => cancel(j.id)} className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-slate-400 hover:text-rose-400 transition-colors" title="Cancel"><XCircle size={13} /></button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="md:hidden divide-y divide-white/5">
          {loading ? (
            <div className="p-4">{Array.from({ length: 4 }).map((_, i) => <SkeletonRow key={i} />)}</div>
          ) : (data?.items ?? []).map((j) => (
            <div key={j.id} className="p-4 space-y-2.5">
              <div className="flex items-center justify-between gap-2">
                <p className="text-white text-sm font-medium truncate flex-1">{j.audio?.title}</p>
                <StatusBadge status={j.status} className="!text-[9px] shrink-0" />
              </div>
              <ProgressBar value={j.progress} indeterminate={j.status === "PROCESSING" && j.progress === 0} />
              <div className="flex items-center justify-between">
                <p className="text-[11px] font-mono text-slate-500 uppercase">{j.type} · {j.progress}%</p>
                <div className="flex gap-1.5">
                  {(j.status === "FAILED" || j.status === "CANCELLED") && (
                    <button onClick={() => retry(j.id)} className="btn-ghost !py-1 text-[11px]">Retry</button>
                  )}
                  {j.status === "QUEUED" && (
                    <button onClick={() => cancel(j.id)} className="btn-ghost !py-1 text-[11px]">Cancel</button>
                  )}
                </div>
              </div>
              {j.error && <p className="text-[11px] text-rose-400">{j.error.slice(0, 120)}</p>}
            </div>
          ))}
        </div>
      </Card>

      {data && data.pages > 1 && (
        <div className="flex items-center justify-center gap-3">
          <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="btn-ghost !p-2" aria-label="Previous"><ChevronLeft size={16} /></button>
          <span className="font-mono text-sm text-slate-400">{page} / {data.pages}</span>
          <button disabled={page >= data.pages} onClick={() => setPage((p) => p + 1)} className="btn-ghost !p-2" aria-label="Next"><ChevronRight size={16} /></button>
        </div>
      )}
    </div>
  );
}
