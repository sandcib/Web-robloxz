import { useEffect, useState } from "react";
import { Settings, CheckCircle2, XCircle } from "lucide-react";
import { api } from "../lib/api";
import { Card } from "../components/ui/Card";

export default function UserSettings() {
  const [robloxConfigured, setRobloxConfigured] = useState<boolean | null>(null);

  useEffect(() => {
    api.get<{ configured: boolean }>("/api/roblox/status").then((d) => setRobloxConfigured(d.configured)).catch(() => setRobloxConfigured(null));
  }, []);

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <h1 className="font-display font-bold text-3xl text-white flex items-center gap-3">
        <Settings className="text-violet-neon" size={26} /> <span className="gradient-text">Settings</span>
      </h1>

      <Card>
        <h3 className="font-display font-semibold text-white mb-4">Integrations</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between rounded-xl bg-white/5 border border-white/10 p-4">
            <div>
              <p className="text-sm text-white font-medium">Roblox Upload API</p>
              <p className="text-xs text-slate-500 mt-0.5">อัปโหลดเสียงขึ้น Roblox และรับ Sound ID โดยตรง</p>
            </div>
            {robloxConfigured === null ? (
              <span className="text-xs text-slate-500">Checking...</span>
            ) : robloxConfigured ? (
              <span className="flex items-center gap-1.5 text-xs text-emerald-300"><CheckCircle2 size={14} /> Connected</span>
            ) : (
              <span className="flex items-center gap-1.5 text-xs text-slate-500"><XCircle size={14} /> Not configured</span>
            )}
          </div>
          <p className="text-[11px] text-slate-600">Credentials ถูกเก็บใน Environment Variables ฝั่ง server เท่านั้น — ไม่มี secret อยู่ใน frontend</p>
        </div>
      </Card>

      <Card>
        <h3 className="font-display font-semibold text-white mb-3">Keyboard Shortcuts</h3>
        <div className="grid sm:grid-cols-2 gap-2 text-sm">
          {[
            ["CTRL + K", "Open command search"],
            ["CTRL + U", "Go to upload"],
            ["SPACE", "Play / Pause"],
            ["ESC", "Close modal"],
          ].map(([k, d]) => (
            <div key={k} className="flex items-center justify-between rounded-lg bg-white/5 px-4 py-2.5">
              <span className="text-slate-400 text-xs">{d}</span>
              <kbd className="font-mono text-[11px] bg-white/10 rounded px-2 py-0.5 text-violet-300">{k}</kbd>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
