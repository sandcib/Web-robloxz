import { useEffect, useState } from "react";
import { Upload, RefreshCw, Download, Gamepad2, Trash2, Heart } from "lucide-react";
import { api } from "../lib/api";
import { formatDate, formatTime } from "../lib/utils";
import { Card } from "../components/ui/Card";
import { SkeletonRow } from "../components/ui/Skeletons";
import type { HistoryItem, Paginated } from "../types";

const ACTION_META: Record<string, { icon: typeof Upload; cls: string }> = {
  UPLOADED: { icon: Upload, cls: "text-sky-300 bg-sky-500/15 border-sky-500/30" },
  CONVERTED: { icon: RefreshCw, cls: "text-violet-300 bg-violet-500/15 border-violet-500/30" },
  DOWNLOADED: { icon: Download, cls: "text-emerald-300 bg-emerald-500/15 border-emerald-500/30" },
  ROBLOX_UPLOADED: { icon: Gamepad2, cls: "text-fuchsia-300 bg-fuchsia-500/15 border-fuchsia-500/30" },
  DELETED: { icon: Trash2, cls: "text-rose-300 bg-rose-500/15 border-rose-500/30" },
  FAVORITED: { icon: Heart, cls: "text-magenta bg-magenta/15 border-magenta/30" },
};

export default function HistoryPage() {
  const [data, setData] = useState<Paginated<HistoryItem> | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get<Paginated<HistoryItem>>("/api/history?limit=60")
      .then(setData)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const groups = new Map<string, HistoryItem[]>();
  (data?.items ?? []).forEach((h) => {
    const d = formatDate(h.createdAt);
    if (!groups.has(d)) groups.set(d, []);
    groups.get(d)!.push(h);
  });

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="font-display font-bold text-3xl text-white">Activity <span className="gradient-text">History</span></h1>
        <p className="text-slate-500 mt-1 text-sm">ประวัติการอัปโหลด แปลงไฟล์ ดาวน์โหลด และอื่น ๆ</p>
      </div>

      {loading ? (
        <Card>{Array.from({ length: 5 }).map((_, i) => <SkeletonRow key={i} />)}</Card>
      ) : groups.size === 0 ? (
        <Card className="text-center py-14"><p className="text-slate-500">ยังไม่มีประวัติการใช้งาน</p></Card>
      ) : (
        [...groups.entries()].map(([date, items]) => (
          <div key={date}>
            <p className="font-display text-xs tracking-[0.25em] text-slate-500 uppercase mb-3">{date}</p>
            <Card className="divide-y divide-white/5 !p-0 overflow-hidden">
              {items.map((h) => {
                const meta = ACTION_META[h.action] ?? ACTION_META.UPLOADED;
                return (
                  <div key={h.id} className="flex items-center gap-4 px-5 py-3.5 hover:bg-white/[0.03] transition-colors">
                    <span className={`w-9 h-9 rounded-xl border flex items-center justify-center shrink-0 ${meta.cls}`}>
                      <meta.icon size={15} />
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-white capitalize">{h.action.toLowerCase().replace(/_/g, " ")} {h.target ? <span className="text-slate-400">— {h.target}</span> : null}</p>
                    </div>
                    <span className="font-mono text-xs text-slate-500 shrink-0">{formatTime(h.createdAt)}</span>
                  </div>
                );
              })}
            </Card>
          </div>
        ))
      )}
    </div>
  );
}
