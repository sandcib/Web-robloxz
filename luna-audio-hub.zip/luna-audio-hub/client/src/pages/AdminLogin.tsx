import { useState, type FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ShieldCheck, Lock, Mail } from "lucide-react";
import { useAuth } from "../contexts/AuthContext";
import { useToast } from "../contexts/ToastContext";
import { BackgroundScene } from "../components/layout/BackgroundScene";
import { Button } from "../components/ui/Button";
import { Input } from "../components/ui/Input";

export default function AdminLogin() {
  const { login } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(true);
  const [loading, setLoading] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const user = await login(email, password);
      if (user.role === "USER") {
        toast("error", "Access denied — admin privileges required");
        return;
      }
      toast("success", `Welcome, ${user.username}`);
      navigate("/admin", { replace: true });
    } catch (err) {
      toast("error", (err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 relative">
      <BackgroundScene />
      <div className="blob w-[500px] h-[500px] top-1/4 left-1/4" style={{ background: "radial-gradient(circle, rgba(217,70,239,0.25), transparent 65%)" }} />
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="w-full max-w-sm relative">
        <div className="text-center mb-8">
          <motion.div
            animate={{ boxShadow: ["0 0 30px rgba(217,70,239,0.4)", "0 0 60px rgba(217,70,239,0.7)", "0 0 30px rgba(217,70,239,0.4)"] }}
            transition={{ repeat: Infinity, duration: 3 }}
            className="inline-flex w-16 h-16 rounded-2xl bg-gradient-to-br from-magenta/30 to-violet-neon/20 border border-magenta/40 items-center justify-center"
          >
            <ShieldCheck size={30} className="text-magenta" />
          </motion.div>
          <h1 className="font-display font-bold text-2xl text-white tracking-[0.2em] mt-5">ADMIN</h1>
          <p className="font-display text-xs tracking-[0.4em] text-magenta/80 mt-1">CONTROL CENTER</p>
        </div>

        <div className="glass-strong rounded-3xl p-8 border-magenta/20">
          <form onSubmit={submit} className="space-y-4">
            <div className="relative">
              <Mail size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
              <Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Admin Email" className="!pl-11" />
            </div>
            <div className="relative">
              <Lock size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
              <Input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" className="!pl-11" />
            </div>
            <label className="flex items-center gap-2 text-xs text-slate-400 cursor-pointer select-none">
              <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} className="accent-violet-neon" />
              Remember session
            </label>
            <Button type="submit" loading={loading} className="w-full !from-magenta !to-violet-neon">
              LOGIN
            </Button>
          </form>
          <p className="text-center text-[11px] text-slate-600 mt-5 font-mono tracking-wider">
            AUTHORIZED PERSONNEL ONLY · ATTEMPTS LOGGED
          </p>
        </div>
      </motion.div>
    </div>
  );
}
