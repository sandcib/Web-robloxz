import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Home, ShieldAlert, ServerCrash, WifiOff } from "lucide-react";
import { BackgroundScene } from "../components/layout/BackgroundScene";

const CONTENT = {
  403: { icon: ShieldAlert, title: "ACCESS DENIED", sub: "คุณไม่มีสิทธิ์เข้าถึงหน้านี้", desc: "This area requires elevated permissions. Contact an administrator if you believe this is a mistake." },
  404: { icon: WifiOff, title: "SIGNAL LOST", sub: "ไม่พบหน้าที่คุณต้องการ", desc: "The page you're looking for doesn't exist or may have been moved." },
  500: { icon: ServerCrash, title: "SYSTEM FAULT", sub: "เกิดข้อผิดพลาดภายในระบบ", desc: "Something went wrong on our end. Our team has been notified." },
} as const;

export function ErrorPage({ code }: { code: 403 | 404 | 500 }) {
  const c = CONTENT[code];
  return (
    <div className="min-h-screen flex items-center justify-center px-4 relative">
      <BackgroundScene />
      <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} className="text-center relative">
        <p className="font-display font-bold text-[8rem] md:text-[11rem] leading-none gradient-text opacity-90 select-none">{code}</p>
        <div className="inline-flex w-14 h-14 rounded-2xl bg-white/5 border border-white/10 items-center justify-center -mt-6 relative z-10">
          <c.icon size={26} className="text-violet-300" />
        </div>
        <h1 className="font-display font-bold text-2xl text-white tracking-[0.2em] mt-5">{c.title}</h1>
        <p className="text-slate-400 mt-2">{c.sub}</p>
        <p className="text-sm text-slate-600 mt-1 max-w-sm mx-auto">{c.desc}</p>
        <Link to="/" className="btn-primary mt-8 inline-flex"><Home size={16} /> BACK HOME</Link>
      </motion.div>
    </div>
  );
}

export default ErrorPage;
