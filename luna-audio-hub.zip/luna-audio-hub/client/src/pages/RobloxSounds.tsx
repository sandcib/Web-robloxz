import { useEffect, useState } from "react";
import { Gamepad2, Copy, Settings2, CheckCircle2 } from "lucide-react";
import { api } from "../lib/api";
import { useToast } from "../contexts/ToastContext";
import { formatDate, formatDuration } from "../lib/utils";
import { Card } from "../components/ui/Card";
import { StatusBadge } from "../components/ui/StatusBadge";
import { SkeletonCard } from "../components/ui/Skeletons";
import { Waveform } from "../components/audio/Waveform";
import { Link } from "react-router-dom";

interface Asset {
  id: string; assetId: string | null; status: string; error: string | null; createdAt: string;
  audio: { id: string; title: string; coverUrl: string | null; duration: number; format: string; soundId: string | null };
}

export default function RobloxSounds() {
  const { toast } = useToast();
  const [configured, setConfigured] = useState<boolean | null>(null);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [st, list] = await Promise.all([
          api.get<{ configured: boolean }>("/api/roblox/status"),
          api.get<{ items: Asset[] }>("/api/roblox/assets"),
        ]);
        setConfigured(st.configured);
        setAssets(list.items);
      } catch {
        toast("error", "Failed to load Roblox data");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const copyId = async (id: string) => {
    await navigator.clipboard.writeText(id).catch(() => {});
    toast("success", "Sound ID copied");
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display font-bold text-3xl text-white flex items-center gap-3">
          <Gamepad2 className="text-violet-neon" size={30} /> Roblox <span className="gradient-text">Audio</span>
        </h1>
        <p className="text-slate-500 mt-1 text-sm">เสียงที่เตรียมพร้อมสำหรับการใช้งานใน Roblox พร้อม Sound ID</p>
      </div>

      {configured === false && (
        <div className="glass rounded-2xl p-6 border-amber-500/30 flex flex-wrap items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center shrink-0">
            <Settings2 size={22} className="text-amber-300" />
          </div>
          <div className="flex-1 min-w-[220px]">
            <p className="font-display font-semibold text-white">Roblox upload integration is not configured</p>
            <p className="text-sm text-slate-500 mt-1">ตั้งค่า ROBLOX_API_KEY, ROBLOX_CLIENT_ID, ROBLOX_CLIENT_SECRET ใน Environment Variables เพื่อเปิดใช้งาน</p>
          </div>
          <Link to="/settings" className="btn-ghost text-sm"><Settings2 size={15} /> ตั้งค่า API</Link>
        </div>
      )}

      {configured && (
        <div className="flex items-center gap-2 text-xs text-emerald-300 bg-emerald-500/10 border border-emerald-500/25 rounded-xl p-3 w-fit">
          <CheckCircle2 size={14} /> Roblox API connected
        </div>
      )}

      {loading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 3 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      ) : assets.length === 0 ? (
        <Card className="text-center py-16">
          <Gamepad2 size={32} className="text-slate-600 mx-auto" />
          <p className="text-slate-400 mt-3">ยังไม่มีเสียงที่อัปโหลดขึ้น Roblox</p>
        </Card>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {assets.map((a) => (
            <Card key={a.id} className="overflow-hidden !p-0">
              <div className="h-32 bg-gradient-to-br from-deep to-abyss flex items-center justify-center relative">
                {a.audio.coverUrl ? (
                  <img src={a.audio.coverUrl} alt="" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full opacity-50"><Waveform bars={36} /></div>
                )}
                <div className="absolute top-3 right-3"><StatusBadge status={a.status === "UPLOADED" ? "UPLOADED" : a.status} /></div>
              </div>
              <div className="p-4">
                <h3 className="font-display font-semibold text-white truncate">{a.audio.title}</h3>
                <p className="text-[11px] text-slate-500 mt-1 font-display uppercase tracking-wider">
                  {formatDuration(a.audio.duration)} · {a.audio.format.toUpperCase()} · {formatDate(a.createdAt)}
                </p>
                <div className="mt-3 flex items-center gap-2">
                  <code className="flex-1 font-mono text-xs bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-violet-300 truncate">
                    {a.assetId ?? a.audio.soundId ?? "PENDING"}
                  </code>
                  <button
                    onClick={() => copyId(a.assetId ?? a.audio.soundId ?? "")}
                    disabled={!a.assetId && !a.audio.soundId}
                    className="btn-ghost !p-2.5"
                    aria-label="Copy sound ID"
                  >
                    <Copy size={14} />
                  </button>
                </div>
                {a.error && <p className="text-[11px] text-rose-400 mt-2">{a.error}</p>}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
