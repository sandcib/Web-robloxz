import { useCallback, useEffect, useState } from "react";
import { Heart } from "lucide-react";
import { api } from "../lib/api";
import { AudioCard } from "../components/audio/AudioCard";
import { SkeletonCard } from "../components/ui/Skeletons";
import { Card } from "../components/ui/Card";
import type { Audio, Paginated } from "../types";

export default function Favorites() {
  const [data, setData] = useState<Paginated<Audio> | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setData(await api.get<Paginated<Audio>>("/api/audio?favorites=true&limit=24"));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display font-bold text-3xl text-white flex items-center gap-3">
          <Heart className="text-magenta" size={28} /> <span className="gradient-text">Favorites</span>
        </h1>
        <p className="text-slate-500 mt-1 text-sm">เสียงที่คุณกดหัวใจไว้</p>
      </div>

      {loading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      ) : !data || data.items.length === 0 ? (
        <Card className="text-center py-16">
          <Heart size={32} className="text-slate-600 mx-auto" />
          <p className="text-slate-400 mt-3">ยังไม่มีรายการโปรด — กดหัวใจบนเสียงที่คุณชอบ</p>
        </Card>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {data.items.map((a) => <AudioCard key={a.id} audio={a} onChanged={load} />)}
        </div>
      )}
    </div>
  );
}
