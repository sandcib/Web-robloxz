import { useState, type FormEvent } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { Mail, Lock, LogIn } from "lucide-react";
import { useAuth } from "../contexts/AuthContext";
import { useToast } from "../contexts/ToastContext";
import { BackgroundScene } from "../components/layout/BackgroundScene";
import { Logo } from "../components/layout/Logo";
import { Button } from "../components/ui/Button";
import { Input } from "../components/ui/Input";

export default function Login() {
  const { login } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation() as { state?: { from?: { pathname?: string } } };
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const user = await login(email, password);
      toast("success", `Welcome back, ${user.username}`);
      navigate(location.state?.from?.pathname || "/dashboard", { replace: true });
    } catch (err) {
      toast("error", (err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 relative">
      <BackgroundScene />
      <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="w-full max-w-md">
        <div className="flex justify-center mb-8"><Logo to="/" /></div>
        <div className="glass-strong neon-border rounded-3xl p-8">
          <h1 className="font-display font-bold text-2xl text-white text-center">ยินดีต้อนรับกลับ</h1>
          <p className="text-sm text-slate-500 text-center mt-2">เข้าสู่ระบบเพื่อจัดการคลังเสียงของคุณ</p>

          <form onSubmit={submit} className="mt-8 space-y-4">
            <div className="relative">
              <Mail size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
              <Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" className="!pl-11" autoComplete="email" />
            </div>
            <div className="relative">
              <Lock size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
              <Input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" className="!pl-11" autoComplete="current-password" />
            </div>
            <Button type="submit" loading={loading} className="w-full">
              <LogIn size={16} /> Login
            </Button>
          </form>

          <p className="text-center text-sm text-slate-500 mt-6">
            ยังไม่มีบัญชี?{" "}
            <Link to="/register" className="text-violet-300 hover:text-white font-medium transition-colors">สมัครสมาชิก</Link>
          </p>
          <p className="text-center text-xs text-slate-600 mt-4">
            Admin? <Link to="/admin/login" className="text-magenta/70 hover:text-magenta transition-colors">Admin Control Center →</Link>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
