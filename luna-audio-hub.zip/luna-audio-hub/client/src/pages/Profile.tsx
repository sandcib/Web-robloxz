import { useState, type FormEvent } from "react";
import { Camera, KeyRound, User as UserIcon } from "lucide-react";
import { useAuth } from "../contexts/AuthContext";
import { useToast } from "../contexts/ToastContext";
import { api } from "../lib/api";
import { formatBytes, formatDate } from "../lib/utils";
import { Card } from "../components/ui/Card";
import { Button } from "../components/ui/Button";
import { Input } from "../components/ui/Input";

export default function Profile() {
  const { user, refresh } = useAuth();
  const { toast } = useToast();
  const [username, setUsername] = useState(user?.username ?? "");
  const [pw, setPw] = useState({ current: "", next: "", confirm: "" });
  const [saving, setSaving] = useState(false);
  const [savingPw, setSavingPw] = useState(false);

  const saveProfile = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.patch("/api/user/me", { username });
      await refresh();
      toast("success", "Profile updated");
    } catch (err) {
      toast("error", (err as Error).message);
    } finally {
      setSaving(false);
    }
  };

  const savePassword = async (e: FormEvent) => {
    e.preventDefault();
    if (pw.next !== pw.confirm) return toast("warning", "Passwords do not match");
    setSavingPw(true);
    try {
      await api.patch("/api/user/me", { currentPassword: pw.current, newPassword: pw.next });
      toast("success", "Password changed — please log in again");
      setTimeout(() => window.location.href = "/login", 1200);
    } catch (err) {
      toast("error", (err as Error).message);
    } finally {
      setSavingPw(false);
    }
  };

  const uploadAvatar = async (f: File | undefined) => {
    if (!f) return;
    if (!["image/png", "image/jpeg", "image/webp"].includes(f.type)) return toast("warning", "รองรับเฉพาะ PNG, JPG, WEBP");
    if (f.size > 5 * 1024 * 1024) return toast("warning", "รูปต้องไม่เกิน 5MB");
    try {
      const form = new FormData();
      form.append("file", f);
      const { coverUrl } = await api.upload<{ coverUrl: string }>("/api/audio/upload", form);
      await api.patch("/api/user/me", { avatarUrl: coverUrl });
      await refresh();
      toast("success", "Avatar updated");
    } catch (err) {
      toast("error", (err as Error).message);
    }
  };

  if (!user) return null;

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <h1 className="font-display font-bold text-3xl text-white">My <span className="gradient-text">Profile</span></h1>

      <Card glow className="flex flex-wrap items-center gap-6">
        <label className="relative group cursor-pointer" role="button" tabIndex={0}>
          <input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(e) => uploadAvatar(e.target.files?.[0] ?? undefined)} />
          <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-violet-neon to-magenta flex items-center justify-center font-display font-bold text-3xl text-white overflow-hidden relative">
            {user.avatarUrl ? <img src={user.avatarUrl} alt="Avatar" className="w-full h-full object-cover" /> : user.username[0].toUpperCase()}
            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <Camera size={20} className="text-white" />
            </div>
          </div>
        </label>
        <div className="flex-1 min-w-[200px]">
          <h2 className="font-display font-bold text-2xl text-white">{user.username}</h2>
          <p className="text-sm text-slate-500">{user.email}</p>
          <div className="flex flex-wrap gap-5 mt-4 text-sm">
            <span className="text-slate-400">Account created: <span className="text-white font-display">{formatDate(user.createdAt)}</span></span>
            <span className="text-slate-400">Total sounds: <span className="text-white font-display">{user.totalSounds ?? 0}</span></span>
            <span className="text-slate-400">Storage: <span className="text-white font-display">{formatBytes(user.storageUsed ?? 0)}</span></span>
          </div>
        </div>
        <span className="px-3 py-1.5 rounded-full bg-violet-neon/15 border border-violet-neon/40 text-violet-300 text-xs font-display font-semibold uppercase tracking-wider">
          {user.role}
        </span>
      </Card>

      <Card>
        <h3 className="font-display font-semibold text-white mb-4 flex items-center gap-2"><UserIcon size={17} className="text-violet-300" /> Profile Settings</h3>
        <form onSubmit={saveProfile} className="flex flex-wrap gap-3">
          <Input value={username} onChange={(e) => setUsername(e.target.value)} className="flex-1 min-w-[200px]" placeholder="Username" />
          <Button type="submit" loading={saving}>Save Changes</Button>
        </form>
      </Card>

      <Card>
        <h3 className="font-display font-semibold text-white mb-4 flex items-center gap-2"><KeyRound size={17} className="text-violet-300" /> Change Password</h3>
        <form onSubmit={savePassword} className="grid sm:grid-cols-3 gap-3">
          <Input type="password" required value={pw.current} onChange={(e) => setPw((p) => ({ ...p, current: e.target.value }))} placeholder="Current password" />
          <Input type="password" required minLength={8} value={pw.next} onChange={(e) => setPw((p) => ({ ...p, next: e.target.value }))} placeholder="New password" />
          <Input type="password" required value={pw.confirm} onChange={(e) => setPw((p) => ({ ...p, confirm: e.target.value }))} placeholder="Confirm new password" />
          <div className="sm:col-span-3">
            <Button type="submit" loading={savingPw} variant="ghost">Update Password</Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
