import { useState } from "react";
import { Youtube, Link2, Clock, AlertTriangle, Plus, ListMusic } from "lucide-react";
import { api } from "../lib/api";
import { useToast } from "../contexts/ToastContext";
import { formatDuration, timecode } from "../lib/utils";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { Input } from "../components/ui/Input";

interface VideoInfo {
  title: string; channel: string; thumbnail: string; duration: number; valid: boolean; warning: string;
}

interface QueueItem { url: string; info: VideoInfo; start: number; end: number; title: string; }

export default function YouTubeImport() {
  const { toast } = useToast();
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [info, setInfo] = useState<VideoInfo | null>(null);
  const [start, setStart] = useState(0);
  const [end, setEnd] = useState(0);
  const [queue, setQueue] = useState<QueueItem[]>([]);
  const [importing, setImporting] = useState(false);

  const validate = async () => {
    setLoading(true);
    setInfo(null);
    try {
      const data = await api.post<VideoInfo>("/api/youtube/validate", { url });
      setInfo(data);
      setEnd(data.duration || 0);
      toast("success", "Video validated");
    } catch (e) {
      toast("error", (e as Error).message);
    } finally {
      setLoading(false);
    }
  };

  const addToQueue = () => {
    if (!info) return;
    if (end <= start) return toast("warning", "End time must be after start time");
    if (end - start > 600) return toast("warning", "Selected range exceeds maximum duration (10 minutes)");
    setQueue((q) => [...q, { url, info, start, end: end || info.duration, title: info.title }]);
    setInfo(null);
    setUrl("");
    toast("success", "Added to queue");
  };

  const importAll = async () => {
    setImporting(true);
    let ok = 0;
    for (const item of queue) {
      try {
        await api.post("/api/youtube/import", { url: item.url, title: item.title, trimStart: item.start, trimEnd: item.end });
        ok++;
      } catch (e) {
        toast("error", `${item.title}: ${(e as Error).message}`);
      }
    }
    setImporting(false);
    setQueue([]);
    toast(ok === queue.length ? "success" : "warning", `Imported ${ok}/${queue.length} item(s)`);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="font-display font-bold text-3xl text-white flex items-center gap-3">
          <Youtube className="text-rose-500" size={30} /> YouTube <span className="gradient-text">→ Audio</span>
        </h1>
        <p className="text-slate-500 mt-1 text-sm">วาง YouTube URL เพื่อดึงข้อมูลวิดีโอ เลือกช่วงเวลา และนำเข้าเป็นไฟล์เสียง</p>
      </div>

      <div className="flex items-start gap-2.5 text-xs text-amber-200/80 bg-amber-500/10 border border-amber-500/25 rounded-xl p-3.5">
        <AlertTriangle size={15} className="shrink-0 mt-0.5" />
        <p><strong>ข้อควรระวัง:</strong> ใช้เฉพาะคอนเทนต์ที่คุณเป็นเจ้าของหรือได้รับอนุญาตให้ดาวน์โหลด/แปลงเท่านั้น — การดาวน์โหลดคอนเทนต์ที่ไม่มีสิทธิ์อาจละเมิดเงื่อนไขการใช้งานและกฎหมายลิขสิทธิ์</p>
      </div>

      <Card glow>
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Link2 size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
            <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://www.youtube.com/watch?v=..." className="!pl-11" />
          </div>
          <Button onClick={validate} loading={loading} disabled={!url.trim()}>Validate</Button>
        </div>

        {info && (
          <div className="mt-6 grid sm:grid-cols-[200px_1fr] gap-5">
            <div className="rounded-xl overflow-hidden border border-white/10 aspect-video">
              <img src={info.thumbnail} alt={info.title} className="w-full h-full object-cover" />
            </div>
            <div className="space-y-4">
              <div>
                <h3 className="font-display font-semibold text-white">{info.title}</h3>
                <p className="text-xs text-slate-500 mt-1 flex items-center gap-1.5"><Clock size={12} /> {info.channel} · {formatDuration(info.duration)}</p>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-display tracking-[0.2em] text-slate-500 uppercase">Start</label>
                  <Input className="mt-1 font-mono" value={timecode(start)} onChange={(e) => {
                    const p = e.target.value.split(":").map(Number);
                    setStart(p.length === 3 ? p[0] * 3600 + p[1] * 60 + p[2] : p[0] * 60 + (p[1] || 0));
                  }} />
                </div>
                <div>
                  <label className="text-[10px] font-display tracking-[0.2em] text-slate-500 uppercase">End</label>
                  <Input className="mt-1 font-mono" value={timecode(end)} onChange={(e) => {
                    const p = e.target.value.split(":").map(Number);
                    setEnd(p.length === 3 ? p[0] * 3600 + p[1] * 60 + p[2] : p[0] * 60 + (p[1] || 0));
                  }} />
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button variant="ghost" onClick={() => { setStart(0); setEnd(info.duration); }}>USE FULL AUDIO</Button>
                <Button onClick={addToQueue}><Plus size={15} /> Add to Queue</Button>
              </div>
            </div>
          </div>
        )}
      </Card>

      {queue.length > 0 && (
        <Card>
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-semibold text-white flex items-center gap-2"><ListMusic size={17} className="text-violet-300" /> Import Queue ({queue.length})</h2>
            <Button onClick={importAll} loading={importing}>Import All</Button>
          </div>
          <div className="space-y-2">
            {queue.map((item, i) => (
              <div key={i} className="flex items-center gap-3 rounded-xl bg-white/5 border border-white/10 p-3">
                <img src={item.info.thumbnail} alt="" className="w-20 rounded-lg aspect-video object-cover" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-white truncate">{item.title}</p>
                  <p className="text-[11px] font-mono text-slate-500">{timecode(item.start)} → {timecode(item.end)}</p>
                </div>
                <button onClick={() => setQueue((q) => q.filter((_, x) => x !== i))} className="text-slate-500 hover:text-rose-400 transition-colors" aria-label="Remove">✕</button>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
