import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Upload, Music, Zap, Shield, Gamepad2, ChevronDown, AudioWaveform, Layers } from "lucide-react";
import { BackgroundScene } from "../components/layout/BackgroundScene";
import { Logo } from "../components/layout/Logo";
import { Waveform } from "../components/audio/Waveform";
import { useAuth } from "../contexts/AuthContext";

const FEATURES = [
  { icon: Upload, title: "อัปโหลดไม่จำกัดรูปแบบ", desc: "รองรับ MP3, WAV, OGG, M4A พร้อมระบบตรวจสอบไฟล์อัตโนมัติ" },
  { icon: AudioWaveform, title: "ประมวลผลระดับสตูดิโอ", desc: "Convert, Normalize, Trim ด้วย FFmpeg พร้อม Queue จริงและ progress แบบ realtime" },
  { icon: Gamepad2, title: "Roblox Ready", desc: "เตรียมไฟล์ให้พร้อมใช้งานใน Roblox พร้อม Sound ID management" },
  { icon: Shield, title: "ปลอดภัยระดับองค์กร", desc: "Password hashing, rate limiting, permission system และ audit log" },
];

const FAQS = [
  { q: "รองรับไฟล์เสียงแบบใดบ้าง?", a: "รองรับ MP3, WAV, OGG และ M4A สูงสุด 50MB ต่อไฟล์ และสามารถแปลงเป็นรูปแบบอื่นได้ภายในแพลตฟอร์ม" },
  { q: "อัปโหลดไป Roblox ได้เลยหรือไม่?", a: "หากตั้งค่า Roblox API credentials ในระบบแล้ว คุณสามารถอัปโหลดและรับ Sound ID กลับมาได้ทันที หากยังไม่ได้ตั้งค่า ระบบจะแจ้งสถานะอย่างชัดเจน" },
  { q: "ใช้ YouTube Import อย่างไรให้ถูกต้อง?", a: "ใช้เฉพาะคอนเทนต์ที่คุณเป็นเจ้าของหรือได้รับอนุญาตให้ดาวน์โหลด/แปลงเท่านั้น ระบบมีข้อความแจ้งเตือนในทุกขั้นตอน" },
  { q: "มีระบบ Admin หรือไม่?", a: "มีระบบ Admin Control Center ครบถ้วน ทั้งการจัดการผู้ใช้ ไฟล์เสียง คิวประมวลผล ระบบ log และการตั้งค่าระบบ" },
];

export default function Landing() {
  const { user } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen relative">
      <BackgroundScene />

      {/* NAV */}
      <nav className="fixed top-0 inset-x-0 z-50 px-4 py-4">
        <div className="max-w-6xl mx-auto glass rounded-2xl px-5 py-3 flex items-center justify-between">
          <Logo />
          <div className="flex items-center gap-2">
            {user ? (
              <Link to="/dashboard" className="btn-primary !py-2 text-sm">เข้า Dashboard</Link>
            ) : (
              <>
                <Link to="/login" className="btn-ghost !py-2 text-sm hidden sm:inline-flex">Login</Link>
                <Link to="/register" className="btn-primary !py-2 text-sm">เริ่มต้นใช้งาน</Link>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* HERO */}
      <section className="relative pt-40 pb-24 px-4 overflow-hidden">
        <div className="light-streak" />
        <div className="max-w-6xl mx-auto grid lg:grid-cols-2 gap-14 items-center">
          <motion.div initial={{ opacity: 0, x: -32 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.7 }}>
            <div className="inline-flex items-center gap-2 rounded-full border border-violet-neon/30 bg-violet-neon/10 px-4 py-1.5 text-xs font-display text-violet-300 tracking-wider mb-6">
              <Zap size={13} /> PREMIUM AUDIO PLATFORM
            </div>
            <h1 className="font-display font-bold text-5xl md:text-6xl leading-[1.1] text-white">
              เสียงของคุณ<br />
              <span className="gradient-text">พร้อมใช้งานใน Roblox</span>
            </h1>
            <p className="mt-6 text-slate-400 text-lg leading-relaxed max-w-lg">
              อัปโหลดเสียง จัดการไฟล์ เตรียมไฟล์สำหรับ Roblox
              และจัดการคลังเสียงของคุณในที่เดียว
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <button onClick={() => navigate(user ? "/upload" : "/register")} className="btn-primary">
                <Upload size={17} /> เริ่มต้นใช้งาน
              </button>
              <button onClick={() => navigate(user ? "/upload" : "/register")} className="btn-ghost">
                <Music size={17} /> อัปโหลดเสียง
              </button>
            </div>
            <div className="mt-10 flex gap-8 font-display">
              {[["128K+", "ACTIVE SOUNDS"], ["99.9%", "UPTIME"], ["4", "FORMATS"]].map(([v, l]) => (
                <div key={l}>
                  <p className="text-2xl font-bold gradient-text">{v}</p>
                  <p className="text-[10px] tracking-[0.2em] text-slate-500 mt-1">{l}</p>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Visualizer panel + floating cards */}
          <motion.div initial={{ opacity: 0, x: 32 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.7, delay: 0.15 }} className="relative">
            <div className="glass-strong neon-border rounded-3xl p-8 relative overflow-hidden">
              <div className="light-streak" />
              <div className="flex items-center justify-between mb-6">
                <span className="text-xs font-display tracking-[0.25em] text-violet-300/80">NOW MONITORING</span>
                <span className="flex items-center gap-1.5 text-xs text-emerald-300"><span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" /> LIVE</span>
              </div>
              <div className="h-48"><Waveform playing bars={64} /></div>
              <div className="mt-6 flex items-end justify-between font-mono text-xs text-slate-500">
                <span>SPECTRUM · 20Hz–20kHz</span>
                <span className="text-violet-300">-6.4dB</span>
              </div>
            </div>

            {[
              { label: "AUDIO READY", value: "128 KBPS", cls: "-left-4 top-8 animate-float", delay: 0 },
              { label: "ROBLOX READY", value: "✓ VERIFIED", cls: "-right-3 top-1/3 animate-float-slow", delay: 0.5 },
              { label: "ACTIVE SOUNDS", value: "128", cls: "-left-6 bottom-10 animate-float", delay: 1 },
            ].map((c) => (
              <motion.div
                key={c.label}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.6 + c.delay, type: "spring" }}
                className={`absolute ${c.cls} glass neon-border rounded-xl px-4 py-3 shadow-xl`}
              >
                <p className="text-[9px] font-display tracking-[0.2em] text-slate-500">{c.label}</p>
                <p className="font-display font-bold text-white text-sm mt-0.5">{c.value}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* FEATURES */}
      <section className="px-4 py-20">
        <div className="max-w-6xl mx-auto">
          <h2 className="font-display font-bold text-3xl md:text-4xl text-white text-center">ทุกอย่างที่คุณต้องการ<span className="gradient-text">ในที่เดียว</span></h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mt-12">
            {FEATURES.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className="glass neon-border rounded-2xl p-6 hover:shadow-[0_0_40px_rgba(139,92,246,0.2)] transition-shadow"
              >
                <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-violet-neon/25 to-magenta/15 border border-violet-neon/30 flex items-center justify-center text-violet-300">
                  <f.icon size={20} />
                </div>
                <h3 className="font-display font-semibold text-white mt-4">{f.title}</h3>
                <p className="text-sm text-slate-400 mt-2 leading-relaxed">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="px-4 py-20">
        <div className="max-w-4xl mx-auto">
          <h2 className="font-display font-bold text-3xl text-white text-center">How It <span className="gradient-text">Works</span></h2>
          <div className="mt-12 space-y-4">
            {[
              { n: "01", t: "อัปโหลดไฟล์เสียง", d: "ลากไฟล์เข้ามาหรือเลือกจากเครื่อง รองรับ MP3, WAV, OGG, M4A พร้อมใส่ชื่อ คำอธิบาย หมวดหมู่ และรูป Cover" },
              { n: "02", t: "ประมวลผลอัตโนมัติ", d: "ระบบ Queue ประมวลผลด้วย FFmpeg ตามการตั้งค่าของคุณ — bitrate, format, normalize, trim" },
              { n: "03", t: "พร้อมใช้งานใน Roblox", d: "เมื่อสถานะ READY คุณสามารถดาวน์โหลดหรืออัปโหลดขึ้น Roblox เพื่อรับ Sound ID" },
            ].map((s, i) => (
              <motion.div
                key={s.n}
                initial={{ opacity: 0, x: i % 2 ? 32 : -32 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="glass rounded-2xl p-6 flex gap-5 items-start"
              >
                <span className="font-display font-bold text-3xl gradient-text shrink-0">{s.n}</span>
                <div>
                  <h3 className="font-display font-semibold text-white">{s.t}</h3>
                  <p className="text-sm text-slate-400 mt-1">{s.d}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FORMATS */}
      <section className="px-4 py-16">
        <div className="max-w-4xl mx-auto glass-strong neon-border rounded-3xl p-10 text-center relative overflow-hidden">
          <div className="light-streak" />
          <h2 className="font-display font-bold text-2xl text-white">Supported <span className="gradient-text">Formats</span></h2>
          <div className="mt-8 flex flex-wrap justify-center gap-4 font-display">
            {["MP3", "OGG", "WAV", "M4A"].map((f) => (
              <span key={f} className="px-6 py-3 rounded-xl bg-white/5 border border-violet-neon/25 text-white font-bold tracking-widest text-sm shadow-[0_0_20px_rgba(139,92,246,0.15)]">{f}</span>
            ))}
          </div>
          <p className="mt-6 text-sm text-slate-500 flex items-center justify-center gap-2"><Layers size={14} /> Bitrate: 128 · 192 · 256 · 320 kbps</p>
        </div>
      </section>

      {/* FAQ */}
      <section className="px-4 py-20">
        <div className="max-w-3xl mx-auto">
          <h2 className="font-display font-bold text-3xl text-white text-center">คำถามที่พบบ่อย</h2>
          <div className="mt-10 space-y-3">
            {FAQS.map((f) => (
              <details key={f.q} className="glass rounded-2xl group">
                <summary className="flex items-center justify-between cursor-pointer px-6 py-4 font-medium text-white list-none">
                  {f.q}
                  <ChevronDown size={16} className="text-violet-300 transition-transform group-open:rotate-180" />
                </summary>
                <p className="px-6 pb-5 text-sm text-slate-400 leading-relaxed">{f.a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-white/5 px-4 py-12 mt-10">
        <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-10">
          <div>
            <Logo />
            <p className="text-sm text-slate-500 mt-4">Audio management platform — เตรียมเสียงให้พร้อมใช้งานใน Roblox</p>
            <p className="mt-4 inline-flex items-center gap-2 text-xs text-emerald-300">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" /> System Status: OPERATIONAL
            </p>
          </div>
          <div className="text-sm">
            <p className="font-display font-semibold text-white mb-4">Links</p>
            <div className="grid grid-cols-2 gap-2 text-slate-400">
              {[["Home", "/"], ["Upload", "/upload"], ["Sounds", "/sounds"], ["Documentation", "#"], ["Privacy", "#"], ["Terms", "#"], ["Discord", "#"]].map(([l, to]) => (
                <Link key={l} to={to} className="hover:text-violet-300 transition-colors">{l}</Link>
              ))}
            </div>
          </div>
          <div className="text-sm text-slate-500">
            <p className="font-display font-semibold text-white mb-4">LUNA AUDIO HUB</p>
            <p>Built for creators. Processed with FFmpeg. Secured end-to-end.</p>
            <p className="mt-4 font-mono text-xs text-slate-600">© 2026 LUNA AUDIO HUB</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
