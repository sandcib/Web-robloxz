import { useCallback, useEffect, useState } from "react";
import { Search, SlidersHorizontal, ChevronLeft, ChevronRight } from "lucide-react";
import { api } from "../lib/api";
import { AudioCard } from "../components/audio/AudioCard";
import { SkeletonCard } from "../components/ui/Skeletons";
import { Card } from "../components/ui/Card";
import { Input, Select } from "../components/ui/Input";
import type { Audio, Paginated } from "../types";

const FILTERS = ["all", "ready", "processing", "failed", "favorites"] as const;
const SORTS = [
  { value: "newest", label: "Newest" },
  { value: "oldest", label: "Oldest" },
  { value: "name", label: "Name" },
  { value: "duration", label: "Duration" },
] as const;

export default function MySounds() {
  const [data, setData] = useState<Paginated<Audio> | null>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("all");
  const [sort, setSort] = useState<(typeof SORTS)[number]["value"]>("newest");
  const [page, setPage] = useState(1);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(page), limit: "12", sort });
      if (search.trim()) params.set("search", search.trim());
      if (filter === "favorites") params.set("favorites", "true");
      else if (filter !== "all") params.set("status", filter.toUpperCase());
      const res = await api.get<Paginated<Audio>>(`/api/audio?${params}`);
      setData(res);
    } finally {
      setLoading(false);
    }
  }, [page, search, filter, sort]);

  useEffect(() => {
    const t = setTimeout(load, search ? 300 : 0); // debounce search
    return () => clearTimeout(t);
  }, [load]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display font-bold text-3xl text-white">My <span className="gradient-text">Sounds</span></h1>
          <p className="text-slate-500 mt-1 text-sm">{data?.total ?? 0} sounds in your library</p>
        </div>
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
            <Input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} placeholder="Search sounds..." className="!pl-10" />
          </div>
          <Select value={sort} onChange={(e) => { setSort(e.target.value as typeof sort); setPage(1); }} className="!w-32">
            {SORTS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
          </Select>
        </div>
      </div>

      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        <SlidersHorizontal size={15} className="text-slate-500 shrink-0" />
        {FILTERS.map((f) => (
          <button
            key={f}
            onClick={() => { setFilter(f); setPage(1); }}
            className={`shrink-0 px-4 py-1.5 rounded-full text-xs font-display font-semibold capitalize transition-all border ${
              filter === f
                ? "bg-violet-neon/20 border-violet-neon/60 text-white shadow-[0_0_15px_rgba(139,92,246,0.25)]"
                : "bg-white/5 border-white/10 text-slate-400 hover:border-violet-neon/30"
            }`}
          >
            {f === "all" ? "All" : f}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      ) : !data || data.items.length === 0 ? (
        <Card className="text-center py-16">
          <p className="text-slate-500">ไม่พบเสียงที่ตรงกับเงื่อนไข</p>
        </Card>
      ) : (
        <>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {data.items.map((a) => <AudioCard key={a.id} audio={a} onChanged={load} />)}
          </div>
          {data.pages > 1 && (
            <div className="flex items-center justify-center gap-3 pt-2">
              <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)} className="btn-ghost !p-2" aria-label="Previous page">
                <ChevronLeft size={16} />
              </button>
              <span className="font-mono text-sm text-slate-400">{page} / {data.pages}</span>
              <button disabled={page >= data.pages} onClick={() => setPage((p) => p + 1)} className="btn-ghost !p-2" aria-label="Next page">
                <ChevronRight size={16} />
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
