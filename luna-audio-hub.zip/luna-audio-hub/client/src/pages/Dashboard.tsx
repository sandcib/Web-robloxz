import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Music, CheckCircle2, Loader2, HardDrive, Upload, ArrowRight } from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import { useAuth } from "../contexts/AuthContext";
import { api } from "../lib/api";
import { formatBytes, formatDuration } from "../lib/utils";
import { StatCard } from "../components/ui/StatCard";
import { SkeletonStats, SkeletonCard } from "../components/ui/Skeletons";
import { Card } from "../components/ui/Card";
import { AudioCard } from "../components/audio/AudioCard";
import type { Audio, Paginated } from "../types";

export default function Dashboard() {
  const { user } = useAuth();
  const [sounds, setSounds] = useState<Audio[]>([]);
  const [stats, setStats] = useState<{ total: number; ready: number; processing: number; storage: number; activity: { date: string; count: number }[] } | null>(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const [list, hist] = await Promise.all([
        api.get<Paginated<Audio>>("/api/audio?limit=6"),
        api.get<Paginated<{ id: string; createdAt: string }>>("/api/history?limit=50"),
      ]);
      setSounds(list.items);
      const byDay: Record<string, number> = {};
      hist.items.forEach((h) => {
        const d = new Date(h.createdAt).toISOString().slice(5, 10);
        byDay[d] = (byDay[d] || 0) + 1;
      });
      setStats({
        total: list.total,
        ready: list.items.filter((a) => a.status === "READY").length,
        processing: list.items.filter((a) => a.status === "PROCESSING" || a.status === "QUEUED").length,
        storage: list.items.reduce((s, a) => s + a.size, 0),
        activity: Object.entries(byDay).slice(-14).map(([date, count]) => ({ date, count })),
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm text-slate-500">Welcome back</p>
          <h1 className="font-display font-bold text-3xl text-white mt-1">
            สวัสดี, <span className="gradient-text">{user?.username}</span>
          </h1>
          <p className="text-slate-400 mt-1">พร้อมสร้างเสียงใหม่หรือยัง?</p>
        </div>
        <Link to="/upload" className="btn-primary"><Upload size={16} /> Upload Audio</Link>
      </div>

      {loading || !stats ? (
        <SkeletonStats />
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard label="Total Sounds" value={stats.total} icon={<Music size={20} />} accent="violet" />
          <StatCard label="Ready" value={stats.ready} icon={<CheckCircle2 size={20} />} accent="emerald" />
          <StatCard label="Processing" value={stats.processing} icon={<Loader2 size={20} />} accent="sky" />
          <StatCard label="Storage Used" value={formatBytes(stats.storage)} icon={<HardDrive size={20} />} accent="rose" />
        </div>
      )}

      <div className="grid lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2" glow>
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-semibold text-white">Upload Activity</h2>
            <span className="text-xs text-slate-500">last 14 days</span>
          </div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats?.activity ?? []}>
                <defs>
                  <linearGradient id="act" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#8B5CF6" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="#8B5CF6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="rgba(255,255,255,0.05)" vertical={false} />
                <XAxis dataKey="date" stroke="#475569" fontSize={11} tickLine={false} axisLine={false} />
                <YAxis stroke="#475569" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
                <Tooltip contentStyle={{ background: "#120820", border: "1px solid rgba(139,92,246,0.3)", borderRadius: 12, fontSize: 12 }} />
                <Area type="monotone" dataKey="count" stroke="#8B5CF6" strokeWidth={2.5} fill="url(#act)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card>
          <h2 className="font-display font-semibold text-white mb-4">Quick Stats</h2>
          <div className="space-y-4">
            {[
              { label: "Avg. duration", value: sounds.length ? formatDuration(sounds.reduce((s, a) => s + a.duration, 0) / sounds.length) : "—" },
              { label: "Formats in use", value: [...new Set(sounds.map((s) => s.format.toUpperCase()))].join(", ") || "—" },
              { label: "Favorites", value: sounds.filter((s) => s.isFavorite).length },
              { label: "With Roblox ID", value: sounds.filter((s) => s.soundId).length },
            ].map((r) => (
              <div key={r.label} className="flex items-center justify-between text-sm">
                <span className="text-slate-500">{r.label}</span>
                <span className="font-display font-semibold text-white">{r.value}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display font-semibold text-white text-lg">Recent Sounds</h2>
          <Link to="/sounds" className="text-sm text-violet-300 hover:text-white inline-flex items-center gap-1 transition-colors">
            View all <ArrowRight size={14} />
          </Link>
        </div>
        {loading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 3 }).map((_, i) => <SkeletonCard key={i} />)}
          </div>
        ) : sounds.length === 0 ? (
          <Card className="text-center py-12">
            <Music size={32} className="text-slate-600 mx-auto" />
            <p className="text-slate-400 mt-3">ยังไม่มีเสียงในระบบ</p>
            <Link to="/upload" className="btn-primary mt-5 inline-flex"><Upload size={15} /> Upload your first audio</Link>
          </Card>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {sounds.map((a) => <AudioCard key={a.id} audio={a} onChanged={load} />)}
          </div>
        )}
      </div>
    </div>
  );
}
