import { useEffect, useRef, useState } from "react";
import { Music2, ImagePlus, X, Wand2, Scissors } from "lucide-react";
import { api } from "../lib/api";
import { useToast } from "../contexts/ToastContext";
import { formatBytes, formatDuration } from "../lib/utils";
import { UploadDropzone } from "../components/audio/UploadDropzone";
import { Waveform } from "../components/audio/Waveform";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { Input, Textarea, Select } from "../components/ui/Input";
import { ProgressBar } from "../components/ui/ProgressBar";
import { Modal } from "../components/ui/Modal";
import { StatusBadge } from "../components/ui/StatusBadge";
import type { Audio, ProcessingJob } from "../types";

const BITRATES = [128, 192, 256, 320] as const;
const FORMATS = ["mp3", "ogg", "wav"] as const;
const CATEGORIES = ["Music", "SFX", "Voice", "Ambient", "Loop", "Other"];

export default function UploadPage() {
  const { toast } = useToast();
  const [file, setFile] = useState<File | null>(null);
  const [cover, setCover] = useState<File | null>(null);
  const [coverPreview, setCoverPreview] = useState<string | null>(null);
  const [metadata, setMetadata] = useState({ title: "", description: "", category: "Music", tags: "" });
  const [localUrl, setLocalUrl] = useState<string | null>(null);
  const [duration, setDuration] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<Audio | null>(null);
  const [processOpen, setProcessOpen] = useState(false);
  const [procOpts, setProcOpts] = useState({ format: "mp3" as (typeof FORMATS)[number], bitrate: 192 as (typeof BITRATES)[number] });
  const [procJob, setProcJob] = useState<ProcessingJob | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (!file) return;
    const url = URL.createObjectURL(file);
    setLocalUrl(url);
    const el = new Audio();
    el.src = url;
    el.onloadedmetadata = () => setDuration(el.duration || 0);
    audioRef.current = el;
    if (!metadata.title) setMetadata((m) => ({ ...m, title: file.name.replace(/\.[^.]+$/, "") }));
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const togglePlay = () => {
    const el = audioRef.current;
    if (!el) return;
    if (playing) { el.pause(); setPlaying(false); }
    else { el.play().then(() => setPlaying(true)).catch(() => setPlaying(false)); }
  };

  const onCover = (f: File | undefined) => {
    if (!f) return;
    if (!["image/png", "image/jpeg", "image/webp"].includes(f.type))
      return toast("warning", "รองรับเฉพาะ PNG, JPG, WEBP");
    if (f.size > 5 * 1024 * 1024) return toast("warning", "รูปต้องไม่เกิน 5MB");
    setCover(f);
    setCoverPreview(URL.createObjectURL(f));
  };

  const doUpload = async () => {
    if (!file) return;
    if (file.size > 50 * 1024 * 1024) return toast("warning", "File exceeds maximum size (50MB)");
    setUploading(true);
    setProgress(0);
    try {
      let coverUrl: string | undefined;
      if (cover) {
        const cf = new FormData();
        cf.append("file", cover);
        const c = await api.upload<{ coverUrl: string }>("/api/audio/upload", cf);
        coverUrl = c.coverUrl;
      }
      const form = new FormData();
      form.append("file", file);
      form.append("title", metadata.title);
      form.append("description", metadata.description);
      form.append("category", metadata.category);
      form.append("tags", metadata.tags);
      if (coverUrl) form.append("coverUrl", coverUrl);
      const audio = await api.upload<Audio>("/api/audio/upload", form);
      setResult(audio);
      setProgress(100);
      toast("success", "Audio uploaded successfully");
    } catch (e) {
      toast("error", (e as Error).message);
    } finally {
      setUploading(false);
    }
  };

  const startProcess = async () => {
    if (!result) return;
    try {
      const job = await api.post<ProcessingJob>(`/api/audio/${result.id}/process`, { type: "CONVERT", ...procOpts });
      setProcJob(job);
      setProcessOpen(false);
      toast("info", "Processing queued...");
      // poll progress จริงจาก API
      const t = setInterval(async () => {
        try {
          const j = await api.get<ProcessingJob>(`/api/jobs/${job.id}`);
          setProcJob(j);
          if (j.status === "COMPLETED") {
            clearInterval(t);
            toast("success", "Conversion complete");
            setResult((r) => (r ? { ...r, status: "READY", format: procOpts.format, bitrate: procOpts.bitrate } : r));
          }
          if (j.status === "FAILED") {
            clearInterval(t);
            toast("error", `Processing failed: ${j.error ?? ""}`);
          }
        } catch { clearInterval(t); }
      }, 1500);
    } catch (e) {
      toast("error", (e as Error).message);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="font-display font-bold text-3xl text-white">Upload <span className="gradient-text">Audio</span></h1>
        <p className="text-slate-500 mt-1 text-sm">ลากไฟล์เสียงเข้ามา ตั้งค่า และอัปโหลด — รองรับ MP3 · WAV · OGG · M4A (สูงสุด 50MB)</p>
      </div>

      {!file ? (
        <UploadDropzone onFile={setFile} />
      ) : (
        <Card glow className="space-y-6">
          <div className="flex flex-wrap items-center gap-4">
            <button onClick={togglePlay} className="w-14 h-14 rounded-2xl bg-gradient-to-br from-violet-neon to-magenta flex items-center justify-center text-white shadow-[0_0_25px_rgba(139,92,246,0.5)] hover:scale-105 transition-transform" aria-label={playing ? "Pause preview" : "Play preview"}>
              {playing ? "❚❚" : "▶"}
            </button>
            <div className="flex-1 min-w-[200px]">
              <p className="font-display font-semibold text-white truncate">{file.name}</p>
              <p className="text-xs text-slate-500 font-display uppercase tracking-wider mt-0.5">
                {formatBytes(file.size)} · {file.type.replace("audio/", "").toUpperCase()} · {formatDuration(duration)}
              </p>
            </div>
            <button onClick={() => { setFile(null); setCover(null); setCoverPreview(null); setResult(null); }} className="btn-ghost !py-2 text-xs">
              <X size={14} /> Replace
            </button>
          </div>

          <div className="h-24 rounded-xl bg-black/30 border border-white/5 p-3">
            <Waveform playing={playing} bars={72} />
          </div>

          {uploading && (
            <div>
              <div className="flex justify-between text-xs text-slate-400 mb-2 font-mono">
                <span>UPLOADING...</span><span>{progress}%</span>
              </div>
              <ProgressBar value={progress} indeterminate={progress < 5} />
            </div>
          )}

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="text-xs font-display text-slate-400 uppercase tracking-wider">Song Name</label>
                <Input className="mt-1.5" value={metadata.title} onChange={(e) => setMetadata((m) => ({ ...m, title: e.target.value }))} placeholder="ชื่อเพลง" />
              </div>
              <div>
                <label className="text-xs font-display text-slate-400 uppercase tracking-wider">Description</label>
                <Textarea className="mt-1.5" value={metadata.description} onChange={(e) => setMetadata((m) => ({ ...m, description: e.target.value }))} placeholder="คำอธิบาย..." />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-display text-slate-400 uppercase tracking-wider">Category</label>
                  <Select className="mt-1.5" value={metadata.category} onChange={(e) => setMetadata((m) => ({ ...m, category: e.target.value }))}>
                    {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
                  </Select>
                </div>
                <div>
                  <label className="text-xs font-display text-slate-400 uppercase tracking-wider">Tags</label>
                  <Input className="mt-1.5" value={metadata.tags} onChange={(e) => setMetadata((m) => ({ ...m, tags: e.target.value }))} placeholder="lofi, chill, roblox" />
                </div>
              </div>
            </div>

            <div>
              <label className="text-xs font-display text-slate-400 uppercase tracking-wider">Cover Image</label>
              <div
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => { e.preventDefault(); onCover(e.dataTransfer.files?.[0]); }}
                onClick={() => document.getElementById("cover-input")?.click()}
                className="mt-1.5 relative h-52 rounded-2xl border-2 border-dashed border-white/15 hover:border-violet-neon/50 transition-all cursor-pointer overflow-hidden group"
                role="button" tabIndex={0}
              >
                <input id="cover-input" type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(e) => onCover(e.target.files?.[0] ?? undefined)} />
                {coverPreview ? (
                  <>
                    <img src={coverPreview} alt="Cover preview" className="w-full h-full object-cover" />
                    <button
                      onClick={(e) => { e.stopPropagation(); setCover(null); setCoverPreview(null); }}
                      className="absolute top-2 right-2 w-8 h-8 rounded-lg bg-black/60 backdrop-blur flex items-center justify-center text-white hover:bg-rose-600/70 transition-colors"
                      aria-label="Remove cover"
                    >
                      <X size={14} />
                    </button>
                  </>
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center gap-2 bg-gradient-to-br from-violet-neon/10 to-magenta/5">
                    <div className="absolute inset-0 opacity-50"><Waveform bars={30} /></div>
                    <div className="relative w-12 h-12 rounded-xl bg-violet-neon/20 border border-violet-neon/30 flex items-center justify-center">
                      <ImagePlus size={20} className="text-violet-300" />
                    </div>
                    <p className="relative text-xs font-display tracking-widest text-slate-400">+ ADD COVER</p>
                    <p className="relative text-[10px] text-slate-600">PNG · JPG · WEBP</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {result ? (
            <div className="glass rounded-xl p-4 flex flex-wrap items-center gap-4">
              <StatusBadge status={result.status} />
              <p className="text-sm text-slate-300 flex-1">“{result.title}” อัปโหลดแล้ว</p>
              {procJob && (procJob.status === "QUEUED" || procJob.status === "PROCESSING") ? (
                <div className="w-48">
                  <ProgressBar value={procJob.progress} indeterminate={procJob.status === "QUEUED"} />
                </div>
              ) : (
                <Button variant="ghost" onClick={() => setProcessOpen(true)}>
                  <Wand2 size={15} /> Process (Convert / Trim)
                </Button>
              )}
            </div>
          ) : (
            <Button onClick={doUpload} loading={uploading} className="w-full">
              Upload Audio
            </Button>
          )}
        </Card>
      )}

      <Modal open={processOpen} onClose={() => setProcessOpen(false)} title="Audio Processing">
        <div className="space-y-5">
          <div>
            <label className="text-xs font-display text-slate-400 uppercase tracking-wider">Output Format</label>
            <div className="flex gap-2 mt-2">
              {FORMATS.map((f) => (
                <button
                  key={f}
                  onClick={() => setProcOpts((o) => ({ ...o, format: f }))}
                  className={`flex-1 py-2.5 rounded-xl font-display font-semibold text-sm uppercase tracking-wider border transition-all ${
                    procOpts.format === f
                      ? "bg-violet-neon/20 border-violet-neon/60 text-white shadow-[0_0_15px_rgba(139,92,246,0.3)]"
                      : "bg-white/5 border-white/10 text-slate-400 hover:border-violet-neon/30"
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="text-xs font-display text-slate-400 uppercase tracking-wider">Bitrate</label>
            <div className="grid grid-cols-4 gap-2 mt-2">
              {BITRATES.map((b) => (
                <button
                  key={b}
                  onClick={() => setProcOpts((o) => ({ ...o, bitrate: b }))}
                  className={`py-2.5 rounded-xl font-mono text-sm border transition-all ${
                    procOpts.bitrate === b
                      ? "bg-magenta/20 border-magenta/60 text-white"
                      : "bg-white/5 border-white/10 text-slate-400 hover:border-magenta/30"
                  }`}
                >
                  {b}k
                </button>
              ))}
            </div>
          </div>
          <div className="flex items-start gap-2 text-xs text-slate-500 bg-white/5 rounded-xl p-3">
            <Scissors size={14} className="shrink-0 mt-0.5 text-violet-300" />
            Trim (ตัดช่วงเวลา) ทำได้หลังอัปโหลดจากหน้า My Sounds → กด Process บนแต่ละเพลง
          </div>
          <Button onClick={startProcess} className="w-full"><Wand2 size={15} /> Start Processing</Button>
        </div>
      </Modal>
    </div>
  );
}
