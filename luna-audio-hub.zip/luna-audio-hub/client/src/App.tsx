import { useEffect, useState } from "react";
import { Routes, Route, Navigate, useLocation } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import { ToastProvider } from "./contexts/ToastContext";
import { PlayerProvider } from "./contexts/PlayerContext";
import { SSEProvider } from "./contexts/SSEContext";
import { LoadingScreen } from "./components/layout/LoadingScreen";
import { AppLayout } from "./layouts/AppLayout";

import Landing from "./pages/Landing";
import Login from "./pages/Login";
import Register from "./pages/Register";
import AdminLogin from "./pages/AdminLogin";
import Dashboard from "./pages/Dashboard";
import UploadPage from "./pages/UploadPage";
import YouTubeImport from "./pages/YouTubeImport";
import MySounds from "./pages/MySounds";
import RobloxSounds from "./pages/RobloxSounds";
import Favorites from "./pages/Favorites";
import HistoryPage from "./pages/HistoryPage";
import Profile from "./pages/Profile";
import UserSettings from "./pages/UserSettings";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminUsers from "./pages/admin/AdminUsers";
import AdminAudio from "./pages/admin/AdminAudio";
import AdminJobs from "./pages/admin/AdminJobs";
import AdminLogs from "./pages/admin/AdminLogs";
import AdminSettings from "./pages/admin/AdminSettings";
import { ErrorPage } from "./pages/ErrorPage";

function Protected({ children, adminOnly }: { children: JSX.Element; adminOnly?: boolean }) {
  const { user, loading } = useAuth();
  const location = useLocation();
  if (loading)
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-10 h-10 rounded-full border-2 border-violet-neon/30 border-t-violet-neon animate-spin" />
      </div>
    );
  if (!user) return <Navigate to="/login" state={{ from: location }} replace />;
  if (adminOnly && user.role === "USER") return <ErrorPage code={403} />;
  return children;
}

function AnimatedRoutes() {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={location.pathname}
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -12 }}
        transition={{ duration: 0.25, ease: "easeOut" }}
      >
        <Routes location={location}>
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/admin/login" element={<AdminLogin />} />

          <Route element={<Protected><AppLayout /></Protected>}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/upload" element={<UploadPage />} />
            <Route path="/youtube" element={<YouTubeImport />} />
            <Route path="/sounds" element={<MySounds />} />
            <Route path="/roblox" element={<RobloxSounds />} />
            <Route path="/favorites" element={<Favorites />} />
            <Route path="/history" element={<HistoryPage />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/settings" element={<UserSettings />} />
          </Route>

          <Route element={<Protected adminOnly><AppLayout /></Protected>}>
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/admin/users" element={<AdminUsers />} />
            <Route path="/admin/audio" element={<AdminAudio />} />
            <Route path="/admin/jobs" element={<AdminJobs />} />
            <Route path="/admin/logs" element={<AdminLogs />} />
            <Route path="/admin/settings" element={<AdminSettings />} />
          </Route>

          <Route path="/403" element={<ErrorPage code={403} />} />
          <Route path="/500" element={<ErrorPage code={500} />} />
          <Route path="*" element={<ErrorPage code={404} />} />
        </Routes>
      </motion.div>
    </AnimatePresence>
  );
}

export default function App() {
  const [loaded, setLoaded] = useState(false);

  return (
    <AuthProvider>
      <ToastProvider>
        <PlayerProvider>
          <SSEProvider>
            {!loaded && <LoadingScreen onDone={() => setLoaded(true)} />}
            <AnimatedRoutes />
          </SSEProvider>
        </PlayerProvider>
      </ToastProvider>
    </AuthProvider>
  );
}
