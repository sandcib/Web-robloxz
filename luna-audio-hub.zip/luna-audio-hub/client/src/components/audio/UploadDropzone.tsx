import { useCallback, useRef, useState, type DragEvent } from "react";
import { motion } from "framer-motion";
import { UploadCloud, Music } from "lucide-react";
import { cn } from "../../lib/utils";

const ACCEPTED = ["audio/mpeg", "audio/wav", "audio/x-wav", "audio/ogg", "audio/mp4", "audio/x-m4a"];

interface Props {
  onFile: (file: File) => void;
  compact?: boolean;
}

export function UploadDropzone({ onFile, compact }: Props) {
  const [drag, setDrag] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handle = useCallback((file: File | undefined) => {
    if (!file) return;
    if (!ACCEPTED.includes(file.type)) return;
    onFile(file);
  }, [onFile]);

  const onDrop = (e: DragEvent) => {
    e.preventDefault();
    setDrag(false);
    handle(e.dataTransfer.files?.[0]);
  };

  return (
    <div
      onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
      onDragLeave={() => setDrag(false)}
      onDrop={onDrop}
      onClick={() => inputRef.current?.click()}
      role="button" tabIndex={0}
      onKeyDown={(e) => { if (e.key === "Enter") inputRef.current?.click(); }}
      className={cn(
        "relative cursor-pointer rounded-2xl border-2 border-dashed text-center transition-all duration-300 overflow-hidden",
        compact ? "p-6" : "p-12",
        drag
          ? "border-violet-neon bg-violet-neon/10 shadow-[0_0_50px_rgba(139,92,246,0.25)] scale-[1.01]"
          : "border-white/15 bg-white/[0.03] hover:border-violet-neon/50 hover:bg-violet-neon/5",
      )}
    >
      {drag && <div className="light-streak" />}
      <input
        ref={inputRef}
        type="file"
        accept=".mp3,.wav,.ogg,.m4a,audio/*"
        className="hidden"
        onChange={(e) => { handle(e.target.files?.[0]); e.target.value = ""; }}
        aria-label="Select audio file"
      />
      <motion.div animate={drag ? { scale: 1.08 } : { scale: 1 }} className="flex flex-col items-center gap-3">
        <div className="relative">
          <div className="absolute inset-0 rounded-full bg-violet-neon/30 blur-xl" />
          <div className="relative rounded-2xl bg-gradient-to-br from-violet-neon/25 to-magenta/15 p-4 border border-violet-neon/30">
            {drag ? <Music size={28} className="text-violet-300" /> : <UploadCloud size={28} className="text-violet-300" />}
          </div>
        </div>
        <div>
          <p className="font-display font-semibold text-white tracking-wide">DROP AUDIO FILE HERE</p>
          <p className="text-xs text-slate-500 mt-1">หรือ</p>
        </div>
        <span className="btn-ghost text-sm pointer-events-none">SELECT FILE</span>
        <p className="text-[11px] text-slate-600 font-display tracking-widest">MP3 · WAV · OGG · M4A</p>
      </motion.div>
    </div>
  );
}
