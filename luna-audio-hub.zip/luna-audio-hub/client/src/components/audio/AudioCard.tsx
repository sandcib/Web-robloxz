import { useState } from "react";
import { Play, Pause, Download, Copy, Heart, Trash2, MoreVertical, Gamepad2 } from "lucide-react";
import { usePlayer } from "../../contexts/PlayerContext";
import { useToast } from "../../contexts/ToastContext";
import { api } from "../../lib/api";
import { formatDuration, formatDate } from "../../lib/utils";
import { StatusBadge } from "../ui/StatusBadge";
import { ConfirmDialog } from "../ui/ConfirmDialog";
import { Waveform } from "./Waveform";
import type { Audio } from "../../types";
import { cn } from "../../lib/utils";

interface Props {
  audio: Audio;
  onChanged?: () => void;
}

export function AudioCard({ audio, onChanged }: Props) {
  const { current, playing, play, toggle } = usePlayer();
  const { toast } = useToast();
  const [fav, setFav] = useState(!!audio.isFavorite);
  const [confirm, setConfirm] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const isCurrent = current?.id === audio.id;

  const handlePlay = () => (isCurrent ? toggle() : play(audio));

  const copyId = async () => {
    if (!audio.soundId) return toast("warning", "No Roblox Sound ID yet");
    await navigator.clipboard.writeText(audio.soundId).catch(() => {});
    toast("success", "Sound ID copied");
  };

  const download = () => {
    const a = document.createElement("a");
    a.href = `/api/audio/${audio.id}/download`;
    a.download = audio.title;
    document.body.appendChild(a);
    a.click();
    a.remove();
    toast("info", "Downloading...");
  };

  const toggleFav = async () => {
    try {
      if (fav) await api.del(`/api/favorites/${audio.id}`);
      else await api.post(`/api/favorites/${audio.id}`);
      setFav(!fav);
      toast("success", fav ? "Removed from favorites" : "Added to favorites");
      onChanged?.();
    } catch (e) {
      toast("error", (e as Error).message);
    }
  };

  const doDelete = async () => {
    setDeleting(true);
    try {
      await api.del(`/api/audio/${audio.id}`);
      toast("success", "Audio deleted");
      setConfirm(false);
      onChanged?.();
    } catch (e) {
      toast("error", (e as Error).message);
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="glass neon-border group relative overflow-hidden transition-all duration-300 hover:shadow-[0_0_40px_rgba(139,92,246,0.18)]">
      <div className="relative h-40 bg-gradient-to-br from-deep via-[#1a0f2e] to-abyss flex items-center justify-center overflow-hidden">
        {audio.coverUrl ? (
          <img src={audio.coverUrl} alt={audio.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy" />
        ) : (
          <div className="w-full h-full opacity-60"><Waveform playing={isCurrent && playing} bars={40} /></div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-void/90 via-transparent to-transparent" />
        <button
          onClick={handlePlay}
          className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
          aria-label={isCurrent && playing ? "Pause" : "Play"}
        >
          <span className="w-14 h-14 rounded-full bg-gradient-to-br from-violet-neon to-magenta flex items-center justify-center text-white shadow-[0_0_30px_rgba(139,92,246,0.7)] hover:scale-110 transition-transform">
            {isCurrent && playing ? <Pause size={22} /> : <Play size={22} className="ml-1" />}
          </span>
        </button>
        <div className="absolute top-3 right-3"><StatusBadge status={audio.status} /></div>
        {audio.soundId && (
          <div className="absolute top-3 left-3 flex items-center gap-1 rounded-full bg-black/50 backdrop-blur px-2 py-1 border border-emerald-500/30">
            <Gamepad2 size={11} className="text-emerald-300" />
            <span className="text-[10px] font-mono text-emerald-300">{audio.soundId}</span>
          </div>
        )}
      </div>

      <div className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <h3 className="font-display font-semibold text-white truncate">{audio.title}</h3>
            <p className="text-[11px] text-slate-500 mt-0.5 font-display uppercase tracking-wider">
              {formatDuration(audio.duration)} · {audio.bitrate ? `${audio.bitrate}kbps` : audio.format.toUpperCase()} · {formatDate(audio.createdAt)}
            </p>
          </div>
          <button onClick={toggleFav} className={cn("shrink-0 transition-all hover:scale-125", fav ? "text-magenta" : "text-slate-600 hover:text-magenta")} aria-label="Favorite">
            <Heart size={17} fill={fav ? "currentColor" : "none"} />
          </button>
        </div>

        <div className="flex items-center gap-1 mt-3">
          <button onClick={handlePlay} className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-slate-300 hover:text-white hover:border-violet-neon/40 transition-all" aria-label="Play">
            {isCurrent && playing ? <Pause size={13} /> : <Play size={13} />}
          </button>
          <button onClick={download} className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-slate-300 hover:text-white hover:border-violet-neon/40 transition-all" aria-label="Download">
            <Download size={13} />
          </button>
          <button onClick={copyId} className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-slate-300 hover:text-white hover:border-violet-neon/40 transition-all" aria-label="Copy sound ID">
            <Copy size={13} />
          </button>
          <div className="flex-1" />
          <button onClick={() => setConfirm(true)} className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-slate-500 hover:text-rose-400 hover:border-rose-500/40 transition-all" aria-label="Delete">
            <Trash2 size={13} />
          </button>
          <button className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-slate-500 hover:text-white transition-all" aria-label="More">
            <MoreVertical size={13} />
          </button>
        </div>
      </div>

      <ConfirmDialog
        open={confirm}
        onClose={() => setConfirm(false)}
        onConfirm={doDelete}
        loading={deleting}
        title="Delete Audio"
        message={`คุณแน่ใจหรือไม่ที่จะลบ “${audio.title}”? การกระทำนี้ไม่สามารถย้อนกลับได้`}
        confirmText="Delete"
      />
    </div>
  );
}
