import { useEffect, useRef } from "react";
import { cn } from "../../lib/utils";

interface Props {
  playing?: boolean;
  bars?: number;
  className?: string;
  color?: string;
}

export function Waveform({ playing, bars = 48, className, color = "#8B5CF6" }: Props) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.innerHTML = "";
    for (let i = 0; i < bars; i++) {
      const bar = document.createElement("div");
      const h = 18 + Math.abs(Math.sin(i * 0.55) * 55) + Math.random() * 22;
      bar.style.cssText = `width:3px;height:${h}%;border-radius:99px;background:linear-gradient(to top, ${color}, #D946EF);transform-origin:center;`;
      bar.className = "transition-transform duration-150";
      bar.style.animationDelay = `${(i % 12) * 0.09}s`;
      el.appendChild(bar);
    }
  }, [bars, color]);

  return (
    <div
      ref={ref}
      className={cn("flex items-center justify-center gap-[3px] h-full w-full", playing && "[&>div]:animate-wave-bar", className)}
      aria-hidden="true"
    />
  );
}
