import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export function LoadingScreen({ onDone }: { onDone: () => void }) {
  const [progress, setProgress] = useState(0);
  const [leaving, setLeaving] = useState(false);

  useEffect(() => {
    let value = 0;
    let finished = false;
    const tick = () => {
      // โหลดจริงตาม resource ที่พร้อม + advance ตามเวลา — ถ้า document พร้อมแล้วจะเร็วขึ้น
      const resourcesReady = document.readyState === "complete" || document.readyState === "interactive";
      const step = resourcesReady ? 7 + Math.random() * 8 : 2 + Math.random() * 4;
      value = Math.min(100, value + step);
      setProgress(Math.floor(value));
      if (value >= 100) {
        if (!finished) {
          finished = true;
          setLeaving(true);
          setTimeout(onDone, 650);
        }
        return;
      }
      setTimeout(tick, 90);
    };
    const start = setTimeout(tick, 250);
    return () => clearTimeout(start);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const blocks = 18;
  const filled = Math.round((progress / 100) * blocks);

  return (
    <AnimatePresence>
      {!leaving && (
        <motion.div
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-void"
        >
          <div className="blob animate-blob-1 w-[420px] h-[420px] -top-24 -left-24 fixed" style={{ background: "radial-gradient(circle, rgba(139,92,246,0.45), transparent 65%)" }} />
          <div className="blob animate-blob-2 w-[380px] h-[380px] -bottom-20 -right-20 fixed" style={{ background: "radial-gradient(circle, rgba(217,70,239,0.3), transparent 65%)" }} />
          <div className="bg-grid fixed inset-0" />
          <div className="bg-noise fixed inset-0" />

          <div className="relative">
            <motion.div
              className="absolute -inset-8 rounded-full border border-violet-neon/30"
              animate={{ rotate: 360 }}
              transition={{ repeat: Infinity, duration: 3, ease: "linear" }}
            >
              <span className="absolute -top-1 left-1/2 w-2 h-2 rounded-full bg-violet-neon shadow-[0_0_12px_#8B5CF6]" />
            </motion.div>
            <motion.div
              className="absolute -inset-14 rounded-full border border-magenta/15"
              animate={{ rotate: -360 }}
              transition={{ repeat: Infinity, duration: 6, ease: "linear" }}
            >
              <span className="absolute top-1/2 -right-1 w-1.5 h-1.5 rounded-full bg-magenta shadow-[0_0_10px_#D946EF]" />
            </motion.div>

            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.8, type: "spring" }}
              className="relative text-center"
            >
              <div className="font-display font-bold text-5xl md:text-6xl tracking-[0.22em] gradient-text drop-shadow-[0_0_25px_rgba(139,92,246,0.5)]">LUNA</div>
              <div className="font-display text-sm tracking-[0.6em] text-slate-400 mt-2 ml-1">AUDIO HUB</div>
            </motion.div>
          </div>

          <div className="mt-16 w-[300px] md:w-[380px] relative z-10">
            <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
              <motion.div
                className="h-full rounded-full bg-gradient-to-r from-violet-neon via-violet-electric to-magenta shadow-[0_0_15px_rgba(139,92,246,0.8)]"
                style={{ width: `${progress}%` }}
              />
            </div>
            <div className="mt-4 flex items-center justify-between font-mono text-xs">
              <span className="tracking-[0.3em] text-violet-300/80">INITIALIZING AUDIO SYSTEM</span>
              <span className="text-white">{progress}%</span>
            </div>
            <div className="mt-3 font-mono text-[11px] text-violet-neon/70 tracking-widest select-none" aria-hidden="true">
              {"█".repeat(filled)}{"░".repeat(blocks - filled)}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
