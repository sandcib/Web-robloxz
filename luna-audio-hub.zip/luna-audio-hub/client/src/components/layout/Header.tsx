import { useNavigate } from "react-router-dom";
import { Menu, Search, Bell, Upload } from "lucide-react";
import { useEffect, useState } from "react";
import { api } from "../../lib/api";
import { useAuth } from "../../contexts/AuthContext";
import { timeAgo } from "../../lib/utils";
import type { Notification } from "../../types";

export function Header({ onMenu }: { onMenu: () => void }) {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [notifs, setNotifs] = useState<Notification[]>([]);
  const [unread, setUnread] = useState(0);
  const [panelOpen, setPanelOpen] = useState(false);

  useEffect(() => {
    if (!user) return;
    const load = () => api.get<{ items: Notification[]; unread: number }>("/api/notifications").then((d) => {
      setNotifs(d.items); setUnread(d.unread);
    }).catch(() => {});
    load();
    const t = setInterval(load, 30000);
    return () => clearInterval(t);
  }, [user]);

  const markAll = async () => {
    await api.post("/api/notifications/read-all").catch(() => {});
    setUnread(0);
    setNotifs((n) => n.map((x) => ({ ...x, read: true })));
  };

  return (
    <header className="sticky top-0 z-30 px-3 lg:pl-[280px] pt-3">
      <div className="glass rounded-2xl px-4 py-3 flex items-center gap-3">
        <button onClick={onMenu} className="lg:hidden text-slate-300 hover:text-white" aria-label="Open menu">
          <Menu size={20} />
        </button>

        <button
          onClick={() => window.dispatchEvent(new CustomEvent("open-command"))}
          className="hidden sm:flex items-center gap-2.5 flex-1 max-w-md rounded-xl bg-white/5 border border-white/10 px-3.5 py-2 text-sm text-slate-500 hover:border-violet-neon/40 hover:text-slate-300 transition-all"
        >
          <Search size={15} />
          <span className="flex-1 text-left">Search sounds...</span>
          <kbd className="font-mono text-[10px] bg-white/10 rounded px-1.5 py-0.5">CTRL K</kbd>
        </button>
        <div className="sm:hidden flex-1" />

        <button onClick={() => navigate("/upload")} className="btn-primary !px-4 !py-2 text-sm hidden md:inline-flex">
          <Upload size={15} /> Upload
        </button>

        <div className="relative">
          <button
            onClick={() => setPanelOpen((o) => !o)}
            className="relative w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-slate-300 hover:text-white hover:border-violet-neon/40 transition-all"
            aria-label="Notifications"
          >
            <Bell size={17} />
            {unread > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-magenta text-white text-[10px] font-bold flex items-center justify-center shadow-[0_0_10px_rgba(217,70,239,0.7)]">
                {unread > 9 ? "9+" : unread}
              </span>
            )}
          </button>
          {panelOpen && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setPanelOpen(false)} />
              <div className="absolute right-0 mt-2 w-[320px] max-h-[420px] overflow-y-auto glass-strong neon-border z-50 p-3">
                <div className="flex items-center justify-between px-2 pb-2">
                  <p className="font-display font-semibold text-sm text-white">Notifications</p>
                  <button onClick={markAll} className="text-[11px] text-violet-300 hover:text-white">Mark all read</button>
                </div>
                {notifs.length === 0 && <p className="text-xs text-slate-500 p-3 text-center">No notifications yet</p>}
                {notifs.map((n) => (
                  <div key={n.id} className={`rounded-xl px-3 py-2.5 mb-1 ${n.read ? "opacity-50" : "bg-violet-neon/10"}`}>
                    <p className="text-xs font-medium text-white">{n.title}</p>
                    {n.body && <p className="text-[11px] text-slate-400 mt-0.5">{n.body}</p>}
                    <p className="text-[10px] text-slate-600 mt-1">{timeAgo(n.createdAt)}</p>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>

        <button onClick={() => navigate("/profile")} className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-neon to-magenta flex items-center justify-center font-display font-bold text-white shadow-[0_0_15px_rgba(139,92,246,0.4)]" aria-label="Profile">
          {user?.username?.[0]?.toUpperCase() ?? "?"}
        </button>
      </div>
    </header>
  );
}
