import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { Search, Music, LayoutDashboard, Upload, Gamepad2, Heart, History, Settings } from "lucide-react";
import { api } from "../../lib/api";
import type { Audio } from "../../types";

const PAGES = [
  { label: "Dashboard", to: "/dashboard", icon: LayoutDashboard },
  { label: "Upload", to: "/upload", icon: Upload },
  { label: "YouTube Import", to: "/youtube", icon: Upload },
  { label: "My Sounds", to: "/sounds", icon: Music },
  { label: "Roblox Sounds", to: "/roblox", icon: Gamepad2 },
  { label: "Favorites", to: "/favorites", icon: Heart },
  { label: "History", to: "/history", icon: History },
  { label: "Settings", to: "/settings", icon: Settings },
];

export function CommandPalette() {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [sounds, setSounds] = useState<Audio[]>([]);
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const openHandler = () => setOpen(true);
    window.addEventListener("open-command", openHandler);
    return () => window.removeEventListener("open-command", openHandler);
  }, []);

  useEffect(() => {
    if (!open) return;
    inputRef.current?.focus();
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  useEffect(() => {
    if (!q.trim()) { setSounds([]); return; }
    const t = setTimeout(() => {
      api.get<{ sounds: Audio[] }>(`/api/search?q=${encodeURIComponent(q)}`).then((d) => setSounds(d.sounds)).catch(() => setSounds([]));
    }, 250); // debounce
    return () => clearTimeout(t);
  }, [q]);

  const go = (to: string) => { setOpen(false); setQ(""); navigate(to); };
  const pageMatches = PAGES.filter((p) => p.label.toLowerCase().includes(q.toLowerCase()));

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="fixed inset-0 z-[85] bg-black/70 backdrop-blur-sm flex items-start justify-center pt-[14vh] px-4"
          onClick={() => setOpen(false)}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: -16 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.97, y: -8 }}
            onClick={(e) => e.stopPropagation()}
            className="glass-strong neon-border w-full max-w-xl rounded-2xl overflow-hidden"
          >
            <div className="flex items-center gap-3 px-5 py-4 border-b border-white/10">
              <Search size={18} className="text-violet-300" />
              <input
                ref={inputRef}
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search sounds, pages, settings..."
                className="flex-1 bg-transparent outline-none text-white placeholder:text-slate-500 text-sm"
              />
              <kbd className="font-mono text-[10px] bg-white/10 rounded px-1.5 py-0.5 text-slate-400">ESC</kbd>
            </div>
            <div className="max-h-[46vh] overflow-y-auto p-2">
              {sounds.length > 0 && (
                <>
                  <p className="px-3 pt-2 pb-1 text-[10px] font-display tracking-[0.2em] text-slate-600 uppercase">Sounds</p>
                  {sounds.map((s) => (
                    <button key={s.id} onClick={() => { setOpen(false); navigate("/sounds"); }} className="w-full flex items-center gap-3 rounded-xl px-3 py-2.5 hover:bg-violet-neon/10 text-left transition-colors">
                      <Music size={15} className="text-violet-300 shrink-0" />
                      <span className="flex-1 text-sm text-white truncate">{s.title}</span>
                      <span className="text-[10px] font-mono text-slate-500 uppercase">{s.format}</span>
                    </button>
                  ))}
                </>
              )}
              <p className="px-3 pt-2 pb-1 text-[10px] font-display tracking-[0.2em] text-slate-600 uppercase">Pages</p>
              {pageMatches.map((p) => (
                <button key={p.to} onClick={() => go(p.to)} className="w-full flex items-center gap-3 rounded-xl px-3 py-2.5 hover:bg-violet-neon/10 text-left transition-colors">
                  <p.icon size={15} className="text-slate-400 shrink-0" />
                  <span className="text-sm text-slate-200">{p.label}</span>
                </button>
              ))}
              {q && sounds.length === 0 && pageMatches.length === 0 && (
                <p className="text-center text-xs text-slate-500 py-6">No results for “{q}”</p>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
