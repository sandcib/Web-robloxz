import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, Music2 } from "lucide-react";
import { usePlayer } from "../../contexts/PlayerContext";
import { formatDuration } from "../../lib/utils";
import { Waveform } from "../audio/Waveform";

export function GlobalPlayer() {
  const { current, playing, time, duration, volume, toggle, seekTo, setVolume } = usePlayer();

  if (!current) return null;
  const pct = duration > 0 ? (time / duration) * 100 : 0;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-[60] px-3 pb-3">
      <div className="glass-strong neon-border rounded-2xl px-4 py-3 flex items-center gap-3 md:gap-5 shadow-[0_-10px_50px_rgba(0,0,0,0.6)]">
        <div className="hidden sm:block w-24 h-8 opacity-70"><Waveform playing={playing} bars={26} /></div>

        <div className="flex items-center gap-3 min-w-0 flex-1 sm:flex-initial sm:w-56">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-violet-neon/40 to-magenta/30 border border-violet-neon/30 flex items-center justify-center shrink-0 overflow-hidden">
            {current.coverUrl ? (
              <img src={current.coverUrl} alt="" className="w-full h-full object-cover" />
            ) : (
              <Music2 size={18} className="text-violet-300" />
            )}
          </div>
          <div className="min-w-0">
            <p className="text-sm font-medium text-white truncate">{current.title}</p>
            <p className="text-[11px] text-slate-500 font-display uppercase tracking-wider">{current.format}</p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button className="hidden md:flex w-9 h-9 items-center justify-center rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-all" onClick={() => seekTo(0)} aria-label="Rewind">
            <SkipBack size={16} />
          </button>
          <button
            onClick={toggle}
            className="w-11 h-11 rounded-full bg-gradient-to-br from-violet-neon to-magenta flex items-center justify-center text-white shadow-[0_0_20px_rgba(139,92,246,0.55)] hover:scale-105 active:scale-95 transition-transform"
            aria-label={playing ? "Pause" : "Play"}
          >
            {playing ? <Pause size={18} /> : <Play size={18} className="ml-0.5" />}
          </button>
          <button className="hidden md:flex w-9 h-9 items-center justify-center rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-all" onClick={() => seekTo(duration)} aria-label="Forward">
            <SkipForward size={16} />
          </button>
        </div>

        <div className="flex-1 hidden md:flex items-center gap-3">
          <span className="font-mono text-[11px] text-slate-400 w-10">{formatDuration(time)}</span>
          <input
            type="range"
            min={0}
            max={duration || 1}
            step={0.1}
            value={time}
            onChange={(e) => seekTo(Number(e.target.value))}
            className="seek flex-1"
            style={{ "--fill": `${pct}%` } as React.CSSProperties}
            aria-label="Seek"
          />
          <span className="font-mono text-[11px] text-slate-400 w-10">{formatDuration(duration)}</span>
        </div>

        <div className="hidden sm:flex items-center gap-2">
          <button onClick={() => setVolume(volume === 0 ? 0.8 : 0)} className="text-slate-400 hover:text-white transition-colors" aria-label="Mute">
            {volume === 0 ? <VolumeX size={16} /> : <Volume2 size={16} />}
          </button>
          <input
            type="range" min={0} max={1} step={0.05} value={volume}
            onChange={(e) => setVolume(Number(e.target.value))}
            className="seek w-20"
            style={{ "--fill": `${volume * 100}%` } as React.CSSProperties}
            aria-label="Volume"
          />
        </div>
      </div>
    </div>
  );
}
