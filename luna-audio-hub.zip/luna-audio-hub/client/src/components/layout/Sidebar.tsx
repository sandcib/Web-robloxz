import { NavLink, useNavigate } from "react-router-dom";
import {
  LayoutDashboard, Upload, Youtube, Music, Gamepad2, Heart, History,
  Shield, Users, FileAudio, ListVideo, ScrollText, Settings as SettingsIcon,
  LogOut, X, User as UserIcon, Cog,
} from "lucide-react";
import { useAuth } from "../../contexts/AuthContext";
import { Logo } from "./Logo";
import { cn } from "../../lib/utils";

const USER_MENU = [
  { to: "/dashboard", icon: LayoutDashboard, label: "Dashboard" },
  { to: "/upload", icon: Upload, label: "Upload" },
  { to: "/youtube", icon: Youtube, label: "YouTube Import" },
  { to: "/sounds", icon: Music, label: "My Sounds" },
  { to: "/roblox", icon: Gamepad2, label: "Roblox Sounds" },
  { to: "/favorites", icon: Heart, label: "Favorites" },
  { to: "/history", icon: History, label: "History" },
];

const ADMIN_MENU = [
  { to: "/admin", icon: Shield, label: "Admin Dashboard" },
  { to: "/admin/users", icon: Users, label: "Users" },
  { to: "/admin/audio", icon: FileAudio, label: "Audio Files" },
  { to: "/admin/jobs", icon: ListVideo, label: "Jobs" },
  { to: "/admin/logs", icon: ScrollText, label: "System Logs" },
  { to: "/admin/settings", icon: SettingsIcon, label: "Settings" },
];

export function Sidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const isAdmin = user?.role === "ADMIN" || user?.role === "SUPER_ADMIN";

  const linkCls = ({ isActive }: { isActive: boolean }) => cn(
    "flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm transition-all duration-200 group",
    isActive
      ? "bg-gradient-to-r from-violet-neon/25 to-transparent text-white border border-violet-neon/30 shadow-[0_0_20px_rgba(139,92,246,0.15)]"
      : "text-slate-400 hover:text-white hover:bg-white/5 border border-transparent",
  );

  return (
    <>
      {open && <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden" onClick={onClose} />}
      <aside className={cn(
        "fixed top-0 left-0 h-full w-[264px] z-50 flex flex-col transition-transform duration-300 lg:translate-x-0",
        open ? "translate-x-0" : "-translate-x-full",
      )}>
        <div className="flex-1 m-3 mb-0 glass-strong rounded-2xl flex flex-col overflow-hidden">
          <div className="flex items-center justify-between p-5 pb-4 border-b border-white/5">
            <Logo />
            <button onClick={onClose} className="lg:hidden text-slate-500 hover:text-white" aria-label="Close menu"><X size={18} /></button>
          </div>

          <nav className="flex-1 overflow-y-auto p-3 space-y-6">
            <div>
              <p className="px-3 pb-2 text-[10px] font-display font-semibold tracking-[0.25em] text-slate-600 uppercase">Menu</p>
              <div className="space-y-1">
                {USER_MENU.map((m) => (
                  <NavLink key={m.to} to={m.to} onClick={onClose} className={linkCls}>
                    <m.icon size={17} className="shrink-0 group-hover:scale-110 transition-transform" />
                    {m.label}
                  </NavLink>
                ))}
              </div>
            </div>

            {isAdmin && (
              <div>
                <p className="px-3 pb-2 text-[10px] font-display font-semibold tracking-[0.25em] text-magenta/70 uppercase">Admin Section</p>
                <div className="space-y-1">
                  {ADMIN_MENU.map((m) => (
                    <NavLink key={m.to} to={m.to} onClick={onClose} className={linkCls}>
                      <m.icon size={17} className="shrink-0 group-hover:scale-110 transition-transform" />
                      {m.label}
                    </NavLink>
                  ))}
                </div>
              </div>
            )}
          </nav>

          <div className="p-3 border-t border-white/5">
            <div className="glass rounded-xl p-3 flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-violet-neon to-magenta flex items-center justify-center font-display font-bold text-white text-sm shrink-0">
                {user?.username?.[0]?.toUpperCase() ?? "?"}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-white truncate">{user?.username}</p>
                <p className="text-[11px] text-slate-500 capitalize">{user?.role.toLowerCase()}</p>
              </div>
            </div>
            <div className="flex gap-1.5 mt-2">
              <button onClick={() => { navigate("/profile"); onClose(); }} className="flex-1 btn-ghost !py-1.5 text-xs gap-1.5" aria-label="Profile">
                <UserIcon size={13} /> Profile
              </button>
              <button onClick={() => { navigate("/settings"); onClose(); }} className="flex-1 btn-ghost !py-1.5 text-xs gap-1.5" aria-label="Settings">
                <Cog size={13} /> Settings
              </button>
              <button
                onClick={async () => { await logout(); navigate("/"); }}
                className="btn-ghost !py-1.5 text-xs !border-rose-500/30 hover:!bg-rose-500/10 text-rose-300 gap-1.5"
                aria-label="Logout"
              >
                <LogOut size={13} />
              </button>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
