import { useMemo } from "react";

export function BackgroundScene() {
  const particles = useMemo(
    () => Array.from({ length: 22 }, (_, i) => ({
      left: `${(i * 47) % 100}%`,
      top: `${(i * 61) % 100}%`,
      delay: `${(i % 9) * 1.1}s`,
      duration: `${7 + (i % 5) * 2}s`,
    })),
    [],
  );

  return (
    <div className="bg-scene" aria-hidden="true">
      <div className="blob animate-blob-1 w-[520px] h-[520px] -top-40 -left-32" style={{ background: "radial-gradient(circle, rgba(139,92,246,0.5), transparent 65%)" }} />
      <div className="blob animate-blob-2 w-[460px] h-[460px] top-1/3 -right-40" style={{ background: "radial-gradient(circle, rgba(217,70,239,0.35), transparent 65%)" }} />
      <div className="blob animate-blob-3 w-[380px] h-[380px] bottom-0 left-1/4" style={{ background: "radial-gradient(circle, rgba(56,189,248,0.22), transparent 65%)" }} />
      <div className="bg-grid" />
      <div className="bg-noise" />
      {particles.map((p, i) => (
        <span key={i} className="particle" style={{ left: p.left, top: p.top, animationDelay: p.delay, animationDuration: p.duration }} />
      ))}
    </div>
  );
}
