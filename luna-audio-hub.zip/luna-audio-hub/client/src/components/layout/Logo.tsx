import { cn } from "../../lib/utils";
import { Link } from "react-router-dom";

export function Logo({ small, to = "/", className }: { small?: boolean; to?: string; className?: string }) {
  return (
    <Link to={to} className={cn("flex items-center gap-3 group", className)}>
      <div className="relative shrink-0">
        <div className="absolute inset-0 rounded-xl bg-violet-neon/40 blur-lg group-hover:bg-violet-neon/60 transition-all" />
        <div className="relative w-10 h-10 rounded-xl bg-gradient-to-br from-violet-neon to-magenta flex items-center justify-center shadow-[0_0_20px_rgba(139,92,246,0.5)]">
          <svg viewBox="0 0 24 24" className="w-5 h-5 text-white" fill="currentColor">
            <path d="M4 18V6l3 0v8h4v4z" opacity="0.95" />
            <path d="M12 18V6l3 0v8h4v4z" opacity="0.65" />
          </svg>
        </div>
      </div>
      {!small && (
        <div className="leading-none">
          <div className="font-display font-bold text-white tracking-[0.18em] text-lg">LUNA</div>
          <div className="font-display text-[10px] tracking-[0.4em] text-violet-300/70 mt-0.5">AUDIO HUB</div>
        </div>
      )}
    </Link>
  );
}
