import { motion } from "framer-motion";
import { cn } from "../../lib/utils";

export function ProgressBar({ value, className, indeterminate }: { value: number; className?: string; indeterminate?: boolean }) {
  return (
    <div className={cn("h-2 w-full rounded-full bg-white/10 overflow-hidden relative", className)}>
      {indeterminate ? (
        <motion.div
          className="h-full w-1/3 rounded-full bg-gradient-to-r from-violet-neon to-magenta"
          animate={{ x: ["-100%", "300%"] }}
          transition={{ repeat: Infinity, duration: 1.2, ease: "easeInOut" }}
        />
      ) : (
        <motion.div
          className="h-full rounded-full bg-gradient-to-r from-violet-neon via-violet-electric to-magenta shadow-[0_0_12px_rgba(139,92,246,0.7)]"
          initial={{ width: 0 }}
          animate={{ width: `${Math.min(100, Math.max(0, value))}%` }}
          transition={{ type: "spring", stiffness: 120, damping: 20 }}
        />
      )}
    </div>
  );
}
