import { cn } from "../../lib/utils";

const STYLES: Record<string, string> = {
  READY: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
  COMPLETED: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
  UPLOADED: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
  PROCESSING: "bg-violet-500/15 text-violet-300 border-violet-500/30",
  QUEUED: "bg-sky-500/15 text-sky-300 border-sky-500/30",
  PENDING: "bg-sky-500/15 text-sky-300 border-sky-500/30",
  FAILED: "bg-rose-500/15 text-rose-300 border-rose-500/30",
  CANCELLED: "bg-slate-500/15 text-slate-400 border-slate-500/30",
};

export function StatusBadge({ status, className }: { status: string; className?: string }) {
  return (
    <span className={cn(
      "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[11px] font-display font-semibold tracking-wide uppercase",
      STYLES[status] ?? STYLES.CANCELLED,
      className,
    )}>
      <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" />
      {status}
    </span>
  );
}
