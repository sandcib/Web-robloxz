import type { ReactNode } from "react";
import { Card } from "./Card";
import { cn } from "../../lib/utils";

interface Props {
  label: string;
  value: string | number;
  icon: ReactNode;
  accent?: "violet" | "emerald" | "sky" | "rose";
}

const ACCENTS = {
  violet: "from-violet-neon/25 to-violet-neon/5 text-violet-300",
  emerald: "from-emerald-500/25 to-emerald-500/5 text-emerald-300",
  sky: "from-sky-500/25 to-sky-500/5 text-sky-300",
  rose: "from-rose-500/25 to-rose-500/5 text-rose-300",
};

export function StatCard({ label, value, icon, accent = "violet" }: Props) {
  return (
    <Card className="relative overflow-hidden group">
      <div className={cn("absolute -right-6 -top-6 w-24 h-24 rounded-full bg-gradient-to-br blur-2xl opacity-40 group-hover:opacity-70 transition-opacity", ACCENTS[accent])} />
      <div className="flex items-start justify-between relative">
        <div>
          <p className="text-[11px] font-display font-semibold tracking-[0.18em] text-slate-500 uppercase">{label}</p>
          <p className="mt-2 font-display text-3xl font-bold text-white">{value}</p>
        </div>
        <div className={cn("rounded-xl bg-gradient-to-br p-2.5", ACCENTS[accent])}>{icon}</div>
      </div>
    </Card>
  );
}
