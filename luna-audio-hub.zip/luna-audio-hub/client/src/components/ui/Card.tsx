import type { HTMLAttributes, ReactNode } from "react";
import { motion } from "framer-motion";
import { cn } from "../../lib/utils";

interface Props extends HTMLAttributes<HTMLDivElement> {
  glow?: boolean;
  children: ReactNode;
}

export function Card({ glow, className, children, ...rest }: Props) {
  return (
    <motion.div
      whileHover={{ y: -3 }}
      transition={{ type: "spring", stiffness: 300, damping: 22 }}
      className={cn("glass p-5", glow && "neon-border shadow-[0_0_40px_rgba(139,92,246,0.12)]", className)}
      {...(rest as object)}
    >
      {children}
    </motion.div>
  );
}
