import { cn } from "../../lib/utils";

export function SkeletonCard({ className }: { className?: string }) {
  return (
    <div className={cn("glass p-5 space-y-4", className)}>
      <div className="skeleton h-36 w-full" />
      <div className="skeleton h-4 w-2/3" />
      <div className="skeleton h-3 w-1/3" />
    </div>
  );
}

export function SkeletonRow() {
  return (
    <div className="flex items-center gap-4 py-3">
      <div className="skeleton w-10 h-10 rounded-full shrink-0" />
      <div className="flex-1 space-y-2">
        <div className="skeleton h-3.5 w-1/2" />
        <div className="skeleton h-3 w-1/4" />
      </div>
      <div className="skeleton h-6 w-20 rounded-full" />
    </div>
  );
}

export function SkeletonStats() {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} className="glass p-5"><div className="skeleton h-4 w-1/2 mb-3" /><div className="skeleton h-8 w-1/3" /></div>
      ))}
    </div>
  );
}
