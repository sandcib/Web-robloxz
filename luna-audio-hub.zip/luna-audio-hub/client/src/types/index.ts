export type Role = "USER" | "ADMIN" | "SUPER_ADMIN";
export type AudioStatus = "QUEUED" | "PROCESSING" | "READY" | "FAILED";
export type JobStatus = "QUEUED" | "PROCESSING" | "COMPLETED" | "FAILED" | "CANCELLED";

export interface User {
  id: string;
  email: string;
  username: string;
  role: Role;
  avatarUrl: string | null;
  storageUsed?: number;
  totalSounds?: number;
  createdAt: string;
  lastLoginAt?: string | null;
}

export interface Audio {
  id: string;
  title: string;
  description?: string | null;
  category?: string | null;
  tags: string[];
  coverUrl?: string | null;
  fileUrl: string;
  originalName?: string;
  duration: number;
  size: number;
  bitrate?: number | null;
  format: string;
  status: AudioStatus;
  soundId?: string | null;
  isFavorite?: boolean;
  createdAt: string;
}

export interface ProcessingJob {
  id: string;
  type: "CONVERT" | "NORMALIZE" | "TRIM";
  status: JobStatus;
  progress: number;
  error?: string | null;
  createdAt: string;
  audio?: { id: string; title: string; format?: string; user?: { username: string } };
}

export interface HistoryItem {
  id: string;
  action: string;
  target?: string | null;
  createdAt: string;
}

export interface Notification {
  id: string;
  type: "success" | "error" | "warning" | "info";
  title: string;
  body?: string | null;
  read: boolean;
  createdAt: string;
}

export interface AuditLogItem {
  id: string;
  action: string;
  target?: string | null;
  ip?: string | null;
  userAgent?: string | null;
  createdAt: string;
  user?: { username: string } | null;
}

export interface ApiOk<T> { success: true; data: T; }
export interface ApiErr { success: false; message: string; code: string; }
export type ApiRes<T> = ApiOk<T> | ApiErr;

export interface Paginated<T> {
  items: T[];
  total: number;
  page: number;
  pages: number;
}
