import { useEffect, useState } from "react";
import { Outlet } from "react-router-dom";
import { Sidebar } from "../components/layout/Sidebar";
import { Header } from "../components/layout/Header";
import { GlobalPlayer } from "../components/layout/GlobalPlayer";
import { CommandPalette } from "../components/layout/CommandPalette";
import { BackgroundScene } from "../components/layout/BackgroundScene";

export function AppLayout() {
  const [menuOpen, setMenuOpen] = useState(false);

  // Keyboard shortcuts: Ctrl+K search, Ctrl+U upload, Space play/pause
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const typing = ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName);
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        window.dispatchEvent(new CustomEvent("open-command"));
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "u") {
        e.preventDefault();
        window.location.href = "/upload";
      }
      if (e.code === "Space" && !typing) {
        e.preventDefault();
        window.dispatchEvent(new CustomEvent("toggle-play"));
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <div className="min-h-screen">
      <BackgroundScene />
      <Sidebar open={menuOpen} onClose={() => setMenuOpen(false)} />
      <Header onMenu={() => setMenuOpen(true)} />
      <main className="px-3 lg:pl-[280px] py-6 pb-36">
        <div className="max-w-[1400px] mx-auto">
          <Outlet />
        </div>
      </main>
      <GlobalPlayer />
      <CommandPalette />
    </div>
  );
}
