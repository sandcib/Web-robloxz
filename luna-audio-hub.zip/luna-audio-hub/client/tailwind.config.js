/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        void: "#05030A",
        abyss: "#0B0614",
        deep: "#120820",
        panel: "rgba(139, 92, 246, 0.06)",
        violet: {
          neon: "#8B5CF6",
          electric: "#A855F7",
        },
        magenta: "#D946EF",
        electric: "#38BDF8",
      },
      fontFamily: {
        thai: ["'Noto Sans Thai'", "'IBM Plex Sans Thai'", "sans-serif"],
        display: ["'Space Grotesk'", "'Noto Sans Thai'", "sans-serif"],
        mono: ["'JetBrains Mono'", "monospace"],
      },
      animation: {
        "spin-slow": "spin 3s linear infinite",
        "pulse-glow": "pulseGlow 2.5s ease-in-out infinite",
        float: "float 7s ease-in-out infinite",
        "float-slow": "float 11s ease-in-out infinite",
        shimmer: "shimmer 2.2s linear infinite",
        "blob-1": "blob1 18s ease-in-out infinite",
        "blob-2": "blob2 22s ease-in-out infinite",
        "blob-3": "blob3 26s ease-in-out infinite",
        "wave-bar": "waveBar 1.1s ease-in-out infinite",
      },
      keyframes: {
        pulseGlow: {
          "0%, 100%": { boxShadow: "0 0 20px rgba(139,92,246,0.35)" },
          "50%": { boxShadow: "0 0 45px rgba(139,92,246,0.6)" },
        },
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-16px)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
        blob1: {
          "0%, 100%": { transform: "translate(0,0) scale(1)" },
          "33%": { transform: "translate(60px,-40px) scale(1.15)" },
          "66%": { transform: "translate(-40px,50px) scale(0.9)" },
        },
        blob2: {
          "0%, 100%": { transform: "translate(0,0) scale(1)" },
          "50%": { transform: "translate(-70px,30px) scale(1.2)" },
        },
        blob3: {
          "0%, 100%": { transform: "translate(0,0) scale(1)" },
          "50%": { transform: "translate(50px,60px) scale(0.85)" },
        },
        waveBar: {
          "0%, 100%": { transform: "scaleY(0.3)" },
          "50%": { transform: "scaleY(1)" },
        },
      },
      backdropBlur: { xs: "2px" },
    },
  },
  plugins: [],
};
