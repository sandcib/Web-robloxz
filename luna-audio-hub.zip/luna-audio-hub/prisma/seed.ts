import { PrismaClient, Role } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const hash = await bcrypt.hash("Admin@1234", 12);

  const admin = await prisma.user.upsert({
    where: { email: "admin@luna.dev" },
    update: {},
    create: {
      email: "admin@luna.dev",
      username: "luna_admin",
      passwordHash: hash,
      role: Role.SUPER_ADMIN,
    },
  });

  await prisma.user.upsert({
    where: { email: "mod@luna.dev" },
    update: {},
    create: {
      email: "mod@luna.dev",
      username: "luna_mod",
      passwordHash: hash,
      role: Role.ADMIN,
    },
  });

  const demoHash = await bcrypt.hash("Demo@1234", 12);
  const demo = await prisma.user.upsert({
    where: { email: "demo@luna.dev" },
    update: {},
    create: {
      email: "demo@luna.dev",
      username: "demo_user",
      passwordHash: demoHash,
      role: Role.USER,
    },
  });

  // Demo sounds (ไฟล์จริงต้องอัปโหลดเอง — นี่เป็น dev seed data เท่านั้น)
  const demoSounds = ["DEMO FANTA MUSIC", "DEMO LIVE MUSIC", "LUNA NIGHT", "PURPLE DREAM"];
  for (const title of demoSounds) {
    const exists = await prisma.audio.findFirst({ where: { userId: demo.id, title } });
    if (!exists) {
      const audio = await prisma.audio.create({
        data: {
          userId: demo.id,
          title,
          fileUrl: `/uploads/demo/${title.toLowerCase().replace(/ /g, "-")}.mp3`,
          originalName: `${title}.mp3`,
          mimeType: "audio/mpeg",
          size: BigInt(3_500_000),
          duration: 180,
          bitrate: 192,
          format: "mp3",
          status: "READY",
          tags: ["demo"],
        },
      });
      await prisma.history.create({
        data: { userId: demo.id, action: "UPLOADED", target: title },
      });
      await prisma.processingJob.create({
        data: { audioId: audio.id, type: "CONVERT", status: "COMPLETED", progress: 100 },
      });
    }
  }

  // Default settings
  const defaults: Record<string, unknown> = {
    maxUploadSize: 52428800,
    maxAudioDuration: 600,
    allowedFileTypes: ["mp3", "wav", "ogg", "m4a"],
    defaultBitrate: 192,
    storageLimitMb: 2048,
    maintenanceMode: false,
    discordLoggingEnabled: false,
    siteName: "LUNA AUDIO HUB",
    primaryColor: "#8B5CF6",
    accentColor: "#D946EF",
  };
  for (const [key, value] of Object.entries(defaults)) {
    await prisma.systemSetting.upsert({ where: { key }, update: {}, create: { key, value } });
  }

  console.log("✅ Seed complete:", { admin: admin.email, demo: demo.email });
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
