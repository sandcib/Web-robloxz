// Types ที่ใช้ร่วมกันระหว่าง client/server (เพื่ออ้างอิงโครงสร้างเดียวกัน)
export * from "../client/src/types";
