import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma.js";
import { ok } from "../utils/response.js";

const router = Router();

router.get("/", async (req, res, next) => {
  try {
    const q = z.object({ page: z.coerce.number().min(1).default(1), limit: z.coerce.number().min(1).max(100).default(30) }).parse(req.query);
    const [total, items] = await Promise.all([
      prisma.history.count({ where: { userId: req.user!.id } }),
      prisma.history.findMany({
        where: { userId: req.user!.id },
        orderBy: { createdAt: "desc" },
        skip: (q.page - 1) * q.limit, take: q.limit,
      }),
    ]);
    return ok(res, { items, total, page: q.page, pages: Math.ceil(total / q.limit) });
  } catch (e) { next(e); }
});

export default router;
