import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { ok } from "../utils/response.js";

const router = Router();

router.get("/", async (req, res, next) => {
  try {
    const [items, unread] = await Promise.all([
      prisma.notification.findMany({ where: { userId: req.user!.id }, orderBy: { createdAt: "desc" }, take: 30 }),
      prisma.notification.count({ where: { userId: req.user!.id, read: false } }),
    ]);
    return ok(res, { items, unread });
  } catch (e) { next(e); }
});

router.post("/read-all", async (req, res, next) => {
  try {
    await prisma.notification.updateMany({ where: { userId: req.user!.id, read: false }, data: { read: true } });
    return ok(res, { read: true });
  } catch (e) { next(e); }
});

export default router;
