import { Router } from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import crypto from "crypto";
import { z } from "zod";
import { config } from "../config.js";
import { prisma } from "../lib/prisma.js";
import { ok, fail } from "../utils/response.js";
import { audit } from "../services/audit.js";
import { notify } from "../services/notify.js";
import { sendDiscordLog } from "../services/discord.js";
import { uploadLimiter } from "../middleware/rateLimit.js";

const router = Router();

const ALLOWED_AUDIO: Record<string, string> = {
  "audio/mpeg": ".mp3",
  "audio/wav": ".wav",
  "audio/x-wav": ".wav",
  "audio/ogg": ".ogg",
  "audio/mp4": ".m4a",
  "audio/x-m4a": ".m4a",
};
const ALLOWED_IMAGES: Record<string, string> = {
  "image/png": ".png",
  "image/jpeg": ".jpg",
  "image/webp": ".webp",
};

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, path.resolve(config.storagePath)),
  filename: (_req, file, cb) => cb(null, `${Date.now()}-${crypto.randomBytes(8).toString("hex")}${path.extname(file.originalname).toLowerCase()}`),
});

const upload = multer({
  storage,
  limits: { fileSize: config.maxUploadSize, files: 1 },
  fileFilter: (_req, file, cb) => {
    const allowed = { ...ALLOWED_AUDIO, ...ALLOWED_IMAGES };
    if (!allowed[file.mimetype]) return cb(new Error("UNSUPPORTED_FILE_TYPE"));
    cb(null, true);
  },
});

/** กัน path traversal: ต้องอยู่ใน storage dir และเป็นไฟล์ของ audio นั้น */
export function safeAudioPath(rel: string): string | null {
  const clean = path.basename(rel);
  const full = path.resolve(config.storagePath, clean);
  if (!full.startsWith(path.resolve(config.storagePath) + path.sep)) return null;
  if (!fs.existsSync(full)) return null;
  return full;
}

router.post("/upload", uploadLimiter, upload.single("file"), async (req, res, next) => {
  try {
    if (!req.file) return fail(res, 400, "No file provided", "NO_FILE");
    const isAudio = req.file.mimetype in ALLOWED_AUDIO;

    const body = z.object({
      title: z.string().min(1).max(120).optional(),
      description: z.string().max(1000).optional(),
      category: z.string().max(50).optional(),
      tags: z.string().max(300).optional(), // comma separated
      coverUrl: z.string().max(500).optional(),
    }).parse(req.body ?? {});

    // storage limit ต่อ user
    const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
    const agg = await prisma.audio.aggregate({ where: { userId: req.user!.id, deleted: false }, _sum: { size: true } });
    const used = Number(agg._sum.size ?? 0);
    if (used + req.file.size > config.storageLimitMb * 1024 * 1024) {
      fs.unlinkSync(req.file.path);
      return fail(res, 413, "Storage limit exceeded", "STORAGE_LIMIT");
    }

    if (!isAudio) {
      // cover image upload เดี่ยว
      const rel = `/uploads/${path.basename(req.file.path)}`;
      return ok(res, { coverUrl: rel }, 201);
    }

    const rel = `/uploads/${path.basename(req.file.path)}`;
    const ext = (path.extname(req.file.originalname) || ALLOWED_AUDIO[req.file.mimetype] || ".bin").replace(".", "");
    const audio = await prisma.audio.create({
      data: {
        userId: req.user!.id,
        title: body.title || path.basename(req.file.originalname, path.extname(req.file.originalname)),
        description: body.description,
        category: body.category,
        tags: body.tags ? body.tags.split(",").map((t) => t.trim()).filter(Boolean).slice(0, 10) : [],
        coverUrl: body.coverUrl || null,
        fileUrl: rel,
        originalName: req.file.originalname.slice(0, 200),
        mimeType: req.file.mimetype,
        size: BigInt(req.file.size),
        format: ext,
        status: "READY",
        user: { update: { storageUsed: { increment: BigInt(req.file.size) } } },
      },
    });

    await prisma.history.create({ data: { userId: req.user!.id, action: "UPLOADED", target: audio.title } });
    await notify(req.user!.id, "success", "Upload complete", `${audio.title} uploaded successfully.`);
    await sendDiscordLog("📤 Audio uploaded", `**${audio.title}** by ${user?.username} (${(req.file.size / 1024 / 1024).toFixed(2)} MB)`);
    await audit(req, "UPLOAD", audio.title);
    return ok(res, audio, 201);
  } catch (e) { next(e); }
});

router.get("/", async (req, res, next) => {
  try {
    const q = z.object({
      page: z.coerce.number().min(1).default(1),
      limit: z.coerce.number().min(1).max(50).default(12),
      search: z.string().max(100).optional(),
      status: z.enum(["QUEUED", "PROCESSING", "READY", "FAILED"]).optional(),
      favorites: z.coerce.boolean().optional(),
      sort: z.enum(["newest", "oldest", "name", "duration"]).default("newest"),
    }).parse(req.query);

    const where: Record<string, unknown> = { userId: req.user!.id, deleted: false };
    if (q.search) where.title = { contains: q.search, mode: "insensitive" };
    if (q.status) where.status = q.status;
    if (q.favorites) where.favorites = { some: { userId: req.user!.id } };

    const orderBy =
      q.sort === "oldest" ? { createdAt: "asc" as const } :
      q.sort === "name" ? { title: "asc" as const } :
      q.sort === "duration" ? { duration: "desc" as const } :
      { createdAt: "desc" as const };

    const [total, items] = await Promise.all([
      prisma.audio.count({ where }),
      prisma.audio.findMany({
        where, orderBy, skip: (q.page - 1) * q.limit, take: q.limit,
        include: { favorites: { where: { userId: req.user!.id }, select: { id: true } } },
      }),
    ]);

    return ok(res, {
      items: items.map((a) => ({ ...a, size: Number(a.size), isFavorite: a.favorites.length > 0 })),
      total, page: q.page, pages: Math.ceil(total / q.limit),
    });
  } catch (e) { next(e); }
});

router.get("/:id", async (req, res, next) => {
  try {
    const audio = await prisma.audio.findFirst({
      where: { id: req.params.id, userId: req.user!.id, deleted: false },
      include: { jobs: { orderBy: { createdAt: "desc" }, take: 5 }, favorites: { where: { userId: req.user!.id } } },
    });
    if (!audio) return fail(res, 404, "Audio not found", "NOT_FOUND");
    return ok(res, { ...audio, size: Number(audio.size), isFavorite: audio.favorites.length > 0 });
  } catch (e) { next(e); }
});

router.patch("/:id", async (req, res, next) => {
  try {
    const audio = await prisma.audio.findFirst({ where: { id: req.params.id, userId: req.user!.id, deleted: false } });
    if (!audio) return fail(res, 404, "Audio not found", "NOT_FOUND");
    const body = z.object({
      title: z.string().min(1).max(120).optional(),
      description: z.string().max(1000).nullable().optional(),
      category: z.string().max(50).nullable().optional(),
      tags: z.string().max(300).optional(),
      coverUrl: z.string().max(500).nullable().optional(),
    }).parse(req.body);
    const updated = await prisma.audio.update({
      where: { id: audio.id },
      data: {
        ...(body.title !== undefined && { title: body.title }),
        ...(body.description !== undefined && { description: body.description }),
        ...(body.category !== undefined && { category: body.category }),
        ...(body.tags !== undefined && { tags: body.tags.split(",").map((t) => t.trim()).filter(Boolean).slice(0, 10) }),
        ...(body.coverUrl !== undefined && { coverUrl: body.coverUrl }),
      },
    });
    return ok(res, { ...updated, size: Number(updated.size) });
  } catch (e) { next(e); }
});

router.delete("/:id", async (req, res, next) => {
  try {
    const audio = await prisma.audio.findFirst({ where: { id: req.params.id, userId: req.user!.id, deleted: false } });
    if (!audio) return fail(res, 404, "Audio not found", "NOT_FOUND");

    await prisma.audio.update({ where: { id: audio.id }, data: { deleted: true } });
    const abs = safeAudioPath(audio.fileUrl);
    if (abs && audio.fileUrl.includes("/uploads/")) {
      try { fs.unlinkSync(abs); } catch { /* already gone */ }
    }
    await prisma.history.create({ data: { userId: req.user!.id, action: "DELETED", target: audio.title } });
    await notify(req.user!.id, "info", "Audio deleted", audio.title);
    await audit(req, "DELETE", audio.title);
    return ok(res, { deleted: true });
  } catch (e) { next(e); }
});

router.get("/:id/download", async (req, res, next) => {
  try {
    const audio = await prisma.audio.findFirst({ where: { id: req.params.id, userId: req.user!.id, deleted: false } });
    if (!audio) return fail(res, 404, "Audio not found", "NOT_FOUND");
    const abs = safeAudioPath(audio.fileUrl);
    if (!abs) return fail(res, 404, "File missing on disk", "FILE_MISSING");
    await prisma.history.create({ data: { userId: req.user!.id, action: "DOWNLOADED", target: audio.title } });
    res.download(abs, audio.originalName || `${audio.title}.${audio.format}`);
  } catch (e) { next(e); }
});

// สร้าง processing job (convert/normalize/trim)
router.post("/:id/process", async (req, res, next) => {
  try {
    const audio = await prisma.audio.findFirst({ where: { id: req.params.id, userId: req.user!.id, deleted: false } });
    if (!audio) return fail(res, 404, "Audio not found", "NOT_FOUND");
    if (audio.status === "PROCESSING") return fail(res, 409, "Already processing", "ALREADY_PROCESSING");

    const body = z.object({
      type: z.enum(["CONVERT", "NORMALIZE", "TRIM"]),
      format: z.enum(["mp3", "ogg", "wav"]).optional(),
      bitrate: z.union([z.literal(128), z.literal(192), z.literal(256), z.literal(320)]).optional(),
      trimStart: z.number().min(0).optional(),
      trimEnd: z.number().min(0).optional(),
      normalize: z.boolean().optional(),
    }).parse(req.body);

    const options: Record<string, unknown> = {};
    if (body.type === "CONVERT") {
      options.format = body.format || "mp3";
      options.bitrate = body.bitrate || audio.bitrate || 192;
    }
    if (body.type === "NORMALIZE") options.normalize = true;
    if (body.type === "TRIM") {
      if (body.trimStart === undefined || body.trimEnd === undefined || body.trimEnd <= body.trimStart)
        return fail(res, 400, "Invalid trim range", "INVALID_TRIM");
      if (body.trimEnd - body.trimStart > config.maxAudioDuration)
        return fail(res, 400, `Trim exceeds maximum duration (${config.maxAudioDuration}s)`, "DURATION_LIMIT");
      options.trimStart = body.trimStart;
      options.trimEnd = body.trimEnd;
    }

    const job = await prisma.processingJob.create({
      data: { audioId: audio.id, type: body.type, options },
    });
    await notify(req.user!.id, "info", "Processing queued", `${audio.title} added to queue.`);
    return ok(res, job, 201);
  } catch (e) { next(e); }
});

export default router;
