import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { ok, fail } from "../utils/response.js";

const router = Router();

router.post("/:audioId", async (req, res, next) => {
  try {
    const audio = await prisma.audio.findFirst({ where: { id: req.params.audioId, deleted: false } });
    if (!audio) return fail(res, 404, "Audio not found", "NOT_FOUND");
    const fav = await prisma.favorite.upsert({
      where: { userId_audioId: { userId: req.user!.id, audioId: audio.id } },
      update: {},
      create: { userId: req.user!.id, audioId: audio.id },
    });
    await prisma.history.create({ data: { userId: req.user!.id, action: "FAVORITED", target: audio.title } });
    return ok(res, fav, 201);
  } catch (e) { next(e); }
});

router.delete("/:audioId", async (req, res, next) => {
  try {
    await prisma.favorite.deleteMany({ where: { userId: req.user!.id, audioId: req.params.audioId } });
    return ok(res, { removed: true });
  } catch (e) { next(e); }
});

export default router;
