import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma.js";
import { ok } from "../utils/response.js";

const router = Router();

router.get("/", async (req, res, next) => {
  try {
    const { q } = z.object({ q: z.string().min(1).max(100) }).parse(req.query);
    const [sounds, pages] = await Promise.all([
      prisma.audio.findMany({
        where: { userId: req.user!.id, deleted: false, title: { contains: q, mode: "insensitive" } },
        select: { id: true, title: true, status: true, format: true, duration: true },
        take: 6, orderBy: { createdAt: "desc" },
      }),
      prisma.audio.findMany({
        where: { userId: req.user!.id, deleted: false, tags: { has: q.toLowerCase() } },
        select: { id: true, title: true }, take: 4,
      }),
    ]);
    return ok(res, { sounds, tags: pages });
  } catch (e) { next(e); }
});

export default router;
