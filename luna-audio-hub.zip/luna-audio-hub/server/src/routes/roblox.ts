import { Router } from "express";
import { z } from "zod";
import { robloxConfigured } from "../config.js";
import { prisma } from "../lib/prisma.js";
import { ok, fail } from "../utils/response.js";
import { audit } from "../services/audit.js";
import { notify } from "../services/notify.js";
import { sendDiscordLog } from "../services/discord.js";

const router = Router();

router.get("/status", (_req, res) => {
  // ไม่เปิดเผย secret — แค่บอกว่า configured หรือไม่
  return ok(res, { configured: robloxConfigured() });
});

router.post("/upload/:audioId", async (req, res, next) => {
  try {
    if (!robloxConfigured())
      return fail(res, 503, "Roblox upload integration is not configured", "ROBLOX_NOT_CONFIGURED");

    const audio = await prisma.audio.findFirst({ where: { id: req.params.audioId, userId: req.user!.id, deleted: false } });
    if (!audio) return fail(res, 404, "Audio not found", "NOT_FOUND");
    if (audio.status !== "READY") return fail(res, 409, "Audio must be READY before Roblox upload", "NOT_READY");

    z.object({ description: z.string().max(200).optional() }).parse(req.body ?? {});

    // ── เรียก Roblox Cloud API จริง ──────────────────────────────
    // Docs: https://create.roblox.com/docs/cloud/open-cloud/usage-data-stores
    // ใช้ Assets API (beta): POST https://apis.roblox.com/assets/v1/assets
    const response = await fetch("https://apis.roblox.com/assets/v1/assets", {
      method: "POST",
      headers: {
        "x-api-key": process.env.ROBLOX_API_KEY!,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        assetType: "Audio",
        displayName: audio.title,
        description: req.body?.description || `Uploaded via LUNA AUDIO HUB`,
        creationContext: {
          creator: { userId: process.env.ROBLOX_CREATOR_ID || undefined },
        },
      }),
    });

    if (!response.ok) {
      const text = await response.text();
      const asset = await prisma.robloxAsset.create({
        data: { audioId: audio.id, status: "FAILED", error: `Roblox API ${response.status}: ${text.slice(0, 300)}` },
      });
      await audit(req, "ROBLOX_UPLOAD_FAILED", audio.title);
      return fail(res, 502, `Roblox API rejected the upload: ${text.slice(0, 120)}`, "ROBLOX_API_ERROR");
    }

    const data = await response.json() as { assetId?: string; operationId?: string };
    const asset = await prisma.robloxAsset.create({
      data: { audioId: audio.id, assetId: data.assetId ?? null, status: data.assetId ? "UPLOADED" : "PROCESSING" },
    });
    if (data.assetId) {
      await prisma.audio.update({ where: { id: audio.id }, data: { soundId: data.assetId } });
    }
    await prisma.history.create({ data: { userId: req.user!.id, action: "ROBLOX_UPLOADED", target: audio.title } });
    await notify(req.user!.id, "success", "Roblox upload complete", `${audio.title} → ID ${data.assetId ?? "pending"}`);
    await sendDiscordLog("🎮 Roblox upload", `**${audio.title}** → Asset ${data.assetId ?? "pending"}`);
    await audit(req, "ROBLOX_UPLOAD", audio.title);
    return ok(res, asset, 201);
  } catch (e) { next(e); }
});

router.get("/assets", async (req, res, next) => {
  try {
    const items = await prisma.robloxAsset.findMany({
      where: { audio: { userId: req.user!.id, deleted: false } },
      include: { audio: { select: { id: true, title: true, coverUrl: true, duration: true, format: true, soundId: true } } },
      orderBy: { createdAt: "desc" }, take: 50,
    });
    return ok(res, { items });
  } catch (e) { next(e); }
});

export default router;
