import { Router, type Response } from "express";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "../lib/prisma.js";
import { createToken, randomToken } from "../utils/tokens.js";
import { ok, fail } from "../utils/response.js";
import { requireAuth } from "../middleware/auth.js";
import { audit } from "../services/audit.js";
import { sendDiscordLog } from "../services/discord.js";
import { config } from "../config.js";

const router = Router();

const registerSchema = z.object({
  email: z.string().email("Invalid email"),
  username: z.string().min(3, "Username must be at least 3 characters").max(30).regex(/^[a-zA-Z0-9_]+$/, "Username may only contain letters, numbers, underscores"),
  password: z.string().min(8, "Password must be at least 8 characters").max(100),
});

function setSessionCookie(res: Response, token: string) {
  res.cookie("luna_token", token, {
    httpOnly: true,
    sameSite: "lax",
    secure: config.nodeEnv === "production",
    maxAge: config.sessionExpiryDays * 24 * 3600 * 1000,
    path: "/",
  });
}

router.post("/register", async (req, res, next) => {
  try {
    const body = registerSchema.parse(req.body);
    const exists = await prisma.user.findFirst({
      where: { OR: [{ email: body.email.toLowerCase() }, { username: body.username }] },
    });
    if (exists) return fail(res, 409, "Email or username already in use", "EMAIL_TAKEN");

    const passwordHash = await bcrypt.hash(body.password, 12);
    const user = await prisma.user.create({
      data: {
        email: body.email.toLowerCase(),
        username: body.username,
        passwordHash,
        sessions: {
          create: {
            token: randomToken(),
            expiresAt: new Date(Date.now() + config.sessionExpiryDays * 24 * 3600 * 1000),
            ip: req.ip,
            userAgent: req.headers["user-agent"]?.slice(0, 300),
          },
        },
      },
      include: { sessions: true },
    });

    const token = createToken(user.id, user.role);
    await prisma.session.update({ where: { id: user.sessions[0].id }, data: { token } });
    setSessionCookie(res, token);
    await sendDiscordLog("🆕 New user registered", `**${user.username}** (${user.email})`);
    return ok(res, { user: publicUser(user), token }, 201);
  } catch (e) { next(e); }
});

router.post("/login", async (req, res, next) => {
  try {
    const body = z.object({ email: z.string().email(), password: z.string() }).parse(req.body);
    const user = await prisma.user.findUnique({ where: { email: body.email.toLowerCase() } });
    if (!user || !(await bcrypt.compare(body.password, user.passwordHash)))
      return fail(res, 401, "Invalid email or password", "INVALID_CREDENTIALS");
    if (user.banned) return fail(res, 403, "Account banned", "ACCOUNT_BANNED");

    const token = createToken(user.id, user.role);
    await prisma.session.create({
      data: {
        token,
        userId: user.id,
        expiresAt: new Date(Date.now() + config.sessionExpiryDays * 24 * 3600 * 1000),
        ip: req.ip,
        userAgent: req.headers["user-agent"]?.slice(0, 300),
      },
    });
    await prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });
    await audit(req, "LOGIN", user.username);
    setSessionCookie(res, token);
    return ok(res, { user: publicUser(user), token });
  } catch (e) { next(e); }
});

router.post("/logout", requireAuth, async (req, res, next) => {
  try {
    const header = req.headers.authorization;
    const token = header?.startsWith("Bearer ") ? header.slice(7) : req.cookies?.luna_token;
    if (token) await prisma.session.deleteMany({ where: { token } });
    await audit(req, "LOGOUT");
    res.clearCookie("luna_token", { path: "/" });
    return ok(res, { loggedOut: true });
  } catch (e) { next(e); }
});

function publicUser(u: { id: string; email: string; username: string; role: string; avatarUrl: string | null; createdAt: Date; storageUsed: bigint; lastLoginAt: Date | null }) {
  return {
    id: u.id, email: u.email, username: u.username, role: u.role,
    avatarUrl: u.avatarUrl, createdAt: u.createdAt,
    storageUsed: Number(u.storageUsed), lastLoginAt: u.lastLoginAt,
  };
}

export default router;
