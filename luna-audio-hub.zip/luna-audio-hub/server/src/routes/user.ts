import { Router } from "express";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "../lib/prisma.js";
import { ok, fail } from "../utils/response.js";
import { audit } from "../services/audit.js";

const router = Router();

router.get("/me", async (req, res, next) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user!.id },
      select: { id: true, email: true, username: true, role: true, avatarUrl: true, storageUsed: true, createdAt: true, lastLoginAt: true },
    });
    if (!user) return fail(res, 404, "User not found", "NOT_FOUND");

    const [totalSounds, favoriteCount] = await Promise.all([
      prisma.audio.count({ where: { userId: user.id, deleted: false } }),
      prisma.favorite.count({ where: { userId: user.id } }),
    ]);
    return ok(res, { ...user, storageUsed: Number(user.storageUsed), totalSounds, favoriteCount });
  } catch (e) { next(e); }
});

router.patch("/me", async (req, res, next) => {
  try {
    const body = z.object({
      username: z.string().min(3).max(30).regex(/^[a-zA-Z0-9_]+$/).optional(),
      avatarUrl: z.string().max(500).nullable().optional(),
      currentPassword: z.string().optional(),
      newPassword: z.string().min(8).max(100).optional(),
    }).parse(req.body);

    const user = await prisma.user.findUnique({ where: { id: req.user!.id } });
    if (!user) return fail(res, 404, "User not found", "NOT_FOUND");

    const data: Record<string, unknown> = {};
    if (body.username) {
      const taken = await prisma.user.findFirst({ where: { username: body.username, id: { not: user.id } } });
      if (taken) return fail(res, 409, "Username already taken", "USERNAME_TAKEN");
      data.username = body.username;
    }
    if (body.avatarUrl !== undefined) data.avatarUrl = body.avatarUrl;
    if (body.newPassword) {
      if (!body.currentPassword || !(await bcrypt.compare(body.currentPassword, user.passwordHash)))
        return fail(res, 400, "Current password is incorrect", "INVALID_PASSWORD");
      data.passwordHash = await bcrypt.hash(body.newPassword, 12);
      // revoke other sessions
      await prisma.session.deleteMany({ where: { userId: user.id } });
    }
    const updated = await prisma.user.update({ where: { id: user.id }, data, select: { id: true, username: true, avatarUrl: true } });
    await audit(req, "PROFILE_UPDATED");
    return ok(res, updated);
  } catch (e) { next(e); }
});

router.get("/storage", async (req, res, next) => {
  try {
    const user = await prisma.user.findUnique({ where: { id: req.user!.id }, select: { storageUsed: true } });
    const agg = await prisma.audio.aggregate({ where: { userId: req.user!.id, deleted: false }, _sum: { size: true } });
    return ok(res, { storageUsed: Number(agg._sum.size ?? user?.storageUsed ?? 0) });
  } catch (e) { next(e); }
});

export default router;
