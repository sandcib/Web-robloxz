import { Router } from "express";
import fs from "fs";
import { z } from "zod";
import { config } from "../config.js";
import { ok, fail } from "../utils/response.js";
import { prisma } from "../lib/prisma.js";
import { notify } from "../services/notify.js";

const router = Router();

const ytUrlSchema = z.string().url().refine(
  (u) => /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\//.test(u),
  "Invalid YouTube URL"
);

router.post("/validate", async (req, res, next) => {
  try {
    const { url } = z.object({ url: ytUrlSchema }).parse(req.body);
    // ไม่มี API key ภายนอก → validate ด้วย oEmbed สาธารณะของ YouTube (ไม่ต้องใช้ key)
    const oembed = await fetch(`https://www.youtube.com/oembed?url=${encodeURIComponent(url)}&format=json`);
    if (!oembed.ok) return fail(res, 400, "Could not fetch video info (video may be private/deleted)", "YOUTUBE_FETCH_FAILED");

    const info = await oembed.json() as { title: string; author_name: string; thumbnail_url: string; };
    // ดึง duration จริงผ่าน yt-dlp ถ้ามีในระบบ (optional)
    let duration = 0;
    try {
      const { spawn } = await import("child_process");
      const idMatch = url.match(/(?:v=|\/|shorts\/)([\w-]{11})/);
      if (idMatch) {
        const out = await new Promise<string>((resolve) => {
          const p = spawn("yt-dlp", ["--get-duration", "--no-playlist", `https://www.youtube.com/watch?v=${idMatch[1]}`]);
          let s = ""; p.stdout.on("data", (c: Buffer) => (s += c.toString()));
          p.on("close", () => resolve(s.trim()));
          p.on("error", () => resolve(""));
        });
        const parts = out.split(":").map(Number);
        duration = parts.length === 3 ? parts[0] * 3600 + parts[1] * 60 + parts[2] : parts.length === 2 ? parts[0] * 60 + parts[1] : Number(out) || 0;
      }
    } catch { /* yt-dlp ไม่มีก็ข้าม */ }

    if (duration > config.maxAudioDuration)
      return fail(res, 400, `Video exceeds maximum duration of ${config.maxAudioDuration}s`, "DURATION_LIMIT");

    return ok(res, {
      title: info.title, channel: info.author_name, thumbnail: info.thumbnail_url, duration, valid: true,
      warning: "ใช้เฉพาะคอนเทนต์ที่คุณเป็นเจ้าของหรือได้รับอนุญาตให้ดาวน์โหลด/แปลงเท่านั้น",
    });
  } catch (e) { next(e); }
});

router.post("/import", async (req, res, next) => {
  try {
    const body = z.object({
      url: ytUrlSchema,
      title: z.string().min(1).max(120),
      trimStart: z.number().min(0).default(0),
      trimEnd: z.number().min(0).optional(),
    }).parse(req.body);

    if (body.trimEnd !== undefined && body.trimEnd - body.trimStart > config.maxAudioDuration)
      return fail(res, 400, "Selected range exceeds maximum duration", "DURATION_LIMIT");

    // ต้องมี yt-dlp ในระบบเพื่อดาวน์โหลดจริง — ไม่สร้างสถานะปลอม
    const { spawn } = await import("child_process");
    const audio = await new Promise<{ path: string; size: number } | null>((resolve) => {
      const out = `${Date.now()}-yt.mp3`;
      const args = ["-x", "--audio-format", "mp3", "--no-playlist", "-o", `${config.storagePath}/${out}`, "--"];
      if (body.trimStart > 0) args.push("--download-sections", `*${fmt(body.trimStart)}-${body.trimEnd ? fmt(body.trimEnd) : "inf"}`);
      args.push(body.url);
      const p = spawn("yt-dlp", args);
      let err = "";
      p.stderr.on("data", (c: Buffer) => (err += c.toString()));
      p.on("close", (code) => {
        if (code !== 0) { console.error("[yt-dlp]", err.slice(-400)); return resolve(null); }
        try {
          const st = fs.statSync(`${config.storagePath}/${out}`);
          resolve({ path: `/uploads/${out}`, size: st.size });
        } catch { resolve(null); }
      });
      p.on("error", () => resolve(null));
    });

    if (!audio) return fail(res, 502, "Import failed — ensure yt-dlp is installed on the server", "IMPORT_FAILED");

    const created = await prisma.audio.create({
      data: {
        userId: req.user!.id, title: body.title, fileUrl: audio.path,
        originalName: `${body.title}.mp3`, mimeType: "audio/mpeg",
        size: BigInt(audio.size), format: "mp3", status: "QUEUED",
      },
    });
    await prisma.processingJob.create({ data: { audioId: created.id, type: "CONVERT", options: { format: "mp3" } } });
    await notify(req.user!.id, "info", "YouTube import started", body.title);
    return ok(res, created, 201);
  } catch (e) { next(e); }
});

function fmt(sec: number) {
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = Math.floor(sec % 60);
  return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export default router;
