import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma.js";
import { ok, fail } from "../utils/response.js";

const router = Router();

router.get("/", async (req, res, next) => {
  try {
    const q = z.object({ page: z.coerce.number().min(1).default(1), limit: z.coerce.number().min(1).max(50).default(20) }).parse(req.query);
    const where = { audio: { userId: req.user!.id, deleted: false } };
    const [total, items] = await Promise.all([
      prisma.processingJob.count({ where }),
      prisma.processingJob.findMany({
        where, orderBy: { createdAt: "desc" },
        skip: (q.page - 1) * q.limit, take: q.limit,
        include: { audio: { select: { id: true, title: true, format: true } } },
      }),
    ]);
    return ok(res, { items, total, page: q.page, pages: Math.ceil(total / q.limit) });
  } catch (e) { next(e); }
});

router.get("/:id", async (req, res, next) => {
  try {
    const job = await prisma.processingJob.findFirst({
      where: { id: req.params.id, audio: { userId: req.user!.id, deleted: false } },
      include: { audio: true },
    });
    if (!job) return fail(res, 404, "Job not found", "NOT_FOUND");
    return ok(res, { ...job, audio: { ...job.audio, size: Number(job.audio.size) } });
  } catch (e) { next(e); }
});

router.post("/:id/cancel", async (req, res, next) => {
  try {
    const job = await prisma.processingJob.findFirst({
      where: { id: req.params.id, status: "QUEUED", audio: { userId: req.user!.id } },
    });
    if (!job) return fail(res, 404, "Job not found or already started", "NOT_FOUND");
    await prisma.processingJob.update({ where: { id: job.id }, data: { status: "CANCELLED" } });
    return ok(res, { cancelled: true });
  } catch (e) { next(e); }
});

export default router;
