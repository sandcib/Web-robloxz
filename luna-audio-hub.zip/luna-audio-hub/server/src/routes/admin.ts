import { Router } from "express";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "../lib/prisma.js";
import { ok, fail } from "../utils/response.js";
import { requireRole } from "../middleware/auth.js";
import { audit } from "../services/audit.js";
import { getAllSettings, getSetting } from "../services/settings.js";
import { notify } from "../services/notify.js";
import { sendDiscordLog } from "../services/discord.js";
import { config } from "../config.js";

const router = Router();
// ทุก endpoint ในนี้ต้องเป็น ADMIN ขึ้นไป (ตรวจฝั่ง server จริง)
router.use(requireRole("ADMIN"));

// ── ADMIN DASHBOARD ─────────────────────────────
router.get("/dashboard", async (_req, res, next) => {
  try {
    const since30 = new Date(Date.now() - 30 * 24 * 3600 * 1000);
    const [totalUsers, activeUsers, totalAudio, processingJobs, failedJobs, storageAgg, uploads30d, bans] =
      await Promise.all([
        prisma.user.count(),
        prisma.user.count({ where: { lastLoginAt: { gte: since30 } } }),
        prisma.audio.count({ where: { deleted: false } }),
        prisma.processingJob.count({ where: { status: { in: ["QUEUED", "PROCESSING"] } } }),
        prisma.processingJob.count({ where: { status: "FAILED" } }),
        prisma.audio.aggregate({ where: { deleted: false }, _sum: { size: true } }),
        prisma.audio.groupBy({ by: ["createdAt"], where: { deleted: false, createdAt: { gte: since30 } } }),
        prisma.user.count({ where: { banned: true } }),
      ]);

    const uploadsByDay: Record<string, number> = {};
    for (const u of uploads30d) {
      const day = u.createdAt.toISOString().slice(0, 10);
      uploadsByDay[day] = (uploadsByDay[day] || 0) + 1;
    }

    return ok(res, {
      totalUsers, activeUsers, totalAudio, processingJobs, failedJobs,
      bannedUsers: bans,
      storageUsed: Number(storageAgg._sum.size ?? 0),
      uploadsByDay: Object.entries(uploadsByDay).map(([date, count]) => ({ date, count })),
      system: {
        online: true,
        uptime: process.uptime(),
        memoryMb: Math.round(process.memoryUsage().rss / 1024 / 1024),
        node: process.version,
        queue: processingJobs,
      },
    });
  } catch (e) { next(e); }
});

// ── USERS ───────────────────────────────────────
router.get("/users", async (req, res, next) => {
  try {
    const q = z.object({
      page: z.coerce.number().min(1).default(1),
      limit: z.coerce.number().min(1).max(50).default(15),
      search: z.string().max(100).optional(),
      role: z.enum(["USER", "ADMIN", "SUPER_ADMIN"]).optional(),
      banned: z.coerce.boolean().optional(),
    }).parse(req.query);

    const where: Record<string, unknown> = {};
    if (q.search) where.OR = [
      { username: { contains: q.search, mode: "insensitive" } },
      { email: { contains: q.search, mode: "insensitive" } },
    ];
    if (q.role) where.role = q.role;
    if (q.banned !== undefined) where.banned = q.banned;

    const [total, items] = await Promise.all([
      prisma.user.count({ where }),
      prisma.user.findMany({
        where, orderBy: { createdAt: "desc" },
        skip: (q.page - 1) * q.limit, take: q.limit,
        select: { id: true, username: true, email: true, role: true, banned: true, avatarUrl: true, createdAt: true, lastLoginAt: true, storageUsed: true, _count: { select: { audios: true } } },
      }),
    ]);
    return ok(res, {
      items: items.map((u) => ({ ...u, storageUsed: Number(u.storageUsed), audioCount: u._count.audios })),
      total, page: q.page, pages: Math.ceil(total / q.limit),
    });
  } catch (e) { next(e); }
});

router.get("/users/:id", async (req, res, next) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.params.id },
      select: { id: true, username: true, email: true, role: true, banned: true, avatarUrl: true, createdAt: true, lastLoginAt: true, storageUsed: true, _count: { select: { audios: true, sessions: true } } },
    });
    if (!user) return fail(res, 404, "User not found", "NOT_FOUND");
    return ok(res, { ...user, storageUsed: Number(user.storageUsed) });
  } catch (e) { next(e); }
});

router.patch("/users/:id", async (req, res, next) => {
  try {
    const target = await prisma.user.findUnique({ where: { id: req.params.id } });
    if (!target) return fail(res, 404, "User not found", "NOT_FOUND");

    const body = z.object({
      role: z.enum(["USER", "ADMIN", "SUPER_ADMIN"]).optional(),
      banned: z.boolean().optional(),
      username: z.string().min(3).max(30).optional(),
      resetPassword: z.boolean().optional(),
    }).parse(req.body);

    // Permission rules: ADMIN แก้ USER ได้, แต่แก้ ADMIN/SUPER_ADMIN ไม่ได้ (เฉพาะ SUPER_ADMIN)
    if (req.user!.role !== "SUPER_ADMIN" && (target.role !== "USER" || body.role === "SUPER_ADMIN")) {
      return fail(res, 403, "Only SUPER_ADMIN can modify admin accounts", "FORBIDDEN");
    }

    const data: Record<string, unknown> = {};
    if (body.role) data.role = body.role;
    if (body.banned !== undefined) {
      data.banned = body.banned;
      if (body.banned) {
        await prisma.session.deleteMany({ where: { userId: target.id } });
        await audit(req, "USER_BAN", target.username);
        await sendDiscordLog("🔨 User banned", `**${target.username}** (${target.email})`);
      }
    }
    if (body.username) data.username = body.username;
    if (body.resetPassword) {
      data.passwordHash = await bcrypt.hash(cryptoRandom(), 12);
      await prisma.session.deleteMany({ where: { userId: target.id } });
    }
    if (body.role) {
      await audit(req, "ROLE_CHANGE", `${target.username} → ${body.role}`);
      await sendDiscordLog("🔑 Role changed", `**${target.username}** → ${body.role}`);
    }

    const updated = await prisma.user.update({ where: { id: target.id }, data, select: { id: true, username: true, role: true, banned: true } });
    await notify(target.id, "warning", "Account updated", "An administrator updated your account.");
    return ok(res, updated);
  } catch (e) { next(e); }
});

function cryptoRandom() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

router.delete("/users/:id", async (req, res, next) => {
  try {
    const target = await prisma.user.findUnique({ where: { id: req.params.id } });
    if (!target) return fail(res, 404, "User not found", "NOT_FOUND");
    if (target.role !== "USER" && req.user!.role !== "SUPER_ADMIN")
      return fail(res, 403, "Only SUPER_ADMIN can delete admin accounts", "FORBIDDEN");
    if (target.id === req.user!.id) return fail(res, 400, "You cannot delete your own account", "SELF_DELETE");

    await prisma.user.delete({ where: { id: target.id } });
    await audit(req, "USER_DELETE", target.username);
    return ok(res, { deleted: true });
  } catch (e) { next(e); }
});

// ── AUDIO MANAGEMENT ────────────────────────────
router.get("/audio", async (req, res, next) => {
  try {
    const q = z.object({
      page: z.coerce.number().min(1).default(1),
      limit: z.coerce.number().min(1).max(50).default(15),
      search: z.string().max(100).optional(),
      status: z.enum(["QUEUED", "PROCESSING", "READY", "FAILED"]).optional(),
      disabled: z.coerce.boolean().optional(),
    }).parse(req.query);

    const where: Record<string, unknown> = {};
    if (q.search) where.title = { contains: q.search, mode: "insensitive" };
    if (q.status) where.status = q.status;
    if (q.disabled !== undefined) where.deleted = q.disabled; // disabled = soft-deleted

    const [total, items] = await Promise.all([
      prisma.audio.count({ where }),
      prisma.audio.findMany({
        where, orderBy: { createdAt: "desc" },
        skip: (q.page - 1) * q.limit, take: q.limit,
        include: { user: { select: { username: true, email: true } } },
      }),
    ]);
    return ok(res, { items: items.map((a) => ({ ...a, size: Number(a.size) })), total, page: q.page, pages: Math.ceil(total / q.limit) });
  } catch (e) { next(e); }
});

router.delete("/audio/:id", async (req, res, next) => {
  try {
    const audio = await prisma.audio.findUnique({ where: { id: req.params.id } });
    if (!audio) return fail(res, 404, "Audio not found", "NOT_FOUND");
    await prisma.audio.update({ where: { id: audio.id }, data: { deleted: true } });
    await audit(req, "ADMIN_AUDIO_DELETE", audio.title);
    await sendDiscordLog("🗑️ Audio deleted by admin", `**${audio.title}**`);
    return ok(res, { deleted: true });
  } catch (e) { next(e); }
});

router.post("/audio/:id/restore", async (req, res, next) => {
  try {
    const audio = await prisma.audio.findUnique({ where: { id: req.params.id } });
    if (!audio) return fail(res, 404, "Audio not found", "NOT_FOUND");
    await prisma.audio.update({ where: { id: audio.id }, data: { deleted: false } });
    await audit(req, "ADMIN_AUDIO_RESTORE", audio.title);
    return ok(res, { restored: true });
  } catch (e) { next(e); }
});

// ── JOBS ────────────────────────────────────────
router.get("/jobs", async (req, res, next) => {
  try {
    const q = z.object({
      page: z.coerce.number().min(1).default(1),
      limit: z.coerce.number().min(1).max(50).default(20),
      status: z.enum(["QUEUED", "PROCESSING", "COMPLETED", "FAILED", "CANCELLED"]).optional(),
    }).parse(req.query);
    const where = q.status ? { status: q.status } : {};
    const [total, items] = await Promise.all([
      prisma.processingJob.count({ where }),
      prisma.processingJob.findMany({
        where, orderBy: { createdAt: "desc" },
        skip: (q.page - 1) * q.limit, take: q.limit,
        include: { audio: { include: { user: { select: { username: true } } } } },
      }),
    ]);
    return ok(res, { items, total, page: q.page, pages: Math.ceil(total / q.limit) });
  } catch (e) { next(e); }
});

router.post("/jobs/:id/retry", async (req, res, next) => {
  try {
    const job = await prisma.processingJob.findUnique({ where: { id: req.params.id } });
    if (!job) return fail(res, 404, "Job not found", "NOT_FOUND");
    if (job.status === "QUEUED" || job.status === "PROCESSING") return fail(res, 409, "Job is already running", "JOB_RUNNING");
    await prisma.$transaction([
      prisma.processingJob.update({ where: { id: job.id }, data: { status: "QUEUED", progress: 0, error: null } }),
      prisma.audio.update({ where: { id: job.audioId }, data: { status: "QUEUED" } }),
    ]);
    await audit(req, "JOB_RETRY", job.id);
    return ok(res, { retried: true });
  } catch (e) { next(e); }
});

router.post("/jobs/:id/cancel", async (req, res, next) => {
  try {
    const job = await prisma.processingJob.findUnique({ where: { id: req.params.id } });
    if (!job) return fail(res, 404, "Job not found", "NOT_FOUND");
    if (job.status === "QUEUED") {
      await prisma.processingJob.update({ where: { id: job.id }, data: { status: "CANCELLED" } });
    }
    await audit(req, "JOB_CANCEL", job.id);
    return ok(res, { cancelled: job.status === "QUEUED" });
  } catch (e) { next(e); }
});

// ── AUDIT LOG ───────────────────────────────────
router.get("/logs", async (req, res, next) => {
  try {
    const q = z.object({
      page: z.coerce.number().min(1).default(1),
      limit: z.coerce.number().min(1).max(100).default(30),
      action: z.string().max(50).optional(),
    }).parse(req.query);
    const where = q.action ? { action: { contains: q.action, mode: "insensitive" } } : {};
    const [total, items] = await Promise.all([
      prisma.auditLog.count({ where }),
      prisma.auditLog.findMany({
        where, orderBy: { createdAt: "desc" },
        skip: (q.page - 1) * q.limit, take: q.limit,
        include: { user: { select: { username: true } } },
      }),
    ]);
    return ok(res, { items, total, page: q.page, pages: Math.ceil(total / q.limit) });
  } catch (e) { next(e); }
});

// ── SETTINGS ────────────────────────────────────
const SETTING_KEYS = [
  "maxUploadSize", "maxAudioDuration", "allowedFileTypes", "defaultBitrate",
  "storageLimitMb", "maintenanceMode", "discordLoggingEnabled",
  "siteName", "primaryColor", "accentColor", "logoUrl", "faviconUrl", "defaultCoverUrl",
] as const;

router.get("/settings", async (_req, res, next) => {
  try {
    const settings = await getAllSettings();
    return ok(res, settings);
  } catch (e) { next(e); }
});

router.patch("/settings", async (req, res, next) => {
  try {
    const body = z.record(z.unknown()).parse(req.body ?? {});
    const allowed = Object.keys(body).filter((k) => (SETTING_KEYS as readonly string[]).includes(k));
    if (allowed.length === 0) return fail(res, 400, "No valid settings provided", "VALIDATION_ERROR");

    await prisma.$transaction(
      allowed.map((key) =>
        prisma.systemSetting.upsert({ where: { key }, update: { value: body[key] as object }, create: { key, value: body[key] as object } })
      )
    );
    await audit(req, "SETTINGS_UPDATED", allowed.join(", "));
    await sendDiscordLog("⚙️ Settings updated", allowed.map((k) => `• ${k}`).join("\n"));
    return ok(res, { updated: allowed });
  } catch (e) { next(e); }
});

// ── STATS (realtime) ────────────────────────────
router.get("/stats/realtime", async (_req, res, next) => {
  try {
    const [queue, processing, failed, users] = await Promise.all([
      prisma.processingJob.count({ where: { status: "QUEUED" } }),
      prisma.processingJob.count({ where: { status: "PROCESSING" } }),
      prisma.processingJob.count({ where: { status: "FAILED" } }),
      prisma.user.count(),
    ]);
    return ok(res, {
      queue, processing, failed, users,
      memoryMb: Math.round(process.memoryUsage().rss / 1024 / 1024),
      uptime: process.uptime(),
    });
  } catch (e) { next(e); }
});

export default router;
