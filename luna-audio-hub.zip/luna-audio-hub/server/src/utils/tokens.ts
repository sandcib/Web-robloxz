import jwt from "jsonwebtoken";
import crypto from "crypto";
import { config } from "../config.js";

export function createToken(userId: string, role: string) {
  return jwt.sign({ sub: userId, role }, config.jwtSecret, {
    expiresIn: `${config.sessionExpiryDays}d`,
  });
}

export function verifyToken(token: string): { sub: string; role: string } | null {
  try {
    return jwt.verify(token, config.jwtSecret) as { sub: string; role: string };
  } catch {
    return null;
  }
}

export function randomToken() {
  return crypto.randomBytes(32).toString("hex");
}
