import "dotenv/config";

export const config = {
  port: Number(process.env.PORT || 4000),
  clientUrl: process.env.CLIENT_URL || "http://localhost:5173",
  jwtSecret: process.env.JWT_SECRET || "dev-insecure-secret",
  sessionSecret: process.env.SESSION_SECRET || "dev-insecure-secret",
  sessionExpiryDays: Number(process.env.SESSION_EXPIRY_DAYS || 7),
  maxUploadSize: Number(process.env.MAX_UPLOAD_SIZE || 50 * 1024 * 1024),
  maxAudioDuration: Number(process.env.MAX_AUDIO_DURATION_SEC || 600),
  storagePath: process.env.STORAGE_PATH || "./uploads",
  storageLimitMb: Number(process.env.STORAGE_LIMIT_MB || 2048),
  nodeEnv: process.env.NODE_ENV || "development",
  roblox: {
    apiKey: process.env.ROBLOX_API_KEY || "",
    clientId: process.env.ROBLOX_CLIENT_ID || "",
    clientSecret: process.env.ROBLOX_CLIENT_SECRET || "",
  },
  discord: {
    webhookUrl: process.env.DISCORD_WEBHOOK_URL || "",
    enabled: process.env.DISCORD_LOGGING_ENABLED === "true",
  },
};

export const robloxConfigured = (): boolean =>
  Boolean(config.roblox.apiKey && config.roblox.clientId && config.roblox.clientSecret);
