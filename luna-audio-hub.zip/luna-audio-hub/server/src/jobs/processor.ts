import { spawn } from "child_process";
import path from "path";
import fs from "fs";
import { config } from "../config.js";
import { prisma } from "../lib/prisma.js";
import { broadcast } from "../services/sse.js";
import { notify } from "../services/notify.js";
import { sendDiscordLog } from "../services/discord.js";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function runFfmpeg(args: string[], onProgress: (pct: number) => void): Promise<void> {
  return new Promise((resolve, reject) => {
    const ff = spawn("ffmpeg", ["-y", ...args], { stdio: ["ignore", "pipe", "pipe"] });
    let stderr = "";
    let duration = 0;
    ff.stderr.on("data", (chunk: Buffer) => {
      const text = chunk.toString();
      stderr += text;
      const durMatch = text.match(/Duration: (\d+):(\d+):([\d.]+)/);
      if (durMatch) {
        duration =
          Number(durMatch[1]) * 3600 + Number(durMatch[2]) * 60 + Number(durMatch[3]);
      }
      const timeMatch = text.match(/time=(\d+):(\d+):([\d.]+)/);
      if (timeMatch && duration > 0) {
        const t = Number(timeMatch[1]) * 3600 + Number(timeMatch[2]) * 60 + Number(timeMatch[3]);
        onProgress(Math.min(99, Math.round((t / duration) * 100)));
      }
    });
    ff.on("error", (err) => reject(new Error(`FFmpeg not available: ${err.message}`)));
    ff.on("close", (code) => (code === 0 ? resolve() : reject(new Error(stderr.slice(-500)))));
  });
}

async function getDuration(filePath: string): Promise<number> {
  return new Promise((resolve) => {
    const ff = spawn("ffprobe", ["-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", filePath]);
    let out = "";
    ff.stdout.on("data", (c: Buffer) => (out += c.toString()));
    ff.on("close", () => resolve(parseFloat(out.trim()) || 0));
    ff.on("error", () => resolve(0));
  });
}

async function probeDurationSafe(filePath: string): Promise<number> {
  try { return await getDuration(filePath); } catch { return 0; }
}

export async function processOneJob() {
  const job = await prisma.processingJob.findFirst({
    where: { status: "QUEUED" },
    orderBy: { createdAt: "asc" },
    include: { audio: true },
  });
  if (!job) return false;

  await prisma.processingJob.update({ where: { id: job.id }, data: { status: "PROCESSING" } });
  await prisma.audio.update({ where: { id: job.audioId }, data: { status: "PROCESSING" } });
  broadcast({ type: "job", jobId: job.id, audioId: job.audioId, status: "PROCESSING", progress: 0 });

  const opts = (job.options ?? {}) as { format?: string; bitrate?: number; trimStart?: number; trimEnd?: number; normalize?: boolean };
  const src = path.resolve(config.storagePath, path.basename(job.audio.fileUrl));
  const outExt = opts.format || "mp3";
  const outName = `${job.audioId}-processed.${outExt}`;
  const outPath = path.resolve(config.storagePath, outName);

  try {
    if (!fs.existsSync(src)) throw new Error("Source file not found");

    const totalDur = await probeDurationSafe(src);
    const start = opts.trimStart && totalDur > 0 ? Math.max(0, Math.min(opts.trimStart, totalDur - 1)) : 0;
    const end = opts.trimEnd && totalDur > 0 ? Math.min(opts.trimEnd, totalDur) : 0;

    const args: string[] = ["-i", src];
    if (start > 0 || end > 0) {
      args.push("-ss", start.toFixed(2));
      if (end > start) args.push("-to", (end - start).toFixed(2));
    }
    if (opts.normalize) args.push("-af", "loudnorm=I=-16:TP=-1.5:LRA=11");
    const bitrate = opts.bitrate || job.audio.bitrate || 192;
    args.push("-b:a", `${bitrate}k`, outPath);

    await runFfmpeg(args, async (pct) => {
      await prisma.processingJob.update({ where: { id: job.id }, data: { progress: pct } }).catch(() => {});
      broadcast({ type: "job", jobId: job.id, audioId: job.audioId, status: "PROCESSING", progress: pct });
    });

    const newSize = fs.statSync(outPath).size;
    const newDur = await probeDurationSafe(outPath);

    await prisma.$transaction([
      prisma.audio.update({
        where: { id: job.audioId },
        data: {
          fileUrl: `/uploads/${outName}`,
          size: BigInt(newSize),
          duration: newDur,
          bitrate,
          format: outExt,
          status: "READY",
        },
      }),
      prisma.processingJob.update({
        where: { id: job.id },
        data: { status: "COMPLETED", progress: 100, completedAt: new Date() },
      }),
    ]);

    await prisma.history.create({
      data: { userId: job.audio.userId, action: "CONVERTED", target: `${job.audio.title} → ${outExt.toUpperCase()}` },
    });
    await notify(job.audio.userId, "success", "Processing complete", `${job.audio.title} is ready.`);
    await sendDiscordLog("✅ Audio processing completed", `**${job.audio.title}** → ${outExt.toUpperCase()} @ ${bitrate}kbps`);
    broadcast({ type: "job", jobId: job.id, audioId: job.audioId, status: "COMPLETED", progress: 100 });
    return true;
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error";
    await prisma.$transaction([
      prisma.processingJob.update({
        where: { id: job.id },
        data: { status: "FAILED", error: message, completedAt: new Date() },
      }),
      prisma.audio.update({ where: { id: job.audioId }, data: { status: "FAILED" } }),
    ]);
    await notify(job.audio.userId, "error", "Processing failed", `${job.audio.title}: ${message}`);
    broadcast({ type: "job", jobId: job.id, audioId: job.audioId, status: "FAILED", progress: 0 });
    return true;
  }
}

let running = false;
export function startJobWorker() {
  (async () => {
    for (;;) {
      if (!running) {
        running = true;
        try {
          while (await processOneJob()) { /* ทำ job ถัดไปทันที */ }
        } finally {
          running = false;
        }
      }
      await sleep(2000);
    }
  })();
  console.log("⚙️  Job worker started");
}
