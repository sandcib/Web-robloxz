import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import path from "path";
import fs from "fs";
import { config } from "./config.js";
import { prisma } from "./lib/prisma.js";
import { apiLimiter, authLimiter } from "./middleware/rateLimit.js";
import { maintenanceGuard } from "./middleware/maintenance.js";
import { errorHandler, notFoundHandler } from "./middleware/error.js";
import { requireAuth } from "./middleware/auth.js";

import authRoutes from "./routes/auth.js";
import userRoutes from "./routes/user.js";
import audioRoutes from "./routes/audio.js";
import jobRoutes from "./routes/jobs.js";
import favoriteRoutes from "./routes/favorites.js";
import historyRoutes from "./routes/history.js";
import notificationRoutes from "./routes/notifications.js";
import searchRoutes from "./routes/search.js";
import robloxRoutes from "./routes/roblox.js";
import youtubeRoutes from "./routes/youtube.js";
import adminRoutes from "./routes/admin.js";

const app = express();
app.set("trust proxy", 1);

app.use(cors({ origin: config.clientUrl, credentials: true }));
app.use(express.json({ limit: "2mb" }));
app.use(cookieParser());
app.use(apiLimiter);

// Static uploads (path traversal ปลอดภัยเพราะ serve จาก dir ที่กำหนด + express static)
const uploadsDir = path.resolve(config.storagePath);
fs.mkdirSync(uploadsDir, { recursive: true });
fs.mkdirSync(path.join(uploadsDir, "covers"), { recursive: true });
app.use("/uploads", express.static(uploadsDir, { fallthrough: true, index: false }));

app.get("/api/health", (_req, res) => {
  res.json({ success: true, data: { status: "OPERATIONAL", uptime: process.uptime() } });
});

app.use("/api/auth", authLimiter, authRoutes);
app.use("/api/user", requireAuth, userRoutes);
app.use("/api/audio", requireAuth, maintenanceGuard, audioRoutes);
app.use("/api/jobs", requireAuth, jobRoutes);
app.use("/api/favorites", requireAuth, favoriteRoutes);
app.use("/api/history", requireAuth, historyRoutes);
app.use("/api/notifications", requireAuth, notificationRoutes);
app.use("/api/search", requireAuth, searchRoutes);
app.use("/api/roblox", requireAuth, robloxRoutes);
app.use("/api/youtube", requireAuth, youtubeRoutes);
app.use("/api/admin", requireAuth, adminRoutes);

app.use(notFoundHandler);
app.use(errorHandler);

const server = app.listen(config.port, () => {
  console.log(`🌙 LUNA AUDIO HUB API → http://localhost:${config.port}`);
});

// เริ่ม worker ประมวลผลเสียง (FFmpeg queue)
import { startJobWorker } from "./jobs/processor.js";
startJobWorker();

// SSE สำหรับ realtime job progress
import { setupSSE } from "./services/sse.js";
setupSSE(server);

process.on("SIGTERM", async () => {
  await prisma.$disconnect();
  server.close();
  process.exit(0);
});
