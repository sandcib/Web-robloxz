import type { Request } from "express";
import { prisma } from "../lib/prisma.js";

export async function audit(req: Request, action: string, target?: string) {
  try {
    await prisma.auditLog.create({
      data: {
        userId: req.user?.id ?? null,
        action,
        target,
        ip: req.ip,
        userAgent: req.headers["user-agent"]?.slice(0, 300),
      },
    });
  } catch (e) {
    console.error("[audit] failed:", e);
  }
}
