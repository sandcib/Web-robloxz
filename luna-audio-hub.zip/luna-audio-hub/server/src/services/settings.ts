import { prisma } from "../lib/prisma.js";

export async function getSetting<T>(key: string, fallback: T): Promise<T> {
  const s = await prisma.systemSetting.findUnique({ where: { key } });
  return (s?.value as T) ?? fallback;
}

export async function getAllSettings() {
  const rows = await prisma.systemSetting.findMany();
  return Object.fromEntries(rows.map((r) => [r.key, r.value]));
}
