import { prisma } from "../lib/prisma.js";

export async function notify(userId: string, type: string, title: string, body?: string) {
  await prisma.notification.create({ data: { userId, type, title, body } });
}
