import { config } from "../config.js";

export async function sendDiscordLog(title: string, description: string) {
  if (!config.discord.enabled || !config.discord.webhookUrl) return;
  try {
    await fetch(config.discord.webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        embeds: [{
          title,
          description,
          color: 0x8b5cf6,
          timestamp: new Date().toISOString(),
        }],
      }),
    });
  } catch (e) {
    console.error("[discord] webhook failed:", e);
  }
}
