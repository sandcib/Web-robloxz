import type { Server } from "http";

const clients = new Set<{ id: string; send: (data: unknown) => void }>();

export function setupSSE(server: Server) {
  server.on("request", (req, res) => {
    if (req.url !== "/api/events" || req.method !== "GET") return;
    res.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
      "Access-Control-Allow-Origin": "*",
    });
    res.write(`data: ${JSON.stringify({ type: "connected" })}

`);
    const client = { id: Math.random().toString(36), send: (d: unknown) => res.write(`data: ${JSON.stringify(d)}

`) };
    clients.add(client);
    req.on("close", () => clients.delete(client));
  });
}

export function broadcast(event: unknown) {
  for (const c of clients) {
    try { c.send(event); } catch { clients.delete(c); }
  }
}
