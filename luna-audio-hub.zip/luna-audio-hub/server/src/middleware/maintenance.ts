import type { Request, Response, NextFunction } from "express";
import { prisma } from "../lib/prisma.js";
import { fail } from "../utils/response.js";

/** บล็อก user ทั่วไปเมื่อ Maintenance Mode เปิด (Admin/SuperAdmin ยังเข้าได้) */
export async function maintenanceGuard(req: Request, res: Response, next: NextFunction) {
  try {
    const setting = await prisma.systemSetting.findUnique({ where: { key: "maintenanceMode" } });
    const enabled = setting?.value === true;
    if (!enabled) return next();

    const role = req.user?.role;
    if (role === "ADMIN" || role === "SUPER_ADMIN") return next();

    return fail(res, 503, "System maintenance in progress", "MAINTENANCE_MODE");
  } catch {
    next();
  }
}
