import type { Request, Response, NextFunction } from "express";
import { verifyToken } from "../utils/tokens.js";
import { prisma } from "../lib/prisma.js";
import { fail } from "../utils/response.js";

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: { id: string; role: "USER" | "ADMIN" | "SUPER_ADMIN"; banned: boolean };
    }
  }
}

export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  const header = req.headers.authorization;
  const token = header?.startsWith("Bearer ") ? header.slice(7) : (req.cookies?.luna_token as string | undefined);
  if (!token) return fail(res, 401, "Authentication required", "UNAUTHORIZED");

  const payload = verifyToken(token);
  if (!payload) return fail(res, 401, "Invalid or expired session", "UNAUTHORIZED");

  const session = await prisma.session.findUnique({
    where: { token },
    include: { user: true },
  });
  if (!session || session.expiresAt < new Date())
    return fail(res, 401, "Session expired", "SESSION_EXPIRED");
  if (session.user.banned) return fail(res, 403, "Account banned", "ACCOUNT_BANNED");

  req.user = { id: session.user.id, role: session.user.role, banned: session.user.banned };
  next();
}

export function requireRole(...roles: Array<"ADMIN" | "SUPER_ADMIN">) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) return fail(res, 401, "Authentication required", "UNAUTHORIZED");
    if (req.user.role === "SUPER_ADMIN") return next();
    if (!roles.includes(req.user.role as "ADMIN"))
      return fail(res, 403, "Insufficient permissions", "FORBIDDEN");
    next();
  };
}
