import type { Request, Response, NextFunction } from "express";
import { ZodError } from "zod";
import { fail } from "../utils/response.js";

export function notFoundHandler(req: Request, res: Response) {
  fail(res, 404, `Route not found: ${req.method} ${req.path}`, "NOT_FOUND");
}

export function errorHandler(err: unknown, _req: Request, res: Response, _next: NextFunction) {
  if (err instanceof ZodError) {
    return fail(res, 400, err.issues[0]?.message || "Validation error", "VALIDATION_ERROR");
  }
  console.error("[ERROR]", err);
  fail(res, 500, "Internal server error", "INTERNAL_ERROR");
}
